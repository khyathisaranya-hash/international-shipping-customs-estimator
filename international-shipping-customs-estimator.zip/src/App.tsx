import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShoppingBag, 
  Calculator, 
  History, 
  HelpCircle, 
  AlertTriangle, 
  CheckCircle, 
  DollarSign, 
  PlaneTakeoff, 
  Truck, 
  FileCheck, 
  ShieldAlert, 
  Layers, 
  Info,
  Sliders,
  Settings,
  Scale,
  Trash2,
  FileText,
  Clock,
  ArrowRight,
  TrendingUp,
  X,
  Plus,
  RefreshCw,
  Search,
  Heart
} from "lucide-react";

import { 
  ItemCategory, 
  CountryData, 
  CalculationInput, 
  CalculationResult, 
  HistoryEntry, 
  GeminiAdvisorResponse 
} from "./types";
import LoginPage from "./components/LoginPage";


// Structured storefront products representing high-quality global goods
interface StoreProduct {
  id: string;
  name: string;
  tagline: string;
  category: ItemCategory;
  priceUSD: number;
  weightKg: number;
  lengthCm: number;
  widthCm: number;
  heightCm: number;
  image: string;
  description: string;
}

const FEATURED_PRODUCTS_TEMPLATES: StoreProduct[] = [
  // --- CARS (AUTOMOTIVE) ---
  {
    id: "car-swift",
    name: "Maruti Suzuki Swift",
    tagline: "Sporty & Efficient Hatchback (Collector Crate Edition)",
    category: ItemCategory.GENERAL,
    priceUSD: 14500,
    weightKg: 5.0,
    lengthCm: 384.5,
    widthCm: 173.5,
    heightCm: 153.0,
    image: "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=600&q=80",
    description: "Sleek crimson-red Maruti Suzuki Swift. Features a dynamic 1.2L DualJet engine, floating screen dashboard design, and aerodynamic urban handling metrics."
  },
  {
    id: "car-i20",
    name: "Hyundai i20",
    tagline: "Elite Premium Smart Hatchback (Sea Cargo Ready)",
    category: ItemCategory.GENERAL,
    priceUSD: 16805,
    weightKg: 5.0,
    lengthCm: 399.5,
    widthCm: 177.5,
    heightCm: 150.5,
    image: "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?auto=format&fit=crop&w=600&q=80",
    description: "Aggressively styled Hyundai i20 finished in metallic blue. Includes premium Bose audio, smart air purifier, smart sunroof, and driver assistance integrations."
  },
  {
    id: "car-tiago",
    name: "Tata Tiago",
    tagline: "High Safety Index Compact Hatchback",
    category: ItemCategory.GENERAL,
    priceUSD: 11200,
    weightKg: 5.0,
    lengthCm: 376.5,
    widthCm: 167.7,
    heightCm: 153.5,
    image: "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?auto=format&fit=crop&w=600&q=80",
    description: "4-Star Global NCAP safety rated urban hatchback equipped with impact absorbing shell, multi-drive modes, and premium infotainment."
  },
  {
    id: "car-thar",
    name: "Mahindra Thar 4x4",
    tagline: "Rugged Offroader Legend Edition",
    category: ItemCategory.GENERAL,
    priceUSD: 21999,
    weightKg: 5.0,
    lengthCm: 398.5,
    widthCm: 182.0,
    heightCm: 184.4,
    image: "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=600&q=80",
    description: "Iconic Mahindra Thar 4x4 offroad SUV. Features heavy-duty terrain suspension, removable hardtop panels, adventure dashboard telemetry, and mud-terrain wheels."
  },
  {
    id: "car-lambangiri",
    name: "Lambangiri Roadster",
    tagline: "Hypercar V12 Heritage Speedster (L-Design)",
    category: ItemCategory.GENERAL,
    priceUSD: 395000,
    weightKg: 5.0,
    lengthCm: 478.0,
    widthCm: 203.0,
    heightCm: 113.6,
    image: "https://images.unsplash.com/photo-1544636331-e26879cd4d9b?auto=format&fit=crop&w=600&q=80",
    description: "Exquisite high-performance carbon roadster. Accelerates 0-100 km/h in 2.9 seconds with a naturally aspirated V12 engine and lightweight composite parts."
  },

  // --- BIKES ---
  {
    id: "bike-ktmrc",
    name: "KTM RC 390",
    tagline: "Supersport Racing Track Warrior",
    category: ItemCategory.GENERAL,
    priceUSD: 5850,
    weightKg: 5.0,
    lengthCm: 199.5,
    widthCm: 73.0,
    heightCm: 111.0,
    image: "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80",
    description: "Aggressive KTM RC 390 track bike sporting aerodynamic orange race bodywork, adjustable WP suspension, and liquid-cooled single cylinder engine."
  },
  {
    id: "bike-ktmduke",
    name: "KTM Duke 390",
    tagline: "Sleek Naked Street Fighter",
    category: ItemCategory.GENERAL,
    priceUSD: 5400,
    weightKg: 5.0,
    lengthCm: 200.2,
    widthCm: 83.6,
    heightCm: 108.0,
    image: "https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=600&q=80",
    description: "High torque naked engine KTM Duke with sharp LED headlamp splitters, premium Bluetooth TFT console, and custom ABS traction algorithms."
  },
  {
    id: "bike-rx100",
    name: "Yamaha RX100 Classic",
    tagline: "Vintage 2-Stroke Legend Edition",
    category: ItemCategory.GENERAL,
    priceUSD: 2490,
    weightKg: 5.0,
    lengthCm: 196.0,
    widthCm: 74.0,
    heightCm: 105.0,
    image: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=600&q=80",
    description: "Immaculately restored classical black-and-chrome Yamaha RX100 motorcycle. Resounding signature exhaust tone and lightweight heritage framework."
  },

  // --- ELECTRONICS ---
  {
    id: "elec-smart",
    name: "iPhone 15 Pro (128GB)",
    tagline: "Titanium Cyber Smartphone",
    category: ItemCategory.ELECTRONICS,
    priceUSD: 999,
    weightKg: 0.22,
    lengthCm: 14.6,
    widthCm: 7.0,
    heightCm: 0.8,
    image: "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=600&q=80",
    description: "Premium titanium smartphone with A17 Pro core processor, high-definition telephoto lenses, and global satellite telemetry antennas."
  },
  {
    id: "elec-laptop",
    name: "MacBook Pro 14 M3",
    tagline: "Advanced Studio Performance Laptop",
    category: ItemCategory.ELECTRONICS,
    priceUSD: 1999,
    weightKg: 1.6,
    lengthCm: 31.2,
    widthCm: 22.1,
    heightCm: 1.5,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=600&q=80",
    description: "14-inch developer laptop featuring M3 architecture, outstanding Liquid Retina XDR screen, and expansive battery longevity."
  },
  {
    id: "elec-tablet",
    name: "iPad Pro 11-inch M4",
    tagline: "Tandem Ultra-Thin OLED Tablet",
    category: ItemCategory.ELECTRONICS,
    priceUSD: 999,
    weightKg: 0.44,
    lengthCm: 24.9,
    widthCm: 17.7,
    heightCm: 0.5,
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=600&q=80",
    description: "Pro-grade tablet utilizing dual OLED tandem screen technology. Light, fast M4 chip capabilities perfect for digital artists."
  },
  {
    id: "elec-watch",
    name: "Apple Watch Ultra 2",
    tagline: "Double-Tap Smartwatch",
    category: ItemCategory.ELECTRONICS,
    priceUSD: 799,
    weightKg: 0.35,
    lengthCm: 4.9,
    widthCm: 4.4,
    heightCm: 1.4,
    image: "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=600&q=80",
    description: "Aerospace titanium casing smartwatch with extreme battery endurance, precision dual-frequency GPS, and custom diving depth tracking."
  },
  {
    id: "elec-headphones",
    name: "Acoustic Noise-Cancelling Headphones",
    tagline: "High-Fidelity ANC Headphones",
    category: ItemCategory.ELECTRONICS,
    priceUSD: 349,
    weightKg: 0.38,
    lengthCm: 18.2,
    widthCm: 16.0,
    heightCm: 8.5,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80",
    description: "Premium digital acoustic headphones with multiple surround feedback microphones, adaptive active noise cancellation, and high bandwidth audio transceivers."
  },

  // --- FASHION ---
  {
    id: "fash-men",
    name: "Authentic German Leather Trench Coat",
    tagline: "Classic Weatherproof Men's Clothing",
    category: ItemCategory.FASHION,
    priceUSD: 450,
    weightKg: 2.1,
    lengthCm: 50.0,
    widthCm: 40.0,
    heightCm: 10.0,
    image: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?auto=format&fit=crop&w=600&q=80",
    description: "Double breasted black leather coat styled with retro heavy cowhide leather, metallic waist rings, and cold proof inner micro wool padding."
  },
  {
    id: "fash-women",
    name: "Premium Silk Evening Gown",
    tagline: "Elegant Flows Women's Clothing",
    category: ItemCategory.FASHION,
    priceUSD: 350,
    weightKg: 0.8,
    lengthCm: 40.0,
    widthCm: 30.0,
    heightCm: 5.0,
    image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=600&q=80",
    description: "Exquisite hand-woven organic silk gown featuring flowing modern silhouettes, breathable hypoallergenic texture, and custom gold-threaded hemline."
  },
  {
    id: "fash-kids",
    name: "Organic Cotton Kids Romper Pack",
    tagline: "Soft Cozy Toddler Outfit Wear",
    category: ItemCategory.FASHION,
    priceUSD: 45,
    weightKg: 0.3,
    lengthCm: 25.0,
    widthCm: 20.0,
    heightCm: 3.0,
    image: "https://images.unsplash.com/photo-1519689680058-324335c77ebe?auto=format&fit=crop&w=600&q=80",
    description: "Set of three premium cotton rompers for infants. Free from synthetic chemical pigments and designed with smooth flatlock diaper seams."
  },
  {
    id: "fash-shoes",
    name: "All-Weather Athletic Trail Shoes",
    tagline: "Enhanced Air Cushion Sport Shoes",
    category: ItemCategory.FASHION,
    priceUSD: 130,
    weightKg: 0.75,
    lengthCm: 32.0,
    widthCm: 20.0,
    heightCm: 12.0,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80",
    description: "Robust trail sneakers incorporating orthopaedic mesh arches, skid resistant carbon treads, and responsive shock buffer heels."
  },
  {
    id: "fash-watches",
    name: "Classic Gold Chronograph Watch",
    tagline: "Mechanical Clock Precision Watches",
    category: ItemCategory.FASHION,
    priceUSD: 210,
    weightKg: 0.15,
    lengthCm: 10.0,
    widthCm: 10.0,
    heightCm: 6.0,
    image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=600&q=80",
    description: "Elegant mechanical watch crafted using custom brass plating, visual skeleton interior, and self-winding chronographic gear arrays."
  },

  // --- HOME & KITCHEN ---
  {
    id: "home-cookware",
    name: "Professional Hard-Anodized Cookware",
    tagline: "Non-Stick 10-Piece Cookware Set",
    category: ItemCategory.GENERAL,
    priceUSD: 180,
    weightKg: 4.8,
    lengthCm: 45.0,
    widthCm: 35.0,
    heightCm: 28.0,
    image: "https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?auto=format&fit=crop&w=600&q=80",
    description: "Heavy-gauge anodized aluminum pots and skillets featuring professional stainless steel riveted grips and uniform central heat dissipation."
  },
  {
    id: "home-storage",
    name: "Airtight Glass Storage Containers",
    tagline: "Zero-BPA Safe Food Storage Containers",
    category: ItemCategory.GENERAL,
    priceUSD: 35,
    weightKg: 1.5,
    lengthCm: 28.0,
    widthCm: 20.0,
    heightCm: 14.0,
    image: "https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?auto=format&fit=crop&w=600&q=80",
    description: "BPA-free high borosilicate glassware set with snap-closing leakproof locking lids to protect freshness and preserve items perfectly."
  },
  {
    id: "home-furniture",
    name: "Mid-Century Modern Lounge Chair",
    tagline: "Ergonomic Retro Accent Furniture",
    category: ItemCategory.GENERAL,
    priceUSD: 420,
    weightKg: 5.0,
    lengthCm: 85.0,
    widthCm: 80.0,
    heightCm: 90.0,
    image: "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=600&q=80",
    description: "Gorgeous low profile designer armchair utilizing curved walnut plywood panels, soft grain black leather, and swivel structural legs."
  },
  {
    id: "home-decor",
    name: "Handcrafted Ceramic Vase",
    tagline: "Fired Clay Abstract Home Decor",
    category: ItemCategory.GENERAL,
    priceUSD: 55,
    weightKg: 0.9,
    lengthCm: 18.0,
    widthCm: 18.0,
    heightCm: 30.0,
    image: "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?auto=format&fit=crop&w=600&q=80",
    description: "Individually turned raw clay minimalist vase with subtle sand glazed finishing. Pairs flawlessly with dried local flora setups."
  },
  {
    id: "home-appliances",
    name: "Retro Style Kitchen Espresso Maker",
    tagline: "High Pressure Pump Espresso Kitchen Appliances",
    category: ItemCategory.GENERAL,
    priceUSD: 299,
    weightKg: 3.5,
    lengthCm: 32.0,
    widthCm: 26.0,
    heightCm: 38.0,
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=600&q=80",
    description: "Authentic 15-bar Italian espresso extraction system styled in vintage teal lacquer. Built-in adjustable steam wand produces velvet microfoam."
  },

  // --- BOOKS & STATIONERY ---
  {
    id: "book-academic",
    name: "Global Calculus & Physics Textbook",
    tagline: "Undergraduate Core Science Academic Books",
    category: ItemCategory.BOOKS,
    priceUSD: 115,
    weightKg: 2.2,
    lengthCm: 28.0,
    widthCm: 22.0,
    heightCm: 4.5,
    image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80",
    description: "Rigorous science textbook focusing on mathematical foundations, mechanical physics proofs, and aerospace modeling guidelines."
  },
  {
    id: "book-novel",
    name: "The Mystery of Forgotten Islands",
    tagline: "Saga Epic Thriller Novels",
    category: ItemCategory.BOOKS,
    priceUSD: 18,
    weightKg: 0.45,
    lengthCm: 21.0,
    widthCm: 14.0,
    heightCm: 3.2,
    image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=600&q=80",
    description: "Grip-turning modern mystery novel formatted in high quality hardback print. Captivating plotlines and character dynamics."
  },
  {
    id: "book-notebook",
    name: "Soft-Touch Leather Journal Set",
    tagline: "Dotted Pages Classic Notebooks",
    category: ItemCategory.BOOKS,
    priceUSD: 25,
    weightKg: 0.5,
    lengthCm: 21.0,
    widthCm: 15.0,
    heightCm: 2.0,
    image: "https://images.unsplash.com/photo-1531346878377-a5be20888e57?auto=format&fit=crop&w=600&q=80",
    description: "Acid-free heavy weight pages notebook bound in eco-friendly synthetic leather. Perfect flat-lay stitch design ideal for sketches and logs."
  },
  {
    id: "book-pen",
    name: "Handcrafted Brass Fountain Pen",
    tagline: "Precision Flow Nib Signature Pens",
    category: ItemCategory.BOOKS,
    priceUSD: 85,
    weightKg: 0.15,
    lengthCm: 14.0,
    widthCm: 1.5,
    heightCm: 1.5,
    image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&w=600&q=80",
    description: "Solid copper brass fountain body that develops a gorgeous rustic patina over time. High precision alloy writing tip for clean flow."
  },
  {
    id: "book-supplies",
    name: "Professional Masterclass Acrylic Set",
    tagline: "High Pigment Non-Toxic Art Supplies",
    category: ItemCategory.BOOKS,
    priceUSD: 60,
    weightKg: 0.9,
    lengthCm: 24.0,
    widthCm: 18.0,
    heightCm: 4.0,
    image: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&q=80",
    description: "Studio grade rich pigment acrylic set. Includes 24 dynamic colors that resist drying cracks and provide marvelous blend-ability."
  },

  // --- BEAUTY & PERSONAL CARE ---
  {
    id: "cosm-skincare",
    name: "Niacinamide Glowing Skincare Serum",
    tagline: "Double Strength Skin Defense Skincare Products",
    category: ItemCategory.COSMETICS,
    priceUSD: 42,
    weightKg: 0.15,
    lengthCm: 12.0,
    widthCm: 4.5,
    heightCm: 4.5,
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80",
    description: "Hydrating serum rich with active zinc complexes and organic plant ferments to nourish cells and optimize healthy skin defense indexes."
  },
  {
    id: "cosm-cosmetics",
    name: "High-Definition Matte Lipstick Trio",
    tagline: "Long Wear Satin Velvet Palette Cosmetics",
    category: ItemCategory.COSMETICS,
    priceUSD: 38,
    weightKg: 0.1,
    lengthCm: 10.0,
    widthCm: 6.0,
    heightCm: 2.2,
    image: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=600&q=80",
    description: "Waterproof velvet lipsticks offering deep moisture lock-in effects, elegant look options, and full matte finishing profiles."
  },
  {
    id: "cosm-hair",
    name: "Argan Oil Intense Hair Therapy Mask",
    tagline: "Reconstructive Keratin Shield Hair Care Products",
    category: ItemCategory.COSMETICS,
    priceUSD: 29,
    weightKg: 0.35,
    lengthCm: 9.0,
    widthCm: 9.0,
    heightCm: 8.0,
    image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=600&q=80",
    description: "Enriched Moroccan oil treatment designed to completely hydrate dry cuticles, fortify roots, and provide elegant light weight shine."
  },
  {
    id: "cosm-perfume",
    name: "Ambra Imperial Eau de Parfum",
    tagline: "Exotic Amber Woody Floral Perfumes",
    category: ItemCategory.COSMETICS,
    priceUSD: 145,
    weightKg: 0.45,
    lengthCm: 13.0,
    widthCm: 6.5,
    heightCm: 5.0,
    image: "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=600&q=80",
    description: "Artisanal fine scent mixing vibrant citrus headnotes with dark sandalwood bases. High concentration sillage that lasts remarkably long."
  },

  // --- TOYS & GAMES ---
  {
    id: "toys-educational",
    name: "Robotics Smart STEM Assembly Kit",
    tagline: "Programmable Smart Mechanical Car Educational Toys",
    category: ItemCategory.TOYS,
    priceUSD: 75,
    weightKg: 1.4,
    lengthCm: 28.0,
    widthCm: 18.0,
    heightCm: 12.0,
    image: "https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?auto=format&fit=crop&w=600&q=80",
    description: "Exciting mechanics assembly kit containing modular circuits, motor rigs, sonar modules, and intuitive drag-drop software tutorials."
  },
  {
    id: "toys-board",
    name: "Fantasy Realm Strategist Board Game",
    tagline: "Mythic Territory Campaign Board Games",
    category: ItemCategory.TOYS,
    priceUSD: 50,
    weightKg: 1.8,
    lengthCm: 30.0,
    widthCm: 30.0,
    heightCm: 8.0,
    image: "https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?auto=format&fit=crop&w=600&q=80",
    description: "Deep mechanics multiplayer strategist boardgame featuring beautifully sculpted fantasy figures, modular board designs, and complex resource mechanics."
  },
  {
    id: "toys-figure",
    name: "Deluxe Titanium Iron-Man Statuette",
    tagline: "Premium Posable Die-Cast Action Figures",
    category: ItemCategory.TOYS,
    priceUSD: 120,
    weightKg: 0.75,
    lengthCm: 24.0,
    widthCm: 12.0,
    heightCm: 8.0,
    image: "https://images.unsplash.com/photo-1608889175123-8ec330b86f84?auto=format&fit=crop&w=600&q=80",
    description: "Scale model high detail heroic action figure designed with metallic alloy cladding, multiple magnetic glowing battery lamps, and high agility limbs."
  },
  {
    id: "toys-puzzle",
    name: "Complex 2000-Piece Cosmic Jigsaw",
    tagline: "Heavy-Grid Precision Cut Puzzles",
    category: ItemCategory.TOYS,
    priceUSD: 30,
    weightKg: 0.95,
    lengthCm: 36.0,
    widthCm: 26.0,
    heightCm: 5.5,
    image: "https://images.unsplash.com/photo-1585241936939-be4099591252?auto=format&fit=crop&w=600&q=80",
    description: "Durable high-cardboard puzzle showcasing breathtaking astrophotography of deep space nebulae with dense satisfying locking keys."
  },

  // --- SPORTS & FITNESS ---
  {
    id: "sports-gym",
    name: "Adjustable Selectable Dumbbell Pair",
    tagline: "Heavy Duty Space-Saving Gym Equipment",
    category: ItemCategory.SPORTS,
    priceUSD: 249,
    weightKg: 5.0,
    lengthCm: 42.0,
    widthCm: 20.0,
    heightCm: 20.0,
    image: "https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?auto=format&fit=crop&w=600&q=80",
    description: "High speed index turning selector pin dumbbells that pack structural metal weight blocks together comfortably and securely."
  },
  {
    id: "sports-mat",
    name: "Eco-Friendly High-Density Yoga Mat",
    tagline: "Skid Resistant Ground Lock Cushion Yoga Mats",
    category: ItemCategory.SPORTS,
    priceUSD: 40,
    weightKg: 1.1,
    lengthCm: 183.0,
    widthCm: 61.0,
    heightCm: 0.6,
    image: "https://images.unsplash.com/photo-1592432678016-e910b452f9a2?auto=format&fit=crop&w=600&q=80",
    description: "Dual texture anti slip surface yoga mat made with sustainable non-toxic TPE rubber. Lightweight, durable, and highly cushioning."
  },
  {
    id: "sports-accessories",
    name: "Pro-Grip Smart Resistance Band",
    tagline: "Silicon Multi-Force Elastic Sports Accessories",
    category: ItemCategory.SPORTS,
    priceUSD: 18,
    weightKg: 0.35,
    lengthCm: 30.0,
    widthCm: 10.0,
    heightCm: 4.0,
    image: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=600&q=80",
    description: "Extremely heavy-duty anti snap silicon band equipped with comfortable foam handles for functional mobility or load resistance sessions."
  },

  // --- AUTOMOTIVE (ACCESSORIES) ---
  {
    id: "auto-accessories",
    name: "Active Smart Dashboard Dashcam GPS",
    tagline: "Dual 4K Wide-Angle Lens Car Accessories",
    category: ItemCategory.GENERAL,
    priceUSD: 120,
    weightKg: 0.45,
    lengthCm: 12.0,
    widthCm: 8.0,
    heightCm: 4.0,
    image: "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=600&q=80",
    description: "Premium dashboard camera recording simultaneous road front and rear views. Built-in G-Sensor, GPS tracking, and automatic loop override."
  },
  {
    id: "auto-bike",
    name: "Waterproof Heavy Duty Bike Cover",
    tagline: "Anti-UV Shield All-Weather Bike Accessories",
    category: ItemCategory.GENERAL,
    priceUSD: 30,
    weightKg: 0.85,
    lengthCm: 220.0,
    widthCm: 90.0,
    heightCm: 110.0,
    image: "https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=600&q=80",
    description: "Ripstop dustproof fabric bike cover. Complete with lock hole eyelets and high elasticity hem cords to shield motorcycles."
  },
  {
    id: "auto-cleaning",
    name: "Deep-Clean Foam Car Detailing Kit",
    tagline: "High Shine Polish & Soap Cleaning Kits",
    category: ItemCategory.GENERAL,
    priceUSD: 45,
    weightKg: 1.25,
    lengthCm: 25.0,
    widthCm: 15.0,
    heightCm: 20.0,
    image: "https://images.unsplash.com/photo-1607860108855-64cac2078bd0?auto=format&fit=crop&w=600&q=80",
    description: "Professional auto waxing and shampoo kit. Includes rich foaming cleaners, high-density microfiber pads, and streak-free buff sponges."
  },

  // --- PET SUPPLIES ---
  {
    id: "pet-food",
    name: "Sovereign Freeze-Dried Salmon Treats",
    tagline: "Grain-Free High Protein Pet Food",
    category: ItemCategory.FOOD,
    priceUSD: 24,
    weightKg: 0.45,
    lengthCm: 18.0,
    widthCm: 12.0,
    heightCm: 6.0,
    image: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=600&q=80",
    description: "Delicious nutrient-dense salmon bites for domestic dogs or cats. Pure fish freeze dried to retain organic proteins and amino acids."
  },
  {
    id: "pet-toys",
    name: "Tough-Bite Interactive Dog Tug Toy",
    tagline: "Heavy-Duty Natural Rubber Pet Toys",
    category: ItemCategory.GENERAL,
    priceUSD: 15,
    weightKg: 0.25,
    lengthCm: 16.0,
    widthCm: 6.0,
    heightCm: 6.0,
    image: "https://images.unsplash.com/photo-1576201836106-db1758fd1c97?auto=format&fit=crop&w=600&q=80",
    description: "Textured rubber dental cleaning dummy. Highly resistant to strong chewers to ensure safe, active play intervals."
  },
  {
    id: "pet-grooming",
    name: "Premium Pet Grooming Scissors Kit",
    tagline: "Stainless Rounded Blade Grooming Products",
    category: ItemCategory.GENERAL,
    priceUSD: 35,
    weightKg: 0.15,
    lengthCm: 18.0,
    widthCm: 8.0,
    heightCm: 2.0,
    image: "https://images.unsplash.com/photo-1516733725897-1aa73b87c8e8?auto=format&fit=crop&w=600&q=80",
    description: "Professional quality alloy pair of shears and spacing combs with protective rounded heads to groom pets safely."
  },

  // --- GROCERY & ESSENTIALS ---
  {
    id: "groc-snacks",
    name: "Organic Honey Roasted Cashews",
    tagline: "Gourmet Oven-Glazed Nut Snacks",
    category: ItemCategory.FOOD,
    priceUSD: 12,
    weightKg: 0.35,
    lengthCm: 15.0,
    widthCm: 10.0,
    heightCm: 5.0,
    image: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&w=600&q=80",
    description: "Crunchy premium grade organic cashews lightly toasted with pure forest honey syrup and a subtle dusting of sea salt."
  },
  {
    id: "groc-beverages",
    name: "Artisanal Fine Cold Brew Coffee Blend",
    tagline: "Nitrogen Infused Roast Beverages",
    category: ItemCategory.FOOD,
    priceUSD: 18,
    weightKg: 0.8,
    lengthCm: 22.0,
    widthCm: 8.0,
    heightCm: 8.0,
    image: "https://images.unsplash.com/photo-1497515114629-f71d768fd07c?auto=format&fit=crop&w=600&q=80",
    description: "Smooth, zero bitterness cold brewed extraction of organic Ethiopian beans with a dynamic chocolatey body profile."
  },
  {
    id: "groc-laundry",
    name: "Eco-Shield Laundry Detergent Sheets",
    tagline: "Rapid Dissolve Clean Sheets Household Essentials",
    category: ItemCategory.GENERAL,
    priceUSD: 15,
    weightKg: 0.15,
    lengthCm: 18.0,
    widthCm: 12.0,
    heightCm: 1.5,
    image: "https://images.unsplash.com/photo-1563453392212-326f5e854473?auto=format&fit=crop&w=600&q=80",
    description: "Highly concentrated plant-based detergent sheets that dissolve instantly. Biodegradable, space-saving, and fragranced with lavender oils."
  }
];

const FEATURED_PRODUCTS: StoreProduct[] = FEATURED_PRODUCTS_TEMPLATES.map(p => ({
  ...p,
  // Keep original realistic weight but clamp heavy items to exactly 5.0 kg so they comply with our system limits
  weightKg: Math.min(5.0, p.weightKg || (Math.floor(Math.random() * 4) + 1))
}));

// Interactive shopping cart item model
interface CartItem {
  id: string; // unique cart uuid
  product: StoreProduct;
  quantity: number;
  originCountry: CountryData;
}

export default function App() {
  const [currentUser, setCurrentUser] = useState<{ email: string; name: string; role: string } | null>(() => {
    const saved = localStorage.getItem("logistics_agent_user");
    return saved ? JSON.parse(saved) : null;
  });

  const handleLogout = () => {
    localStorage.removeItem("logistics_agent_user");
    setCurrentUser(null);
  };

  const [countries, setCountries] = useState<CountryData[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [selectedComplianceCountry, setSelectedComplianceCountry] = useState<string>("IN");
  const [complianceSearchItem, setComplianceSearchItem] = useState<string>("");
  
  // Navigation tabs state
  const [activeTab, setActiveTab] = useState<"items" | "estimator" | "cart" | "insights">("items");
  
  // Custom theme filter for searching items
  const [itemSearchQuery, setItemSearchQuery] = useState("");
  
  // Estimator Form Inputs State (Pre-filled with default Values to prevent loading blank screens)
  const [formInput, setFormInput] = useState<CalculationInput>({
    originCode: "US",
    destinationCode: "IN",
    category: ItemCategory.ELECTRONICS,
    declaredValue: 999,
    valueCurrency: "USD",
    weight: 0.22,
    weightUnit: "kg",
    length: 15,
    width: 8,
    height: 1,
    dimensionUnit: "cm",
    shippingMode: "express"
  });

  const [itemDescription, setItemDescription] = useState("iPhone 15 Pro Titanium smartphone");
  
  // Async status states
  const [isCalculating, setIsCalculating] = useState(false);
  const [isAdvising, setIsAdvising] = useState(false);
  const [feedbackError, setFeedbackError] = useState<string | null>(null);
  
  // Active estimation findings model
  const [activeResult, setActiveResult] = useState<CalculationResult | null>(null);
  const [advisorAdvice, setAdvisorAdvice] = useState<GeminiAdvisorResponse | null>(null);

  // Interactive Bargaining Broker states
  const [bargainProposedPriceStr, setBargainProposedPriceStr] = useState<string>("");
  const [bargainStatus, setBargainStatus] = useState<"idle" | "sending" | "approved" | "rejected" | "countered">("idle");
  const [bargainMessage, setBargainMessage] = useState<string>("");
  const [bargainAttempts, setBargainAttempts] = useState<number>(0);
  const [bargainDiscountApplied, setBargainDiscountApplied] = useState<number>(0);
  const [bargayedCostUSD, setBargayedCostUSD] = useState<number | null>(null);
  const [bargainHistory, setBargainHistory] = useState<{offer: number; status: string; agentReply: string}[]>([]);
  
  // Client Shopping Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartDestination, setCartDestination] = useState<string>("IN");
  
  // Custom Dynamic Multi-User Admin Surcharge Adjuster
  const [adminFuelMultiplier, setAdminFuelMultiplier] = useState<number>(1.0);
  const [adminHandlingMarkup, setAdminHandlingMarkup] = useState<number>(0.0);

  // Custom dynamically searched/retrieved items via AI Specs Lookup
  const [customProducts, setCustomProducts] = useState<StoreProduct[]>([]);
  const [globalSearchPhrase, setGlobalSearchPhrase] = useState("");
  const [isGlobalLoading, setIsGlobalLoading] = useState(false);
  const [retrievedProducts, setRetrievedProducts] = useState<StoreProduct[]>([]);
  const [globalSearchError, setGlobalSearchError] = useState<string | null>(null);

  // User Wishlist State persisted in localStorage
  const [wishlist, setWishlist] = useState<StoreProduct[]>(() => {
    const saved = localStorage.getItem("logistics_agent_wishlist");
    return saved ? JSON.parse(saved) : [];
  });

  const toggleWishlist = (product: StoreProduct) => {
    setWishlist(prev => {
      const exists = prev.some(item => item.id === product.id);
      let updated;
      if (exists) {
        updated = prev.filter(item => item.id !== product.id);
      } else {
        updated = [...prev, product];
      }
      localStorage.setItem("logistics_agent_wishlist", JSON.stringify(updated));
      return updated;
    });
  };

  // Detailed modal/detail visual overlay for selected product
  const [selectedProductDetails, setSelectedProductDetails] = useState<StoreProduct | null>(null);

  // Track dynamic weight and price adjustments per product
  const [productAdjustments, setProductAdjustments] = useState<Record<string, { weightKg: number; priceUSD: number }>>(() => {
    try {
      const saved = localStorage.getItem("logistics_agent_adjustments");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const getProductStats = (product: StoreProduct) => {
    const adjustment = productAdjustments[product.id];
    if (adjustment) {
      return {
        weightKg: Number(adjustment.weightKg.toFixed(2)),
        priceUSD: Number(adjustment.priceUSD.toFixed(0))
      };
    }
    return {
      weightKg: product.weightKg,
      priceUSD: product.priceUSD
    };
  };

  const adjustProductWeight = (product: StoreProduct, newWeight: number) => {
    if (newWeight < 0.01) return;
    const ratio = newWeight / product.weightKg;
    const newPrice = Math.round(product.priceUSD * ratio);
    setProductAdjustments(prev => {
      const updated = {
        ...prev,
        [product.id]: {
          weightKg: Number(newWeight.toFixed(2)),
          priceUSD: Number(newPrice.toFixed(0))
        }
      };
      localStorage.setItem("logistics_agent_adjustments", JSON.stringify(updated));
      return updated;
    });
  };

  const getAdjustedProduct = (product: StoreProduct): StoreProduct => {
    const stats = getProductStats(product);
    return {
      ...product,
      weightKg: stats.weightKg,
      priceUSD: stats.priceUSD
    };
  };

  const handleGlobalSpecsSearch = async () => {
    if (!globalSearchPhrase.trim()) return;
    setIsGlobalLoading(true);
    setGlobalSearchError(null);

    try {
      const res = await fetch("/api/custom-product-lookup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ searchQuery: globalSearchPhrase.trim() })
      });

      if (!res.ok) {
        throw new Error("Unable to retrieve item specifications from market database.");
      }

      const data = await res.json();
      const randomizedData = {
        ...data,
        weightKg: Math.floor(Math.random() * 10) + 1
      };
      setRetrievedProducts(prev => {
        // Prevent duplicate results by name
        const exists = prev.some(p => p.name.toLowerCase() === randomizedData.name.toLowerCase());
        if (exists) return prev;
        return [randomizedData, ...prev];
      });
      // Clear search phrase after successfully completing
      setGlobalSearchPhrase("");
    } catch (err: any) {
      setGlobalSearchError(err.message || "Failed to search product specifications.");
    } finally {
      setIsGlobalLoading(false);
    }
  };

  // Initialize application details on launch
  useEffect(() => {
    fetchCountries();
    fetchHistory();
    fetchNotifications();
  }, []);

  const fetchCountries = async () => {
    try {
      const res = await fetch("/api/countries");
      if (res.ok) {
        const data = await res.ok ? await res.json() : [];
        setCountries(data);
      }
    } catch (err: any) {
      console.error("Error retrieving countries database list:", err);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await fetch("/api/history");
      if (res.ok) {
        const data = await res.json();
        setHistory(data);
      }
    } catch (err: any) {
      console.error("Error fetching calculations log repository:", err);
    }
  };

  const fetchNotifications = async () => {
    try {
      const res = await fetch("/api/notifications");
      if (res.ok) {
        const data = await res.json();
        setNotifications(data);
      }
    } catch (err) {
      console.error("Error fetching live critical notices feed:", err);
    }
  };

  const executeClearHistory = async () => {
    if (!window.confirm("Are you sure you want to clear all calculations history? This action is server-side and irreversible.")) {
      return;
    }
    try {
      const res = await fetch("/api/history/clear", { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        setHistory(data.history);
      }
    } catch (err) {
      console.error("Error clearing memory history:", err);
    }
  };

  // Launch Estimator calculation action
  const handleCalculate = async (customInput?: CalculationInput, customDesc?: string) => {
    setFeedbackError(null);
    setIsCalculating(true);
    setIsAdvising(true);
    
    // Reset bargaining index
    setBargainProposedPriceStr("");
    setBargainStatus("idle");
    setBargainMessage("");
    setBargainAttempts(0);
    setBargainDiscountApplied(0);
    setBargayedCostUSD(null);
    setBargainHistory([]);

    const finalInput = customInput || formInput;
    const desc = customDesc || itemDescription;

    try {
      // 1. Fetch exact pricing equations
      const pricingRes = await fetch("/api/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(finalInput),
      });

      if (!pricingRes.ok) {
        throw new Error("Unable to evaluate shipping rates. Check parameter boundaries.");
      }

      const pricingData = await pricingRes.json();
      
      // Inject admin customized multipliers if set
      let adjustedResult: CalculationResult = { ...pricingData.result };
      if (adminFuelMultiplier !== 1.0 || adminHandlingMarkup > 0) {
        const deltaFuelUSD = adjustedResult.fuelSurchargeUSD * (adminFuelMultiplier - 1);
        const deltaHandlingUSD = adminHandlingMarkup;
        const totalDeltaUSD = deltaFuelUSD + deltaHandlingUSD;

        const targetDest = countries.find(c => c.code === finalInput.destinationCode) || countries[0];
        const destRate = targetDest.rateToUSD || 1.0;

        adjustedResult.fuelSurchargeUSD = Number((adjustedResult.fuelSurchargeUSD * adminFuelMultiplier).toFixed(2));
        adjustedResult.handlingFeeUSD = Number((adjustedResult.handlingFeeUSD + adminHandlingMarkup).toFixed(2));
        adjustedResult.landedCostUSD = Number((adjustedResult.landedCostUSD + totalDeltaUSD).toFixed(2));
        adjustedResult.landedCostLocal = Number((adjustedResult.landedCostLocal + (totalDeltaUSD / destRate)).toFixed(2));
      }

      setActiveResult(adjustedResult);
      fetchHistory(); // refresh calculation logs immediately

      // 2. Fetch intelligent customs advice powered by server-side Gemini AI
      const advisorRes = await fetch("/api/gemini/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          originCode: finalInput.originCode,
          destinationCode: finalInput.destinationCode,
          itemDescription: desc,
          declaredValue: finalInput.declaredValue,
          category: finalInput.category,
        }),
      });

      if (advisorRes.ok) {
        const advisorData = await advisorRes.json();
        setAdvisorAdvice(advisorData);
      }
    } catch (err: any) {
      setFeedbackError(err.message || "Logistics evaluation timeout. Please retry.");
    } finally {
      setIsCalculating(false);
      setIsAdvising(false);
    }
  };

  // Launch Interactive Cargo Bargaining
  const handleBargain = async (proposedValue: number) => {
    if (!activeResult) return;
    setBargainStatus("sending");
    setFeedbackError(null);
    try {
      const res = await fetch("/api/bargain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          originalResult: activeResult,
          proposedPriceUSD: proposedValue,
          attemptsCount: bargainAttempts + 1,
          declaredValue: formInput.declaredValue
        })
      });

      if (!res.ok) {
        throw new Error("Logistics negotiation desk is temporarily offline. Please bid again shortly.");
      }

      const data = await res.json();
      const currentAttempt = bargainAttempts + 1;
      setBargainAttempts(currentAttempt);
      setBargainStatus(data.status);
      setBargainMessage(data.explanation);

      if (data.status === "approved" || data.status === "countered") {
        setBargayedCostUSD(data.bargainedLandedCostUSD);
        setBargainDiscountApplied(activeResult.landedCostUSD - data.bargainedLandedCostUSD);
      } else {
        // rejected
        setBargayedCostUSD(null);
        setBargainDiscountApplied(0);
      }

      setBargainHistory(prev => [
        {
          offer: proposedValue,
          status: data.status,
          agentReply: data.explanation
        },
        ...prev
      ]);

    } catch (err: any) {
      setBargainStatus("idle");
      setFeedbackError(err.message || "Bargaining failed. Please retry.");
    }
  };

  const handleAcceptCounterOffer = () => {
    if (bargayedCostUSD && activeResult) {
      setBargainStatus("approved");
      setBargainMessage(`Deal officially sealed! 🤝 You successfully accepted our counter-offer of $${bargayedCostUSD} USD. Safe shipping index is active.`);
    }
  };

  // Actions for selecting products directly from storefront
  const selectProductToEstimate = (product: StoreProduct) => {
    const matchedOrigin = "US"; // default origin for initial stocks
    const matchedCategory = product.category;

    const updatedFormInput: CalculationInput = {
      originCode: matchedOrigin,
      destinationCode: "IN", // default import testbed
      category: matchedCategory,
      declaredValue: product.priceUSD,
      valueCurrency: "USD",
      weight: product.weightKg,
      weightUnit: "kg",
      length: product.lengthCm,
      width: product.widthCm,
      height: product.heightCm,
      dimensionUnit: "cm",
      shippingMode: "express"
    };

    setFormInput(updatedFormInput);
    setItemDescription(`${product.name} - ${product.tagline}`);
    setActiveTab("estimator");
    
    // Auto-calculate immediately to prevent extra clicks for the student testing it!
    handleCalculate(updatedFormInput, `${product.name} - ${product.tagline}`);
  };

  const addProductToCart = (product: StoreProduct) => {
    // Lookup origin from countries or fallback to US
    const usCountry = countries.find(c => c.code === "US") || {
      code: "US",
      name: "United States",
      currency: "USD",
      symbol: "$",
      rateToUSD: 1.0,
      deMinimis: 800,
      vatRate: 0,
      dutyRates: {},
      restrictedItems: []
    } as any;

    setCartItems(prev => {
      // check if already listed with the same customized specifications (weight and price)
      const exists = prev.find(item => item.product.id === product.id && item.product.weightKg === product.weightKg);
      if (exists) {
        return prev.map(item => (item.product.id === product.id && item.product.weightKg === product.weightKg) ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, {
        id: "cart_" + Math.random().toString(36).substring(2, 9),
        product,
        quantity: 1,
        originCountry: usCountry
      }];
    });

    // Pulse feedback
    const originalBtn = document.getElementById(`btn-cart-${product.id}`);
    if (originalBtn) {
      const originalText = originalBtn.innerHTML;
      originalBtn.innerHTML = "✅ Added to Cart!";
      originalBtn.classList.remove("bg-cyan-600", "hover:bg-cyan-700");
      originalBtn.classList.add("bg-emerald-600");
      setTimeout(() => {
        originalBtn.innerHTML = originalText;
        originalBtn.classList.remove("bg-emerald-600");
        originalBtn.classList.add("bg-cyan-600", "hover:bg-cyan-700");
      }, 1500);
    }
  };

  // Remove individual item from tracking cart
  const removeCartItem = (uuid: string) => {
    setCartItems(prev => prev.filter(p => p.id !== uuid));
  };

  // Calculate Consolidated Shopping Cart totals
  const evaluateCombinedCartStats = () => {
    let rawItemValueUSD = 0;
    let totalWeightKg = 0;
    
    cartItems.forEach(item => {
      rawItemValueUSD += (item.product.priceUSD * item.quantity);
      totalWeightKg += (item.product.weightKg * item.quantity);
    });

    // Find destination country rules
    const destCountry = countries.find(c => c.code === cartDestination) || countries.find(c => c.code === "IN") || {
      code: "IN",
      name: "India",
      currency: "INR",
      symbol: "₹",
      rateToUSD: 0.012,
      deMinimis: 20,
      vatRate: 18,
      dutyRates: { [ItemCategory.ELECTRONICS]: 10.0 },
      restrictedItems: []
    } as any;

    // Approximate combined volume weight
    const rawShippingCostUSD = 25 + (totalWeightKg * 9.50);
    const isBelowDeMinimis = rawItemValueUSD <= destCountry.deMinimis;

    let dutyUSD = 0;
    let vatUSD = 0;

    if (!isBelowDeMinimis && cartItems.length > 0) {
      // Find average duty rate based on items added
      let totalWeightedDutyPct = 0;
      cartItems.forEach(item => {
        const categoryRate = destCountry.dutyRates[item.product.category] !== undefined
          ? destCountry.dutyRates[item.product.category]
          : 5.0;
        totalWeightedDutyPct += (categoryRate * item.quantity);
      });
      const avgDutyPct = totalWeightedDutyPct / Math.max(1, cartItems.reduce((acc, cur) => acc + cur.quantity, 0));
      
      const cifUSD = rawItemValueUSD + rawShippingCostUSD;
      dutyUSD = cifUSD * (avgDutyPct / 100);
      vatUSD = (cifUSD + dutyUSD) * (destCountry.vatRate / 100);
    }

    const fuelUSD = rawShippingCostUSD * 0.125 * adminFuelMultiplier;
    const handlingUSD = 12.0 + adminHandlingMarkup;
    
    const finalFreightUSD = rawShippingCostUSD + fuelUSD + handlingUSD;
    const finalLandedUSD = cartItems.length === 0 ? 0 : rawItemValueUSD + finalFreightUSD + dutyUSD + vatUSD;
    
    const localRate = destCountry.rateToUSD || 1.0;
    const finalLandedLocal = finalLandedUSD / localRate;

    return {
      rawItemValueUSD,
      totalWeightKg,
      finalFreightUSD,
      dutyUSD,
      vatUSD,
      finalLandedUSD,
      destCountry,
      finalLandedLocal,
      isBelowDeMinimis
    };
  };

  const fallbackCountry: CountryData = {
    code: "US",
    name: "United States",
    currency: "USD",
    symbol: "$",
    rateToUSD: 1.0,
    deMinimis: 800,
    vatRate: 0,
    dutyRates: {},
    restrictedItems: []
  };

  const computeLocalDDPPreview = (product: StoreProduct) => {
    const destination = countries.find(c => c.code === formInput.destinationCode) || countries[0] || fallbackCountry;
    
    const physicalWeight = product.weightKg;
    const volumetricWeight = (product.lengthCm * product.widthCm * product.heightCm) / 5000;
    const chargeableWeight = Math.max(physicalWeight, volumetricWeight);
    
    const baseShippingRate = formInput.shippingMode === "express" ? 35 : 15;
    const perKgRate = formInput.shippingMode === "express" ? 14.50 : 8.50;
    
    const baseShippingCostUSD = baseShippingRate + (chargeableWeight * perKgRate);
    const fuelSurchargeUSD = baseShippingCostUSD * 0.125 * adminFuelMultiplier;
    const handlingFeeUSD = 7.50 + adminHandlingMarkup;
    const totalShippingCostUSD = baseShippingCostUSD + fuelSurchargeUSD + handlingFeeUSD;
    
    const itemValueUSD = product.priceUSD;
    const isBelowDeMinimis = itemValueUSD <= destination.deMinimis;
    
    let dutyUSD = 0;
    let vatUSD = 0;
    
    if (!isBelowDeMinimis) {
      const dutyPercentage = destination.dutyRates[product.category] !== undefined 
        ? destination.dutyRates[product.category] 
        : 5.0;
      
      const cifValueUSD = itemValueUSD + totalShippingCostUSD;
      dutyUSD = cifValueUSD * (dutyPercentage / 100);
      vatUSD = (cifValueUSD + dutyUSD) * (destination.vatRate / 100);
    }
    
    const landedCostUSD = itemValueUSD + totalShippingCostUSD + dutyUSD + vatUSD;
    const landedCostLocal = landedCostUSD / (destination.rateToUSD || 1.0);
    
    return {
      destination,
      isBelowDeMinimis,
      shippingCostUSD: totalShippingCostUSD,
      dutyUSD,
      vatUSD,
      landedCostUSD,
      landedCostLocal
    };
  };

  const cartStats = evaluateCombinedCartStats();
  const complianceCountryData = countries.find(c => c.code === selectedComplianceCountry) || fallbackCountry;

  const activeDestinationCountry = countries.find(c => c.code === formInput.destinationCode) || countries[0] || fallbackCountry;
  const activeDestinationRate = activeDestinationCountry.rateToUSD || 1.0;
  
  const finalDisplayLandedCostUSD = (bargayedCostUSD !== null && (bargainStatus === "approved" || bargainStatus === "countered"))
    ? bargayedCostUSD
    : (activeResult ? activeResult.landedCostUSD : 0);

  const finalDisplayLandedCostLocal = finalDisplayLandedCostUSD / activeDestinationRate;

  const allProducts = [...customProducts, ...FEATURED_PRODUCTS].map(getAdjustedProduct);

  // Filter storefront items based on query, ensuring we provide up to 15 related suggestions when searched
  const filteredProducts = (() => {
    if (!itemSearchQuery.trim()) {
      return allProducts.map(p => ({ ...p, isSuggested: false }));
    }
    const query = itemSearchQuery.toLowerCase().trim();
    
    // 1. Get direct matches
    const directMatches = allProducts.filter(p =>
      p.name.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query) ||
      p.tagline.toLowerCase().includes(query) ||
      (p.description && p.description.toLowerCase().includes(query))
    ).map(p => ({ ...p, isSuggested: false }));
    
    // If we have at least 15 direct matches, return them
    if (directMatches.length >= 15) {
      return directMatches;
    }
    
    // 2. Pad with products from the same categories
    const matchedCategories = Array.from(new Set(directMatches.map(m => m.category)));
    const relatedFromCategories = allProducts.filter(p =>
      !directMatches.some(m => m.id === p.id) &&
      matchedCategories.includes(p.category)
    ).map(p => ({ ...p, isSuggested: true }));
    
    // 3. Fallback to other popular products to pad to exactly 15 items if needed
    const remainingProducts = allProducts.filter(p =>
      !directMatches.some(m => m.id === p.id) &&
      !relatedFromCategories.some(r => r.id === p.id)
    ).map(p => ({ ...p, isSuggested: true }));
    
    const combined = [...directMatches, ...relatedFromCategories, ...remainingProducts];
    return combined.slice(0, 15);
  })();

  if (!currentUser) {
    return (
      <LoginPage 
        onLoginSuccess={(user) => {
          localStorage.setItem("logistics_agent_user", JSON.stringify(user));
          setCurrentUser(user);
        }} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans flex flex-col selection:bg-cyan-200">
      
      {/* Sleek Modern Application Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-cyan-600 text-white rounded-xl shadow-xs">
                <PlaneTakeoff className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h1 className="text-sm sm:text-base font-extrabold text-slate-900 leading-none uppercase tracking-tight">
                  Global Carrier & Customs Estimator
                </h1>
                <p className="text-[10px] sm:text-xs text-slate-500 mt-1 font-medium">
                  Real-time IATA shipping, duty rate simulations & compliance verification
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {currentUser && (
                <div className="hidden sm:flex flex-col items-end text-right">
                  <span className="text-[11px] font-black text-slate-800 leading-none">{currentUser.name}</span>
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1 leading-none">{currentUser.role}</span>
                </div>
              )}

              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-100 uppercase tracking-wider">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Oracle Active
              </span>

              {currentUser && (
                <button
                  onClick={handleLogout}
                  className="px-2.5 py-1.5 text-[10px] font-extrabold bg-slate-100 hover:bg-slate-200 text-slate-650 rounded-lg uppercase tracking-wider transition-all cursor-pointer border border-slate-200"
                >
                  Sign Out
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Container Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 sm:px-6 lg:px-8 space-y-6">
        
        {/* Amazon style Cyan glowing mini alerts ticker */}
        <div className="bg-cyan-900 border border-cyan-800 text-cyan-100 px-4 py-3 rounded-xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
            </span>
            <span className="font-semibold tracking-wide uppercase text-cyan-400">Logistics Alert Feed:</span>
            <span>Real-time duty & compliance regulations synced for 2026.</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-cyan-300">
            <span>Exchange rates: 1 USD = 83.33 INR | 0.80 GBP | 1.37 CAD</span>
          </div>
        </div>

        {/* New Interactive Currency Rates & Prohibited Status Sub-Bar */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden p-5 space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between border-b border-slate-100 pb-4 gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="p-1 bg-cyan-50 text-cyan-600 rounded-lg">
                  <TrendingUp className="w-4 h-4 text-cyan-600 animate-pulse" />
                </div>
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Global Currency Rates & Customs Restrictions Explorer
                </h2>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                Select a country code to view active exchange rates, tax specifications, and customs prohibitions.
              </p>
            </div>
            
            {/* Country Selector Mini Navbar Tabs */}
            <div className="flex flex-wrap gap-1 bg-slate-50 border border-slate-150 p-1 rounded-xl shrink-0 self-start lg:self-auto">
              {countries.length > 0 ? (
                countries.map(c => (
                  <button
                    key={c.code}
                    onClick={() => {
                      setSelectedComplianceCountry(c.code);
                      // Clear search when switching country
                      setComplianceSearchItem("");
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                      selectedComplianceCountry === c.code
                        ? "bg-slate-900 text-white shadow-xs"
                        : "text-slate-600 hover:text-slate-900 hover:bg-slate-200/50"
                    }`}
                  >
                    <span>
                      {c.code === "US" ? "🇺🇸" : 
                       c.code === "IN" ? "🇮🇳" : 
                       c.code === "GB" ? "🇬🇧" : 
                       c.code === "CA" ? "🇨🇦" : 
                       c.code === "AU" ? "🇦🇺" : 
                       c.code === "DE" ? "🇩🇪" : 
                       c.code === "JP" ? "🇯🇵" : "🌐"}
                    </span>
                    <span>{c.code}</span>
                  </button>
                ))
              ) : (
                <div className="text-[11px] text-slate-400 py-1.5 px-3">Loading rates...</div>
              )}
            </div>
          </div>

          {/* Details Panel representing Selected Country */}
          {complianceCountryData && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs text-slate-650 pt-1">
              
              {/* Box 1: Currency & Exchange Rate info */}
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center gap-1.5 text-slate-800 font-bold uppercase tracking-wide text-[10px]">
                  <DollarSign className="w-3.5 h-3.5 text-cyan-600" />
                  <span>Currency & Rate</span>
                </div>
                <div className="space-y-1">
                  <div className="text-base font-black text-slate-900 tracking-tight flex items-baseline gap-1">
                    <span>{complianceCountryData.currency} ({complianceCountryData.symbol})</span>
                  </div>
                  <div className="text-[11px] font-mono font-bold text-slate-500 mt-0.5 space-y-0.5 leading-tight">
                    <div>1 USD = {(1 / (complianceCountryData.rateToUSD || 1)).toFixed(2)} {complianceCountryData.currency}</div>
                    <div>1 {complianceCountryData.currency} = {complianceCountryData.rateToUSD.toFixed(4)} USD</div>
                  </div>
                </div>
              </div>

              {/* Box 2: DeMinimis Threshold limits */}
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center gap-1.5 text-slate-800 font-bold uppercase tracking-wide text-[10px]">
                  <Scale className="w-3.5 h-3.5 text-cyan-600" />
                  <span>De-Minimis Limit</span>
                </div>
                <div className="space-y-1">
                  <div className="text-base font-black text-slate-900 tracking-tight">
                    ${complianceCountryData.deMinimis} USD
                  </div>
                  <p className="text-[10px] text-slate-500 leading-normal font-medium">
                    Import values below this limit enter free of standard duty assessment.
                  </p>
                </div>
              </div>

              {/* Box 3: Tax structure (VAT/GST Rate) */}
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center gap-1.5 text-slate-800 font-bold uppercase tracking-wide text-[10px]">
                  <FileCheck className="w-3.5 h-3.5 text-cyan-600" />
                  <span>VAT / GST Rate</span>
                </div>
                <div className="space-y-1">
                  <div className="text-base font-black text-slate-900 tracking-tight">
                    {complianceCountryData.vatRate}%
                  </div>
                  <p className="text-[10px] text-slate-500 leading-normal font-medium">
                    National value-added tax/GST applied to items exceeding de-minimis limits.
                  </p>
                </div>
              </div>

              {/* Box 4: Restrictions & Prohibited item search */}
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-3.5 flex flex-col justify-between gap-3">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5 text-slate-800 font-bold uppercase tracking-wide text-[10px]">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-500" />
                    <span>Restrictions Search</span>
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      className="w-full bg-white border border-slate-200 rounded-lg py-1 px-2 py-1.5 pl-7 text-[11px] focus:outline-none focus:border-cyan-500 font-semibold"
                      placeholder="Check item (e.g. used, satellite...)"
                      value={complianceSearchItem}
                      onChange={(e) => setComplianceSearchItem(e.target.value)}
                    />
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  </div>
                </div>

                {complianceSearchItem.trim() ? (
                  (() => {
                    const query = complianceSearchItem.toLowerCase().trim();
                    const generalRestrictedKeywords = [
                      "drug", "drugs", "narcotic", "narcotics", "stimulant", "stimulants", "medicine", "medicines", "prescription", "pill", "pills", "medication", "medications",
                      "oil", "oils", "liquid", "liquids", "fuel", "fuels", "gas", "petrol", "diesel", "petroleum", "gasoline", "flammable", "combustible",
                      "weapon", "weapons", "knife", "knives", "gun", "guns", "blade", "blades", "explosive", "explosives", "bullet", "bullets", "firearm", "firearms", "ammunition", "bomb", "bombs", "grenade", "dagger",
                      "aerosol", "aerosols", "spray", "sprays", "coolant", "coolants", "chemical", "chemicals", "poison", "vape", "vapes", "vaping"
                    ];
                    
                    const isGeneralAirportRestricted = generalRestrictedKeywords.some(keyword => {
                      return query.includes(keyword) || keyword.includes(query);
                    });

                    const match = complianceCountryData.restrictedItems.some(item => 
                      item.toLowerCase().includes(query)
                    ) || (query === "india" && complianceCountryData.code === "IN")
                      || (query === "us" && complianceCountryData.code === "US")
                      || isGeneralAirportRestricted;
                    
                    return match ? (
                      <div className="bg-rose-50 border border-rose-200 text-rose-800 p-2 rounded-lg text-[10px] font-extrabold flex flex-col gap-1">
                        <div className="flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-650 shrink-0 animate-pulse" />
                          <span>🚫 Restrictive Import Rules Apply</span>
                        </div>
                        {isGeneralAirportRestricted && (
                          <span className="text-[9px] text-rose-700 font-semibold leading-normal">
                            Air security threat category detected (drugs, flammable oils, aerosols, liquids, or weapons).
                          </span>
                        )}
                      </div>
                    ) : (
                      <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-2 rounded-lg text-[10px] font-extrabold flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-650 shrink-0" />
                        <span>✅ Permitted with standard declaration</span>
                      </div>
                    );
                  })()
                ) : (
                  <div className="text-[10px] text-slate-400 font-medium italic">
                    Type item keyword to test border compliance flags.
                  </div>
                )}
              </div>

              {/* Sub-bar showing Prohibited items list for the selected country */}
              <div className="col-span-1 sm:col-span-2 lg:col-span-4 bg-slate-50 border border-slate-150 p-3 rounded-xl text-[11px] flex flex-col md:flex-row md:items-center gap-3 justify-between">
                <div className="flex items-center gap-1.5 font-bold text-slate-700 shrink-0 uppercase tracking-wide text-[10px]">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span>Prohibited & Restricted Items in {complianceCountryData.name}:</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {complianceCountryData.restrictedItems.map((item, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 border border-rose-100 font-bold text-[10px] flex items-center gap-1"
                    >
                      <span className="text-[8px]">🚫</span> {item}
                    </span>
                  ))}
                </div>
              </div>

            </div>
          )}
        </div>

        {/* Global Multi-Bar Navigation Layout (Cyan Theme Accent) */}
        <div className="bg-white border border-slate-200 rounded-2xl p-2.5 shadow-xs">
          <ul className="flex flex-wrap gap-1.5" id="logistics-navigation-bar">
            
            <li>
              <button
                id="nav-tab-shop-items"
                onClick={() => { setActiveTab("items"); setFeedbackError(null); }}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  activeTab === "items" 
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/10" 
                    : "text-slate-600 hover:text-slate-950 hover:bg-slate-50"
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>1. Browse Global Items</span>
                <span className="bg-cyan-100 text-cyan-800 text-[10px] px-1.5 py-0.2 rounded-full font-bold ml-1">
                  {allProducts.length}
                </span>
              </button>
            </li>

            <li>
              <button
                id="nav-tab-estimator"
                onClick={() => { setActiveTab("estimator"); setFeedbackError(null); }}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  activeTab === "estimator" 
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/10" 
                    : "text-slate-600 hover:text-slate-950 hover:bg-slate-50"
                }`}
              >
                <Calculator className="w-4 h-4" />
                <span>2. Customs Estimator Pipeline</span>
                {activeResult && (
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] px-1.5 py-0.2 rounded-full font-bold ml-1">
                    Ready
                  </span>
                )}
              </button>
            </li>

            <li>
              <button
                id="nav-tab-cart-panel"
                onClick={() => { setActiveTab("cart"); setFeedbackError(null); }}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  activeTab === "cart" 
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/10" 
                    : "text-slate-600 hover:text-slate-950 hover:bg-slate-50"
                }`}
              >
                <Layers className="w-4 h-4" />
                <span>3. Combined Freight Cart</span>
                <span className={`text-[10px] px-2 py-0.2 rounded-full font-bold ml-1 ${
                  cartItems.length > 0 
                    ? "bg-cyan-500 text-white" 
                    : "bg-slate-100 text-slate-500"
                }`}>
                  {cartItems.reduce((acc, curr) => acc + curr.quantity, 0)}
                </span>
              </button>
            </li>

            <li>
              <button
                id="nav-tab-policy-insights"
                onClick={() => { setActiveTab("insights"); setFeedbackError(null); }}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  activeTab === "insights" 
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/10" 
                    : "text-slate-600 hover:text-slate-950 hover:bg-slate-50"
                }`}
              >
                <Sliders className="w-4 h-4" />
                <span>4. Admin Control Playground</span>
                <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.2 rounded-full font-bold ml-1">
                  Active
                </span>
              </button>
            </li>
            
          </ul>
        </div>

        {/* Error segment */}
        {feedbackError && (
          <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded-xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-bold text-red-800">Logistics Calculation Interruption</h3>
              <p className="text-xs text-red-700 mt-0.5">{feedbackError}</p>
            </div>
          </div>
        )}

        {/* TAB 1: Shopping Storefront View (Amazon visual style) */}
        {activeTab === "items" && (
          <div className="space-y-6">
            
            {/* Header with Search and Instructions */}
            <div className="bg-gradient-to-r from-slate-900 to-cyan-950 p-6 rounded-2xl border border-cyan-800 shadow-lg text-white flex flex-col md:flex-row md:items-center justify-between gap-6 font-sans">
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest block">Cross-Border E-Commerce Market</span>
                <h2 className="text-2xl font-bold tracking-tight">Interactive Global Storefront</h2>
                <p className="text-slate-300 text-xs sm:text-sm max-w-xl">
                  Select key consumer goods imported from international hubs. Tap an item to auto-populate the duty estimators, or add multiple objects to your combined freight cart to simulate consolidated customs clearance.
                </p>
              </div>

              {/* Dynamic Theme Filter Search bar */}
              <div className="relative w-full md:w-80 shrink-0">
                <span className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-400">
                  <Search className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  placeholder="Filter local storefront stock..."
                  value={itemSearchQuery}
                  onChange={(e) => setItemSearchQuery(e.target.value)}
                  className="w-full bg-slate-800/80 border border-slate-700 rounded-xl py-2 pl-9 pr-4 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                />
              </div>
            </div>

            {/* AI Product Specs Retriever widget (Real-time product specifications lookup) */}
            <div className="bg-white border border-cyan-150 rounded-2xl shadow-xs overflow-hidden border-l-4 border-l-cyan-600">
              <div className="p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5 uppercase tracking-wide">
                      <Search className="w-4 h-4 text-cyan-700" />
                      Global Product AI Specification Search & Add
                    </h3>
                    <p className="text-slate-500 text-xs mt-0.5">
                      Type <span className="font-semibold text-slate-700">whatever item you want</span> (e.g. <em>"Sony PlayStation 5 Pro"</em>, <em>"Dyson Airwrap Multi-Styler"</em>, or <em>"Orem Organic Matcha"</em>). Gemini AI will retrieve its standard weight, box dimensions, commercial category, and average retail price, letting you estimate or order it immediately!
                    </p>
                  </div>
                  <div className="shrink-0">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-50 text-cyan-700 border border-cyan-100">
                      <span className="h-1.5 w-1.5 rounded-full bg-cyan-500 animate-pulse"></span> Live Spec Engine
                    </span>
                  </div>
                </div>

                {/* Search bar and query trigger button */}
                <div className="flex gap-2.5">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      placeholder="Type any product in the world you want to import or estimate..."
                      value={globalSearchPhrase}
                      onChange={(e) => setGlobalSearchPhrase(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleGlobalSpecsSearch();
                      }}
                      className="w-full bg-slate-50 border border-slate-200 focus:bg-white rounded-xl py-2.5 pl-4 pr-12 text-xs font-semibold text-slate-900 placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
                    />
                    {globalSearchPhrase && (
                      <button
                        onClick={() => setGlobalSearchPhrase("")}
                        className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <button
                    onClick={handleGlobalSpecsSearch}
                    disabled={isGlobalLoading || !globalSearchPhrase.trim()}
                    className="bg-cyan-650 hover:bg-cyan-700 text-white px-5 rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5 shrink-0 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer h-10"
                  >
                    {isGlobalLoading ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Searching...</span>
                      </>
                    ) : (
                      <>
                        <Search className="w-3.5 h-3.5" />
                        <span>Retrieve Spec Rules</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Error status */}
                {globalSearchError && (
                  <div className="p-3 bg-red-50 text-red-700 border border-red-100 rounded-xl text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                    <span>{globalSearchError}</span>
                  </div>
                )}

                {/* Retrieved spec result preview panel */}
                {retrievedProducts.length > 0 && (
                  <div className="space-y-4 pt-1">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <span className="text-[11px] font-extrabold text-cyan-650 uppercase tracking-widest flex items-center gap-1.5">
                        <CheckCircle className="w-4 h-4 text-emerald-600 animate-pulse" />
                        Verified Specifications Found via Gemini API ({retrievedProducts.length})
                      </span>
                      <button
                        onClick={() => setRetrievedProducts([])}
                        className="text-slate-400 hover:text-rose-600 text-[11px] font-bold cursor-pointer transition-colors"
                      >
                        Clear All Results
                      </button>
                    </div>

                    <div className="space-y-4">
                      {retrievedProducts.map((p) => (
                        <motion.div
                          key={p.id}
                          initial={{ opacity: 0, y: 15 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-4 relative"
                        >
                          <div className="flex items-center justify-between border-b border-slate-150 pb-2">
                            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">
                              CATALOG REF: {p.id}
                            </span>
                            <button
                              onClick={() => setRetrievedProducts(prev => prev.filter(item => item.id !== p.id))}
                              className="text-slate-400 hover:text-rose-600 text-[10px] font-extrabold uppercase tracking-wide cursor-pointer transition-colors"
                            >
                              Dismiss Listing
                            </button>
                          </div>

                          <div className="flex flex-col md:flex-row items-start gap-4">
                            {/* Photo area */}
                            <div className="w-24 h-24 rounded-xl bg-white border border-slate-200 overflow-hidden shrink-0 shadow-sm">
                              <img
                                src={p.image}
                                alt={p.name}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                            </div>

                            {/* Info layout */}
                            <div className="flex-1 space-y-2">
                              <div>
                                <div className="flex flex-wrap items-center gap-2">
                                  <h4 className="font-extrabold text-slate-900 text-sm">{p.name}</h4>
                                  <span className="px-2 py-0.5 text-[9px] font-bold bg-cyan-100 text-cyan-800 rounded-full select-none">
                                    {p.category}
                                  </span>
                                </div>
                                <span className="text-cyan-600 text-xs block font-semibold mt-0.5">{p.tagline}</span>
                              </div>
                              <p className="text-slate-500 text-[11px] leading-relaxed max-w-2xl">{p.description}</p>
                            </div>

                            {/* Spec metrics details */}
                            <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-xs border border-slate-200 bg-white p-3.5 rounded-xl w-full md:w-auto md:min-w-[240px] shrink-0">
                              <div>
                                <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Estimated Price</span>
                                <span className="font-extrabold text-slate-900 text-sm">${p.priceUSD} USD</span>
                              </div>
                              <div>
                                <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Est. Weight</span>
                                <span className="font-extrabold text-slate-900 text-sm">{p.weightKg} kg</span>
                              </div>
                              <div className="col-span-2 pt-1 border-t border-slate-100 mt-1">
                                <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider font-semibold">Standard Package Sizing</span>
                                <span className="font-bold text-slate-700 font-mono text-[11px] block mt-0.5">
                                  {p.lengthCm} × {p.widthCm} × {p.heightCm} CM
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Quick spec trigger actions */}
                          <div className="pt-2 border-t border-slate-200 flex flex-wrap gap-2 justify-end">
                            <button
                              onClick={() => {
                                const updatedFormInput: CalculationInput = {
                                  originCode: "US",
                                  destinationCode: "IN",
                                  category: p.category,
                                  declaredValue: p.priceUSD,
                                  valueCurrency: "USD",
                                  weight: p.weightKg,
                                  weightUnit: "kg",
                                  length: p.lengthCm,
                                  width: p.widthCm,
                                  height: p.heightCm,
                                  dimensionUnit: "cm",
                                  shippingMode: "express"
                                };
                                setFormInput(updatedFormInput);
                                setItemDescription(`${p.name} - ${p.tagline}`);
                                setActiveTab("estimator");
                                handleCalculate(updatedFormInput, `${p.name} - ${p.tagline}`);
                              }}
                              className="py-1.5 px-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-850 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                            >
                              <Calculator className="w-3.5 h-3.5 text-cyan-600" />
                              <span>Estimate Customs Now</span>
                            </button>

                            <button
                              onClick={() => {
                                setCustomProducts(prev => {
                                  const exists = prev.some(item => item.name.toLowerCase() === p.name.toLowerCase());
                                  if (exists) {
                                    alert(`"${p.name}" is already saved in your local e-commerce storefront collection below!`);
                                    return prev;
                                  }
                                  alert(`Saved "${p.name}" to your local e-commerce storefront collection below! You can now browse or filter it locally.`);
                                  return [p, ...prev];
                                });
                              }}
                              className="py-1.5 px-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-850 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                            >
                              <Plus className="w-3.5 h-3.5 text-cyan-600" />
                              <span>Save to Storefront Stock</span>
                            </button>

                            <button
                              onClick={() => {
                                addProductToCart(p);
                              }}
                              className="py-1.5 px-3 bg-cyan-650 hover:bg-cyan-750 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1"
                            >
                              <ShoppingBag className="w-3.5 h-3.5" />
                              <span>Add to Consolidated Cart</span>
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Active Wishlist section */}
            {wishlist.length > 0 && (
              <div className="bg-white border border-slate-200 rounded-2xl shadow-xs p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5 font-sans">
                    <Heart className="w-4 h-4 text-rose-500 fill-rose-500 animate-pulse" />
                    My Shopping Wishlist ({wishlist.length})
                  </h3>
                  <button
                    onClick={() => {
                      setWishlist([]);
                      localStorage.setItem("logistics_agent_wishlist", JSON.stringify([]));
                    }}
                    className="text-[10px] font-bold text-slate-400 hover:text-rose-600 transition-colors uppercase cursor-pointer"
                  >
                    Clear Wishlist
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {wishlist.map(rawP => {
                    const p = getAdjustedProduct(rawP);
                    return (
                      <div
                        key={`wish-${p.id}`}
                        onClick={() => setSelectedProductDetails(p)}
                        className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 flex flex-col justify-between space-y-2 cursor-pointer hover:border-cyan-400 hover:bg-slate-100/50 transition-all group relative"
                      >
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleWishlist(rawP);
                          }}
                          className="absolute top-1.5 right-1.5 p-1 rounded-full bg-white text-slate-400 hover:text-rose-600 shadow-xs border border-slate-150 transition-all opacity-0 group-hover:opacity-100 z-10"
                          title="Remove item"
                        >
                          <X className="w-3 h-3" />
                        </button>

                        <div className="space-y-1.5">
                          <div className="aspect-square rounded-lg bg-white overflow-hidden border border-slate-200 shrink-0">
                            <img
                              src={p.image}
                              alt={p.name}
                              className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-900 text-[11px] truncate leading-tight">
                              {p.name}
                            </h4>
                            <span className="text-[9px] text-cyan-600 font-bold block truncate">
                              {p.tagline}
                            </span>
                          </div>
                        </div>

                        <div className="pt-1.5 border-t border-slate-150 flex items-center justify-between">
                          <span className="text-[11px] font-black text-slate-800">
                            ${p.priceUSD}
                          </span>
                          <span className="text-[9px] text-slate-400 font-bold">
                            {p.weightKg} kg
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Product Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.map(product => (
                <div 
                  key={product.id} 
                  id={`product-card-${product.id}`}
                  className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-300 flex flex-col group"
                >
                  
                  {/* Photo area with beautiful hover effect and details click */}
                  <div 
                    onClick={() => setSelectedProductDetails(product)}
                    className="relative h-48 bg-slate-100 overflow-hidden shrink-0 cursor-pointer"
                  >
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1 z-10">
                      <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-white/95 text-slate-900 shadow-sm border border-slate-100">
                        {product.category}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-cyan-600 text-white shadow-s">
                        US Hub
                      </span>
                      {(product as any).isSuggested && (
                        <span className="px-2 py-0.5 rounded text-[9px] font-extrabold bg-amber-500 text-white shadow-sm">
                          Related Idea
                        </span>
                      )}
                    </div>

                    {/* Wishlist Toggle Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleWishlist(product);
                      }}
                      className="absolute top-3 right-3 p-1.5 rounded-full bg-white/95 text-slate-400 hover:text-rose-600 hover:scale-110 shadow-xs border border-slate-100 transition-all cursor-pointer z-20"
                      title={wishlist.some(item => item.id === product.id) ? "Remove from Wishlist" : "Add to Wishlist"}
                    >
                      <Heart 
                        className={`w-3.5 h-3.5 transition-colors ${
                          wishlist.some(item => item.id === product.id)
                            ? "fill-rose-500 text-rose-500"
                            : "text-slate-400"
                        }`}
                      />
                    </button>
                  </div>

                  {/* Product Metadata */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                    <div 
                      onClick={() => setSelectedProductDetails(product)}
                      className="space-y-1.5 cursor-pointer"
                    >
                      <div className="flex items-start justify-between gap-1">
                        <h3 className="font-bold text-slate-950 text-sm tracking-tight leading-tight group-hover:text-cyan-600 transition-colors">
                          {product.name}
                        </h3>
                      </div>
                      <span className="text-[11px] text-cyan-600 block font-semibold">
                        {product.tagline}
                      </span>
                      <p className="text-slate-500 text-[11px] leading-relaxed line-clamp-2">
                        {product.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-100">
                      <div className="flex items-center justify-between gap-1 mb-3">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Landed Base Price</span>
                          <span className="text-sm font-extrabold text-slate-900 font-mono">
                            ${product.priceUSD.toLocaleString()} <span className="text-[10px] text-slate-500 font-normal">USD</span>
                          </span>
                        </div>
                        <div className="text-right flex flex-col items-end">
                          <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Custom Weight (Max 5)</span>
                          <div 
                            className="flex items-center gap-1 mt-0.5 bg-slate-50 border border-slate-200 rounded-lg px-1.5 py-0.5"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                adjustProductWeight(product, Math.max(0.01, product.weightKg - 1));
                              }}
                              className="text-xs w-4 h-4 flex items-center justify-center font-extrabold text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 rounded-sm cursor-pointer transition-colors"
                              title="Decrease 1 kg"
                            >
                              -
                            </button>
                            <div className="flex items-center" onClick={(e) => e.stopPropagation()}>
                              <input
                                type="number"
                                step="0.1"
                                min="0.01"
                                max="5"
                                value={product.weightKg || ""}
                                onChange={(e) => {
                                  e.stopPropagation();
                                  const val = parseFloat(e.target.value);
                                  if (!isNaN(val)) {
                                    adjustProductWeight(product, val > 5 ? 5 : val);
                                  }
                                }}
                                className="w-10 bg-transparent text-slate-950 border-none outline-hidden text-center text-[11px] font-black font-mono focus:ring-0 p-0"
                                title="Type weight (max 5 kg)"
                              />
                              <span className="text-[10px] text-cyan-600 font-bold font-mono">kg</span>
                            </div>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                adjustProductWeight(product, Math.min(5, product.weightKg + 1));
                              }}
                              className="text-xs w-4 h-4 flex items-center justify-center font-extrabold text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 rounded-sm cursor-pointer transition-colors"
                              title="Increase 1 kg"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          id={`btn-est-${product.id}`}
                          onClick={() => selectProductToEstimate(product)}
                          className="w-full py-2 px-1.5 text-[11px] font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer text-center"
                        >
                          Estimate Customs
                        </button>
                        
                        <button
                          id={`btn-cart-${product.id}`}
                          onClick={() => addProductToCart(product)}
                          className="w-full py-2 px-1.5 text-[11px] font-semibold text-white bg-cyan-600 hover:bg-cyan-700 rounded-lg transition-all cursor-pointer text-center"
                        >
                          Add to Cart
                        </button>
                      </div>
                    </div>
                  </div>

                </div>
              ))}
              
              {filteredProducts.length === 0 && (
                <div className="col-span-full bg-white border border-slate-200 p-12 rounded-2xl text-center space-y-3">
                  <ShoppingBag className="w-9 h-9 text-slate-300 mx-auto" />
                  <h3 className="text-slate-800 font-bold text-sm">No items match your search.</h3>
                  <p className="text-xs text-slate-500">Try searching "iPhone", "Matcha", or selecting another category.</p>
                </div>
              )}
            </div>

          </div>
        )}

        {/* TAB 2: Dynamic Customs Estimator Pipeline */}
        {activeTab === "estimator" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Column Left: Input Forms Segment */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Main Inputs Card */}
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                
                <div className="bg-cyan-900 p-4 border-b border-cyan-800 text-white flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-5 h-5 text-cyan-400 animate-pulse" />
                    <div>
                      <h3 className="text-sm font-bold tracking-tight">Customs Valuation & Logistics</h3>
                      <p className="text-[10px] text-cyan-200 font-medium">Cross-Border E-Commerce Calculator Mode</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold uppercase bg-cyan-800 px-2 py-0.5 rounded text-cyan-200 border border-cyan-700/50">
                    V2026 Engine
                  </span>
                </div>

                <div className="p-5 space-y-4">
                  
                  {/* Origin & Destination Ports */}
                  <div className="grid grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Origin Country Hub
                      </label>
                      <select
                        id="form-origin-country"
                        value={formInput.originCode}
                        onChange={(e) => setFormInput({ ...formInput, originCode: e.target.value })}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-cyan-500 transition-colors"
                      >
                        {countries.map(c => (
                          <option key={`orig-${c.code}`} value={c.code}>
                            🇺🇸/✈️ {c.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Destination Country
                      </label>
                      <select
                        id="form-destination-country"
                        value={formInput.destinationCode}
                        onChange={(e) => setFormInput({ ...formInput, destinationCode: e.target.value })}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-cyan-500 transition-colors"
                      >
                        {countries.map(c => (
                          <option key={`dest-${c.code}`} value={c.code}>
                            🏁/📥 {c.name} ({c.currency})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Declared Value & Commodity Group */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5">
                    
                    <div className="md:col-span-7">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                        <span>Declared Item Value</span>
                        <span className="text-[10px] font-semibold text-slate-400">USD Equivalent</span>
                      </label>
                      
                      <div className="relative">
                        <span className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-450 font-bold text-xs">
                          $
                        </span>
                        <input
                          id="form-declared-value"
                          type="number"
                          min="1"
                          max="100000"
                          value={formInput.declaredValue}
                          onChange={(e) => setFormInput({ ...formInput, declaredValue: parseFloat(e.target.value) || 0 })}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-7 pr-3 text-xs font-semibold focus:outline-none focus:border-cyan-500 transition-colors"
                        />
                      </div>
                    </div>

                    <div className="md:col-span-5">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Category (HS Rule)
                      </label>
                      <select
                        id="form-item-category"
                        value={formInput.category}
                        onChange={(e) => setFormInput({ ...formInput, category: e.target.value as ItemCategory })}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-2 text-[11px] font-semibold focus:outline-none focus:border-cyan-500 transition-colors"
                      >
                        {Object.values(ItemCategory).map(cat => (
                          <option key={`cat-${cat}`} value={cat}>
                            {cat}
                          </option>
                        ))}
                      </select>
                    </div>

                  </div>

                  {/* Package Weight Segments */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex justify-between">
                        <span>Actual Package Weight</span>
                        <span className="text-[10px] text-cyan-600 font-bold font-mono">Max: 5.00 kg</span>
                      </label>
                      <input
                        id="form-package-weight"
                        type="number"
                        step="0.01"
                        min="0.01"
                        max="5"
                        value={formInput.weight}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          if (val > 5) {
                            setFormInput({ ...formInput, weight: 5 });
                          } else {
                            setFormInput({ ...formInput, weight: isNaN(val) ? 0 : val });
                          }
                        }}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-cyan-500 transition-colors font-mono"
                        placeholder="e.g. 1.50"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Weight Unit
                      </label>
                      <div className="grid grid-cols-2 bg-slate-50 border border-slate-200 rounded-xl p-1">
                        <button
                          type="button"
                          onClick={() => setFormInput({ ...formInput, weightUnit: "kg" })}
                          className={`py-1 text-center text-[10px] sm:text-xs font-bold rounded-md cursor-pointer ${
                            formInput.weightUnit === "kg" ? "bg-white text-cyan-600 shadow-xs border border-slate-100" : "text-slate-500 hover:text-slate-800"
                          }`}
                        >
                          KG
                        </button>
                        <button
                          type="button"
                          onClick={() => setFormInput({ ...formInput, weightUnit: "lb" })}
                          className={`py-1 text-center text-[10px] sm:text-xs font-bold rounded-md cursor-pointer ${
                            formInput.weightUnit === "lb" ? "bg-white text-cyan-600 shadow-xs border border-slate-100" : "text-slate-500 hover:text-slate-800"
                          }`}
                        >
                          LB
                        </button>
                      </div>
                    </div>

                  </div>

                  {/* Package Dimensions Segment */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                        Box Dimensions (Length × Width × Height)
                      </label>
                      <div className="inline-flex bg-slate-50 border border-slate-200 rounded-lg p-0.5">
                        <button
                          type="button"
                          onClick={() => setFormInput({ ...formInput, dimensionUnit: "cm" })}
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-all ${
                            formInput.dimensionUnit === "cm" ? "bg-white text-cyan-600 shadow-3xs" : "text-slate-500"
                          }`}
                        >
                          CM
                        </button>
                        <button
                          type="button"
                          onClick={() => setFormInput({ ...formInput, dimensionUnit: "in" })}
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-all ${
                            formInput.dimensionUnit === "in" ? "bg-white text-cyan-600 shadow-3xs" : "text-slate-500"
                          }`}
                        >
                          IN
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2.5">
                      <div className="relative">
                        <span className="absolute right-2.5 top-2 text-[10px] font-semibold text-slate-400">L</span>
                        <input
                          id="form-dim-length"
                          type="number"
                          min="1"
                          value={formInput.length}
                          onChange={(e) => setFormInput({ ...formInput, length: parseInt(e.target.value) || 1 })}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-3 pr-6 text-xs font-semibold focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                      <div className="relative">
                        <span className="absolute right-2.5 top-2 text-[10px] font-semibold text-slate-400">W</span>
                        <input
                          id="form-dim-width"
                          type="number"
                          min="1"
                          value={formInput.width}
                          onChange={(e) => setFormInput({ ...formInput, width: parseInt(e.target.value) || 1 })}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-3 pr-6 text-xs font-semibold focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                      <div className="relative">
                        <span className="absolute right-2.5 top-2 text-[10px] font-semibold text-slate-400">H</span>
                        <input
                          id="form-dim-height"
                          type="number"
                          min="1"
                          value={formInput.height}
                          onChange={(e) => setFormInput({ ...formInput, height: parseInt(e.target.value) || 1 })}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-3 pr-6 text-xs font-semibold focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Level of Service and Clearances Selection */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Logistics Shipping Method
                    </label>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        id="btn-ship-mode-standard"
                        onClick={() => setFormInput({ ...formInput, shippingMode: "standard" })}
                        className={`p-3 text-left rounded-xl border transition-all cursor-pointer flex flex-col justify-between h-20 ${
                          formInput.shippingMode === "standard"
                            ? "border-cyan-400 bg-cyan-50/50 ring-1 ring-cyan-400 text-slate-900" 
                            : "border-slate-200 hover:bg-slate-50 text-slate-650"
                        }`}
                      >
                        <div className="flex items-center gap-1.5 text-xs font-bold">
                          <Truck className="w-4 h-4 text-slate-500" />
                          <span>Standard Logistics</span>
                        </div>
                        <div className="text-[10px] text-slate-500 leading-normal">
                          Estimated 7-12 days shipping. Safe ocean/ground mix clearance.
                        </div>
                      </button>

                      <button
                        type="button"
                        id="btn-ship-mode-express"
                        onClick={() => setFormInput({ ...formInput, shippingMode: "express" })}
                        className={`p-3 text-left rounded-xl border transition-all cursor-pointer flex flex-col justify-between h-20 ${
                          formInput.shippingMode === "express"
                            ? "border-cyan-500 bg-cyan-50/50 ring-1 ring-cyan-500 text-slate-900" 
                            : "border-slate-200 hover:bg-slate-50 text-slate-650"
                        }`}
                      >
                        <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-700">
                          <PlaneTakeoff className="w-4 h-4 text-cyan-600" />
                          <span>Express Courier</span>
                        </div>
                        <div className="text-[10px] text-slate-500 leading-normal">
                          Airport priority 4-7 business days. High priority broker clearance.
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* Specific Product Description for Gemini Custom classification */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                      <span>Item Product Details (AI Advisory Input)</span>
                      <span className="bg-cyan-100 text-cyan-800 text-[9px] px-1.5 py-0.2 rounded font-bold uppercase tracking-wider">
                        Deep Advisor Feature
                      </span>
                    </label>
                    <textarea
                      id="form-ai-details-text"
                      rows={2}
                      value={itemDescription}
                      onChange={(e) => setItemDescription(e.target.value)}
                      placeholder="e.g., iPhone 15 Pro, containing internal lithium metal batteries, original sealed box."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-cyan-500 placeholder-slate-400 focus:bg-white resize-none"
                    />
                  </div>

                  <button
                    id="submit-logistics-estimation-btn"
                    onClick={() => handleCalculate()}
                    disabled={isCalculating}
                    className="w-full mt-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-bold py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer text-xs uppercase"
                  >
                    {isCalculating ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-white" />
                        <span>Evaluating Logistics pipeline...</span>
                      </>
                    ) : (
                      <>
                        <Calculator className="w-4 h-4" />
                        <span>Calculate Landed Cost & AI Rules</span>
                      </>
                    )}
                  </button>

                </div>
              </div>

              {/* Package Volumetric Helper box */}
              <div className="bg-slate-900 border border-slate-800 p-4.5 rounded-2xl text-slate-400 text-[11px] space-y-3">
                <div className="flex items-center gap-2 text-slate-200 font-bold text-xs uppercase tracking-wider">
                  <Info className="w-4 h-4 text-cyan-400" />
                  <span>Logistics Mathematical Rule</span>
                </div>
                <p className="leading-relaxed">
                  International freight applies the **Chargeable Weight Rule**. This represents the larger calculation comparing the physical weight against the volume weight:
                </p>
                <div className="bg-slate-950 p-2.5 rounded-lg font-mono text-cyan-300 text-center border border-slate-850/50">
                  Volumetric (kg) = (Length × Width × Height in CM) / 5,000
                </div>
                <div className="flex items-center justify-between text-slate-300 border-t border-slate-800 pt-2 text-[10px]">
                  <span>Formula used: standard (CIF) bases</span>
                  <span className="text-cyan-400">IATA Standard Compliant</span>
                </div>
              </div>

            </div>

            {/* Column Right: Interactive Cost Share Charts & Timeline Indicators */}
            <div className="lg:col-span-7 space-y-6">
              
              {!activeResult && !isCalculating ? (
                <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-4">
                  <div className="w-16 h-16 bg-cyan-50 rounded-full flex items-center justify-center mx-auto text-cyan-600">
                    <Calculator className="w-8 h-8" />
                  </div>
                  <h3 className="text-slate-800 font-extrabold text-base">Estimator Database Ready</h3>
                  <p className="text-slate-500 text-xs max-w-md mx-auto leading-relaxed">
                    Fill the parameters in the left config segment and click the Calculate action. The platform will run real-time local calculations and connect with Gemini AI services.
                  </p>
                  
                  <div className="pt-2">
                    <button
                      onClick={() => handleCalculate()}
                      className="px-4 py-2 border border-cyan-200 text-cyan-600 text-xs font-semibold rounded-xl bg-cyan-50/50 hover:bg-cyan-50 cursor-pointer"
                    >
                      Preload Default Scenario
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  
                  {/* Phase 1: Output calculation values dashboard */}
                  <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                    
                    <div className="bg-gradient-to-r from-cyan-600 to-cyan-700 p-4 border-b border-cyan-800 text-white flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-cyan-100" />
                        <div>
                          <h3 className="text-xs font-bold uppercase tracking-wider">Evaluation Breakdown Result</h3>
                          <span className="text-[10px] text-cyan-100 tracking-wide font-medium">Landed Duty Paid (DDP) projection analysis</span>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <span className="text-[10px] text-cyan-200 block font-semibold">Destination currency:</span>
                        <span id="output-currency-code" className="text-xs font-bold font-mono tracking-wider">
                          {formInput.destinationCode === "IN" ? "INR" : "USD / Local"}
                        </span>
                      </div>
                    </div>

                    <div className="p-5 space-y-6">
                      
                      {/* Landing Total display */}
                      <div className="bg-cyan-50/35 border border-cyan-100 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div className="space-y-1 text-center sm:text-left">
                          <span className="text-xs text-slate-505 font-bold uppercase tracking-widest text-cyan-800 block">Total Landed Import Cost</span>
                          <span className="text-[11px] text-slate-450 block">Consolidated product value + duties + VAT + logistics fee</span>
                        </div>
                        
                        <div className="text-center sm:text-right space-y-0.5">
                          {bargayedCostUSD !== null && (bargainStatus === "approved" || bargainStatus === "countered") ? (
                            <>
                              <div className="flex items-center justify-center sm:justify-end gap-1.5 flex-wrap">
                                <span className="line-through text-slate-400 text-xs font-bold">
                                  {formInput.destinationCode === "IN" ? "₹" : "$"}
                                  {activeResult ? (formInput.destinationCode === "IN" ? activeResult.landedCostLocal.toLocaleString(undefined, {maximumFractionDigits: 2}) : activeResult.landedCostUSD.toLocaleString(undefined, {maximumFractionDigits: 2})) : "0.00"}
                                </span>
                                <span className={`px-1.5 py-0.5 text-[8px] font-black rounded-sm uppercase tracking-wider ${
                                  bargainStatus === "approved" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                                }`}>
                                  {bargainStatus === "approved" ? "Bargain Won" : "Proposed Counter"}
                                </span>
                              </div>
                              <h2 id="landed-cost-local-display" className="text-2xl sm:text-3xl font-black text-emerald-600 tracking-tight">
                                {formInput.destinationCode === "IN" ? "₹" : "$"}
                                {finalDisplayLandedCostLocal.toLocaleString(undefined, {maximumFractionDigits: 2})}
                              </h2>
                              <div id="landed-cost-usd-display" className="text-[10px] font-bold text-emerald-700">
                                Bargained rate: ${finalDisplayLandedCostUSD.toLocaleString(undefined, {maximumFractionDigits: 2})} (Saved ${bargainDiscountApplied.toFixed(0)} USD!)
                              </div>
                            </>
                          ) : (
                            <>
                              <h2 id="landed-cost-local-display" className="text-2xl sm:text-4xl font-extrabold text-cyan-700 tracking-tight">
                                {formInput.destinationCode === "IN" ? "₹" : "$"}
                                {activeResult ? (formInput.destinationCode === "IN" ? activeResult.landedCostLocal.toLocaleString(undefined, {maximumFractionDigits: 2}) : activeResult.landedCostUSD.toLocaleString(undefined, {maximumFractionDigits: 2})) : "0.00"}
                              </h2>
                              <div id="landed-cost-usd-display" className="text-xs font-bold text-slate-500">
                                USD rate: ${activeResult ? activeResult.landedCostUSD.toLocaleString(undefined, {maximumFractionDigits: 2}) : "0.00"}
                              </div>
                            </>
                          )}
                        </div>
                      </div>

                      {/* De-minimis rule indication badge */}
                      {activeResult?.isBelowDeMinimis ? (
                        <div className="p-3.5 bg-emerald-50 border border-emerald-100 rounded-xl flex items-start gap-3 text-xs text-emerald-800">
                          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.2" />
                          <div>
                            <span className="font-bold block">De-Minimis Duty exemption Active!</span>
                            <span className="text-[11px] text-emerald-700 block mt-0.5">
                              Declared total values fall below the threshold. Your parcel is exempted from local general customs duties & consumption taxes. Save big!
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="p-3.5 bg-amber-50 border border-amber-100 rounded-xl flex items-start gap-3 text-xs text-slate-850">
                          <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.2" />
                          <div>
                            <span className="font-bold text-slate-900 block">Duty Imposed (Exceeds De-Minimis Threshold)</span>
                            <span className="text-[11px] text-slate-650 block mt-0.5">
                              This shipment values exceed the regional free import limit. Government customs and taxation are fully formulated on CIF value.
                            </span>
                          </div>
                        </div>
                      )}

                      {/* Side by side: Specific Cost Segments Table & Custom SVG Doughnut */}
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                        
                        {/* Segments Table */}
                        <div className="md:col-span-7 space-y-2.5 text-xs text-slate-700">
                          
                          <div className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 transition-colors">
                            <span className="flex items-center gap-1.5 font-medium">
                              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
                              <span>Declared Item Price</span>
                            </span>
                            <span className="font-semibold text-slate-900">
                              ${formInput.declaredValue.toLocaleString()} USD
                            </span>
                          </div>

                          <div className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 transition-colors">
                            <span className="flex items-center gap-1.5 font-medium">
                              <span className="w-2.5 h-2.5 rounded-full bg-cyan-600"></span>
                              <span>Base Freight Charges</span>
                            </span>
                            <span className="font-semibold text-slate-900">
                              ${activeResult?.baseShippingCostUSD.toLocaleString()} USD
                            </span>
                          </div>

                          <div className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 transition-colors">
                            <span className="flex items-center gap-1.5 font-medium">
                              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>
                              <span>Import Government Duty ({formInput.destinationCode === "IN" ? "10%" : "Avg"})</span>
                            </span>
                            <span className="font-semibold text-slate-900">
                              ${activeResult?.dutyUSD.toLocaleString()} USD
                            </span>
                          </div>

                          <div className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 transition-colors text-slate-650">
                            <span className="flex items-center gap-1.5 font-medium">
                              <span className="w-2.5 h-2.5 rounded-full bg-pink-500"></span>
                              <span>Consumption TAX / GST / VAT</span>
                            </span>
                            <span className="font-semibold text-slate-900">
                              ${activeResult?.vatUSD.toLocaleString()} USD
                            </span>
                          </div>

                          <div className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 transition-colors">
                            <span className="flex items-center gap-1.5 font-medium text-slate-500">
                              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                              <span>Surcharges & Handling fees</span>
                            </span>
                            <span className="font-semibold text-slate-900">
                              ${activeResult ? (activeResult.fuelSurchargeUSD + activeResult.handlingFeeUSD).toFixed(2) : "0.00"} USD
                            </span>
                          </div>

                        </div>

                        {/* Pixel-designed Custom SVG breakdown Doughnut Graph */}
                        <div className="md:col-span-5 flex flex-col items-center justify-center p-3 text-center">
                          <div className="relative w-36 h-36">
                            
                            {/* SVG Donut implementation relative to percentages */}
                            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                              <circle cx="18" cy="18" r="15.915" fill="none" stroke="#e2e8f0" strokeWidth="3" />
                              
                              {/* Declared Value Segment (approx 60%) */}
                              <circle cx="18" cy="18" r="15.915" fill="none" stroke="#22d3ee" strokeWidth="4.2" 
                                      strokeDasharray="60 100" strokeDashoffset="0" />
                              
                              {/* Freight base Segment (approx 20%) */}
                              <circle cx="18" cy="18" r="15.915" fill="none" stroke="#0891b2" strokeWidth="4.2" 
                                      strokeDasharray="20 100" strokeDashoffset="-60" />
                              
                              {/* Duty segment (approx 12%) */}
                              <circle cx="18" cy="18" r="15.915" fill="none" stroke="#6366f1" strokeWidth="4.2" 
                                      strokeDasharray="12 100" strokeDashoffset="-80" />

                              {/* VAT & Surcharge (approx 8%) */}
                              <circle cx="18" cy="18" r="15.915" fill="none" stroke="#ec4899" strokeWidth="4.2" 
                                      strokeDasharray="8 100" strokeDashoffset="-92" />
                            </svg>

                            <div className="absolute inset-0 flex flex-col items-center justify-center">
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Share</span>
                              <span id="donut-item-percentage" className="text-lg font-bold font-mono text-cyan-600 mt-0.5">
                                {activeResult ? Math.round((formInput.declaredValue / activeResult.landedCostUSD) * 100) : "100"}%
                              </span>
                              <span className="text-[8px] text-slate-400 font-semibold leading-none mt-0.2">Declared</span>
                            </div>

                          </div>
                          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block mt-2">
                            Interactive Cost allocation proportions
                          </span>
                        </div>

                      </div>

                      {/* SECTION: INTEGRATE DELIVERY TIMELINE ESTIMATES */}
                      <div className="border-t border-slate-100 pt-5 space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Clock className="w-5 h-5 text-cyan-600" />
                            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                              Integrated Delivery Timeline (Standard vs Express)
                            </h4>
                          </div>
                          <span className="text-[10px] uppercase tracking-wider font-extrabold text-cyan-600 bg-cyan-50 px-2 py-0.5 rounded">
                            {formInput.shippingMode === "express" ? "Express Priority Air" : "Postal Standard Lane"}
                          </span>
                        </div>

                        {/* Visual Pipeline Slider Indicator */}
                        <div className="space-y-2">
                          <div className="flex justify-between text-[11px] font-bold text-slate-500">
                            <span>Shipment leaves hub</span>
                            <span>Customs check</span>
                            <span>Destination delivery</span>
                          </div>

                          <div className="relative pt-1">
                            <div className="overflow-hidden h-2.5 text-xs flex rounded-full bg-slate-100 border border-slate-150">
                              <div style={{ width: "30%" }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-cyan-400"></div>
                              <div style={{ width: formInput.shippingMode === "express" ? "45%" : "60%" }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-cyan-600"></div>
                              <div style={{ width: "10%" }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-cyan-500 animate-pulse"></div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-xs font-medium text-slate-650 bg-slate-50 p-3 rounded-xl border border-slate-150">
                            <div>
                              <span className="text-slate-450 block text-[10px] uppercase font-bold tracking-wider">Estimated Window</span>
                              <span id="logistics-estimated-days" className="text-sm font-bold text-cyan-700">
                                {activeResult?.timelineMinDays} – {activeResult?.timelineMaxDays} Business Days
                              </span>
                            </div>

                            <div className="text-right">
                              <span className="text-slate-450 block text-[10px] uppercase font-bold tracking-wider">Broker cleared velocity</span>
                              <span className="text-sm font-bold text-emerald-600 flex items-center gap-1 justify-end">
                                <CheckCircle className="w-3.5 h-3.5" /> High priority
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Smart incoterms recommendation card */}
                      {activeResult?.recommendation && (
                        <div className="p-4 bg-cyan-950 border border-cyan-800 text-white rounded-2xl flex items-start gap-3.5">
                          <div className="bg-cyan-900 border border-cyan-700/50 p-2.5 rounded-xl text-cyan-400 font-bold font-mono text-center shrink-0">
                            {activeResult.recommendation.incoterm}
                          </div>
                          
                          <div className="space-y-1.5 text-xs text-cyan-100 flex-1">
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-extrabold text-white text-[13px]">{activeResult.recommendation.title}</span>
                              <span className="bg-cyan-800/80 text-cyan-300 font-extrabold text-[9px] px-2 py-0.5 rounded-full border border-cyan-700/50">
                                Confidence: {activeResult.recommendation.score}%
                              </span>
                            </div>
                            <p className="text-[11px] leading-relaxed text-slate-300">
                              {activeResult.recommendation.description}
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Interactive Cargo Bargaining Segment */}
                      <div className="border-t border-slate-100 pt-5 space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="p-1 px-2 text-[10px] bg-cyan-100 text-cyan-800 font-extrabold rounded-md uppercase font-mono">Negotiate</span>
                            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                              AI Landed Price Bargaining Broker
                            </h4>
                          </div>
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                            Attempts: {bargainAttempts}/3
                          </span>
                        </div>

                        <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl space-y-4">
                          <div className="flex items-start gap-3">
                            <div className="w-8 h-8 bg-cyan-900 border border-cyan-700/50 rounded-xl flex items-center justify-center text-cyan-300 shrink-0 select-none">
                              🤖
                            </div>
                            <div className="space-y-1">
                              <span className="text-xs font-bold text-slate-800 block">Lead Cargo Arbitrage Officer:</span>
                              <p className="text-[11px] text-slate-500 leading-relaxed">
                                Statutory regulatory duties and regional VAT represent sovereign taxation and cannot be revised. However, I can manually waive our high-volume surcharges and logistics commissions if you offer a reasonable compromise. Try bidding below!
                              </p>
                            </div>
                          </div>

                          {/* Bargain Status Displays */}
                          {bargainStatus === "sending" && (
                            <div className="py-4 text-center text-xs text-slate-500 space-y-2">
                              <RefreshCw className="w-5 h-5 text-cyan-600 animate-spin mx-auto" />
                              <span className="font-bold">Analyzing bid weight and carrier fuel buffers...</span>
                            </div>
                          )}

                          {bargainStatus === "idle" && (
                            <div className="space-y-3 pt-1">
                              {/* Quick discount selectors */}
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-[10px] text-slate-400 font-bold uppercase mr-1 p-1">Quick Deals:</span>
                                <button
                                  onClick={() => {
                                    if (activeResult) {
                                      const val = Math.round(activeResult.landedCostUSD * 0.95);
                                      setBargainProposedPriceStr(val.toString());
                                      handleBargain(val);
                                    }
                                  }}
                                  className="px-2 py-1 hover:bg-slate-200 text-slate-705 bg-white border border-slate-200 rounded-lg text-[10px] font-bold cursor-pointer transition-colors"
                                >
                                  -5% Discount
                                </button>
                                <button
                                  onClick={() => {
                                    if (activeResult) {
                                      const val = Math.round(activeResult.landedCostUSD * 0.90);
                                      setBargainProposedPriceStr(val.toString());
                                      handleBargain(val);
                                    }
                                  }}
                                  className="px-2 py-1 hover:bg-slate-200 text-slate-705 bg-white border border-slate-200 rounded-lg text-[10px] font-bold cursor-pointer transition-colors"
                                >
                                  -10% Discount
                                </button>
                                <button
                                  onClick={() => {
                                    if (activeResult) {
                                      const val = Math.round(activeResult.landedCostUSD * 0.85);
                                      setBargainProposedPriceStr(val.toString());
                                      handleBargain(val);
                                    }
                                  }}
                                  className="px-2 py-1 hover:bg-slate-200 text-slate-705 bg-white border border-slate-200 rounded-lg text-[10px] font-bold cursor-pointer transition-colors"
                                >
                                  -15% Discount
                                </button>
                              </div>

                              {/* Manual Input form */}
                              <div className="flex items-center gap-2">
                                <div className="relative flex-1">
                                  <span className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-405 font-bold text-xs">
                                    $
                                  </span>
                                  <input
                                    type="number"
                                    placeholder={`Less than $${activeResult ? Math.ceil(activeResult.landedCostUSD) : '0'}`}
                                    value={bargainProposedPriceStr}
                                    onChange={(e) => setBargainProposedPriceStr(e.target.value)}
                                    className="w-full bg-white border border-slate-250 rounded-xl py-1.5 pl-7 pr-3 text-xs font-semibold focus:outline-none focus:border-cyan-500 font-mono"
                                  />
                                </div>
                                <button
                                  onClick={() => {
                                    const val = parseFloat(bargainProposedPriceStr);
                                    if (!isNaN(val)) {
                                      handleBargain(val);
                                    }
                                  }}
                                  disabled={!bargainProposedPriceStr}
                                  className="px-3.5 py-1.5 bg-cyan-700 hover:bg-cyan-800 disabled:bg-slate-300 disabled:cursor-not-allowed text-white text-[11px] font-bold rounded-xl transition-all cursor-pointer shadow-xs uppercase tracking-wider"
                                >
                                  Negotiate
                                </button>
                              </div>
                            </div>
                          )}

                          {bargainStatus !== "sending" && bargainStatus !== "idle" && (
                            <div className="space-y-3 pt-1">
                              {/* Message Box */}
                              <div className={`p-3 rounded-xl text-xs border ${
                                bargainStatus === "approved"
                                  ? "bg-emerald-50 border-emerald-100 text-emerald-900"
                                  : bargainStatus === "countered"
                                    ? "bg-amber-50 border-amber-100 text-amber-900"
                                    : "bg-rose-50 border-rose-100 text-rose-900"
                              }`}>
                                <span className="font-bold block mb-1 text-[12px]">
                                  {bargainStatus === "approved" && "🤝 Deal Approved!"}
                                  {bargainStatus === "countered" && "⚖️ Counter-Offer Proposed"}
                                  {bargainStatus === "rejected" && "❌ Bid Terminated / Lowball Error"}
                                </span>
                                <p className="text-[11px] leading-relaxed font-semibold">
                                  {bargainMessage}
                                </p>
                              </div>

                              {/* Action Options Row for Counter Offer */}
                              {bargainStatus === "countered" && (
                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={handleAcceptCounterOffer}
                                    className="flex-1 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[10px] text-center uppercase tracking-wider transition-all cursor-pointer shadow-xs"
                                  >
                                    Accept Counter Offer
                                  </button>
                                  <button
                                    onClick={() => {
                                      setBargainStatus("idle");
                                      setBargayedCostUSD(null);
                                      setBargainDiscountApplied(0);
                                    }}
                                    className="py-1.5 px-3 bg-white border border-slate-205 text-slate-700 hover:bg-slate-50 font-bold rounded-lg text-[10px] text-center uppercase tracking-wider transition-all cursor-pointer"
                                  >
                                    Reject / Bid Again
                                  </button>
                                </div>
                              )}

                              {/* Action Row for Rejected or Approved Deals */}
                              {(bargainStatus === "approved" || bargainStatus === "rejected") && (
                                <div className="flex flex-wrap items-center justify-between gap-2.5 pt-1">
                                  {bargainStatus === "approved" && (
                                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-sm">
                                      Landed discount applied to checkout!
                                    </span>
                                  )}
                                  {bargainStatus === "rejected" && bargainAttempts < 3 && (
                                    <span className="text-[10px] font-bold text-rose-700">
                                      {3 - bargainAttempts} rounds of bargaining remaining.
                                    </span>
                                  )}
                                  {bargainStatus === "rejected" && bargainAttempts >= 3 && (
                                    <span className="text-[10px] font-bold text-slate-500 font-mono">
                                      Negotiation rounds exhausted.
                                    </span>
                                  )}

                                  <button
                                    onClick={() => {
                                      setBargainStatus("idle");
                                      if (bargainStatus === "rejected") {
                                        setBargayedCostUSD(null);
                                        setBargainDiscountApplied(0);
                                      }
                                    }}
                                    disabled={bargainStatus === "rejected" && bargainAttempts >= 3}
                                    className="py-1 px-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 disabled:opacity-50 disabled:cursor-not-allowed font-bold rounded-lg text-[10px] uppercase tracking-wider cursor-pointer"
                                  >
                                    {bargainStatus === "approved" ? "Reset / Bargain Again" : "Propose New Bid"}
                                  </button>
                                </div>
                              )}
                            </div>
                          )}

                          {/* Log record of bargains */}
                          {bargainHistory.length > 0 && (
                            <div className="text-[9px] border-t border-slate-200/60 pt-2.5 space-y-1">
                              <span className="font-extrabold text-slate-400 uppercase tracking-wider block">Negotiation Log:</span>
                              <div className="max-h-24 overflow-y-auto space-y-1 font-mono pr-1">
                                {bargainHistory.map((hist, index) => (
                                  <div key={`hist-${index}`} className="flex items-center justify-between text-slate-500">
                                    <span>Offer: <span className="font-bold text-slate-700">${hist.offer} USD</span></span>
                                    <span className={`font-black uppercase text-[8px] px-1 rounded-xs ${
                                      hist.status === "approved" ? "bg-emerald-50 text-emerald-700 border border-emerald-100" :
                                      hist.status === "countered" ? "bg-amber-50 text-amber-700 border border-amber-100" : "bg-rose-50 text-rose-700 border border-rose-100"
                                    }`}>
                                      {hist.status}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Phase 2: AI Advisor Insights Segment (Server-side Gemini 3.5-flash response display) */}
                  <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                    
                    <div className="bg-slate-900 p-4 border-b border-cyan-800 text-white flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Scale className="w-5 h-5 text-cyan-400" />
                        <div>
                          <h3 className="text-xs font-bold uppercase tracking-wider">AI Customs Classification Counsel</h3>
                          <p className="text-[10px] text-slate-400 font-medium font-mono leading-none">Powered by Gemini 3.5-flash</p>
                        </div>
                      </div>

                      <span className="inline-flex items-center gap-1 bg-cyan-950 px-2 py-1 rounded text-[10px] text-cyan-300 border border-cyan-800/50">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span> Active Broker
                      </span>
                    </div>

                    <div className="p-5">
                      {isAdvising ? (
                        <div className="py-12 text-center text-xs text-slate-500 space-y-3.5">
                          <RefreshCw className="w-8 h-8 text-cyan-500 animate-spin mx-auto" />
                          <div>
                            <span className="font-bold text-slate-700 block">Gemini AI is parsing compliance documentation...</span>
                            <span className="text-[10px] text-slate-400 block mt-1">Cross-referencing Harmonized Tariff schedule (HTS) datasets.</span>
                          </div>
                        </div>
                      ) : advisorAdvice ? (
                        <div className="space-y-4">
                          
                          {/* Top metadata grid */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                            
                            <div className="p-3 bg-slate-50 border border-slate-150 rounded-xl">
                              <span className="text-slate-450 block font-bold text-[9px] uppercase tracking-wider mb-1">Estimated HS Tariff Code</span>
                              <span id="ai-hs-code" className="font-bold font-mono text-cyan-700 text-sm">
                                {advisorAdvice.hsCode || "8517.62"}
                              </span>
                              <span className="block text-[10px] text-slate-400 mt-0.5">
                                Confidence: {advisorAdvice.hsCodeConfidence || "High"}
                              </span>
                            </div>

                            <div className="p-3 bg-slate-50 border border-slate-150 rounded-xl">
                              <span className="text-slate-450 block font-bold text-[9px] uppercase tracking-wider mb-1">Tariff rate segment</span>
                              <span id="ai-tariff-range" className="font-bold text-slate-800 text-[13px]">
                                {advisorAdvice.dutyEstimateRange || "No custom duty matches."}
                              </span>
                              <span className="block text-[10px] text-slate-400 mt-0.5">
                                Base: {advisorAdvice.vatGstRate || "Standard vat"}
                              </span>
                            </div>

                            <div className="p-3 bg-slate-50 border border-slate-150 rounded-xl">
                              <span className="text-slate-450 block font-bold text-[9px] uppercase tracking-wider mb-1">Import Restriction Status</span>
                              <span id="ai-restriction-status" className={`font-bold text-[13px] flex items-center gap-1 ${
                                advisorAdvice.isRestricted ? "text-amber-600" : "text-emerald-600"
                              }`}>
                                {advisorAdvice.isRestricted ? (
                                  <>
                                    <AlertTriangle className="w-4 h-4" /> Restricted Area
                                  </>
                                ) : (
                                  <>
                                    <CheckCircle className="w-4 h-4" /> Cleared Entry
                                  </>
                                )}
                              </span>
                              <span className="block text-[10px] text-slate-400 mt-0.5">
                                Requires declaration
                              </span>
                            </div>

                          </div>

                          {/* Restriction cautions text */}
                          {advisorAdvice.restrictionsWarning && (
                            <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-100 flex items-start gap-2.5 text-xs text-amber-900">
                              <ShieldAlert className="w-4.5 h-4.5 text-amber-600 shrink-0 mt-0.5" />
                              <div className="space-y-1">
                                <span className="font-bold tracking-tight block">Warning details:</span>
                                <p id="ai-warning-p" className="text-[11px] text-slate-700 leading-relaxed font-semibold">
                                  {advisorAdvice.restrictionsWarning}
                                </p>
                              </div>
                            </div>
                          )}

                          {/* Text smart advice */}
                          <div className="space-y-1 bg-slate-50 border border-slate-150 p-4 rounded-xl text-xs text-slate-650 leading-relaxed">
                            <span className="text-slate-850 font-bold block text-sm">Strategic Import Advisory Profile</span>
                            <p id="ai-recomm-p" className="text-[11px]">
                              {advisorAdvice.smartAdvice}
                            </p>
                          </div>

                          {/* Required documentations checklist */}
                          {advisorAdvice.documentationRequired && advisorAdvice.documentationRequired.length > 0 && (
                            <div className="space-y-2 text-xs">
                              <span className="font-bold text-slate-800 tracking-tight flex items-center gap-1">
                                <FileCheck className="w-4 h-4 text-cyan-600" /> Documents required for Custom Clearance
                              </span>
                              
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                                {advisorAdvice.documentationRequired.map((doc, idx) => (
                                  <div key={`doc-${idx}`} className="flex items-center gap-2 p-2 bg-slate-50 border border-slate-100 rounded-lg font-bold text-slate-700">
                                    <span className="h-1.5 w-1.5 rounded-full bg-cyan-500"></span>{doc}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                        </div>
                      ) : (
                        <div className="py-6 text-center text-xs text-slate-450 italic">
                          No active counsel logs loaded. Click estimation triggers to pull AI reviews.
                        </div>
                      )}
                    </div>

                  </div>

                </div>
              )}

            </div>

          </div>
        )}

        {/* TAB 3: Combined Freight Shipping Cart & History logs */}
        {activeTab === "cart" && (
          <div className="space-y-6">
            
            {/* Header banner */}
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 bg-cyan-100 text-cyan-600 rounded-lg">
                    <Layers className="w-5 h-5 text-cyan-700" />
                  </span>
                  <h2 className="text-xl font-bold text-slate-900 tracking-tight">Consolidated Shipping Agent Cart</h2>
                </div>
                <p className="text-slate-500 text-xs sm:text-sm max-w-2xl leading-relaxed">
                  Avoid paying multiple handling surcharges by grouping your overseas purchases together! 
                  Our system evaluates volumetric parameters recursively to yield the best de-minimis threshold utility.
                </p>
              </div>

              {/* Destination Port Select for combined cart */}
              <div className="shrink-0 space-y-1.5 w-full md:w-56">
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Global Shipping Port Destination
                </label>
                <select
                  id="cart-global-destination"
                  value={cartDestination}
                  onChange={(e) => setCartDestination(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-cyan-500 cursor-pointer"
                >
                  {countries.map(c => (
                    <option key={`cart-dest-${c.code}`} value={c.code}>
                      📥 {c.name} ({c.currency})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* List and Statistics divide */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Product tracking list column */}
              <div className="lg:col-span-7 space-y-4">
                
                {cartItems.map((item) => (
                  <div 
                    key={item.id} 
                    id={`cart-row-${item.id}`}
                    className="p-4 bg-white border border-slate-200 rounded-2xl shadow-3xs flex flex-col sm:flex-row items-center justify-between gap-4 hover:border-slate-300 transition-colors"
                  >
                    
                    <div className="flex items-center gap-3.5 w-full sm:w-auto">
                      <div className="w-16 h-16 rounded-xl bg-slate-150 overflow-hidden shrink-0 border border-slate-100">
                        <img src={item.product.image} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <span className="bg-cyan-50 text-cyan-700 px-2 py-0.2 rounded-md text-[9px] font-extrabold uppercase tracking-wide">
                          {item.product.category}
                        </span>
                        <h4 className="font-bold text-slate-850 text-[13px] tracking-tight mt-1">
                          {item.product.name}
                        </h4>
                        <div className="text-[10px] text-slate-450 font-semibold mt-0.5">
                          Vol: {item.product.lengthCm} × {item.product.widthCm} × {item.product.heightCm} CM | {item.product.weightKg} kg
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-105">
                      
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-slate-400 block sm:hidden">QTY:</span>
                        <div className="flex items-center border border-slate-200 rounded-lg p-0.5 bg-slate-50">
                          <button
                            onClick={() => {
                              if (item.quantity > 1) {
                                setCartItems(prev => prev.map(p => p.id === item.id ? { ...p, quantity: p.quantity - 1 } : p));
                              } else {
                                removeCartItem(item.id);
                              }
                            }}
                            className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold hover:bg-slate-200 cursor-pointer text-slate-500"
                          >
                            -
                          </button>
                          <span className="px-2.5 font-bold text-xs text-slate-850 font-mono">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => {
                              setCartItems(prev => prev.map(p => p.id === item.id ? { ...p, quantity: p.quantity + 1 } : p));
                            }}
                            className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold hover:bg-slate-200 cursor-pointer text-slate-700"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-slate-450 block text-[9px] uppercase tracking-wider font-bold">Subtotal</span>
                        <span className="font-bold text-slate-900 text-sm">
                          ${(item.product.priceUSD * item.quantity).toLocaleString()} USD
                        </span>
                      </div>

                      <button
                        onClick={() => removeCartItem(item.id)}
                        className="p-2 text-slate-400 hover:text-red-500 rounded-lg bg-slate-50 hover:bg-red-50 transition-colors cursor-pointer"
                        title="Remove product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>

                    </div>

                  </div>
                ))}

                {cartItems.length === 0 && (
                  <div className="p-12 text-center bg-white border border-slate-200 rounded-2xl space-y-4">
                    <div className="w-12 h-12 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center mx-auto">
                      <ShoppingBag className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm">Consolidated Shopping Cart Empty</h3>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed mt-1">
                        Navigate to the Browse Items tab, explore available e-commerce products, and tap "Add to Cart" to build combined freight scenarios.
                      </p>
                    </div>
                    <button
                      onClick={() => setActiveTab("items")}
                      className="px-4 py-2 text-xs font-bold bg-cyan-600 rounded-lg hover:bg-cyan-700 text-white transition-colors cursor-pointer"
                    >
                      Browse Amazon Stocks Now
                    </button>
                  </div>
                )}

                {/* HISTORICAL RECENT RUNS LOGS (Satisfies student 2 and dynamic user persistent histories requirement) */}
                <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-3xs pt-1.5">
                  <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-bold text-xs text-slate-800 uppercase tracking-widest">
                      <History className="w-4 h-4 text-cyan-600" /> Server Logs & Historical Calculations
                    </span>
                    {history.length > 0 && (
                      <button
                        onClick={executeClearHistory}
                        className="text-[10px] font-bold text-slate-450 hover:text-red-600 flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Wipe Database Log
                      </button>
                    )}
                  </div>

                  <div className="p-4 space-y-2.5 max-h-80 overflow-y-auto">
                    {history.map((entry) => (
                      <div 
                        key={entry.id} 
                        className="p-3 bg-slate-50 border border-slate-100 hover:border-cyan-200 rounded-xl text-[11px] leading-relaxed transition-all flex flex-col sm:flex-row items-center sm:items-start justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 font-bold">
                            <span className="text-cyan-600 uppercase tracking-wide">{entry.originCountryName}</span>
                            <ArrowRight className="w-3 h-3 text-slate-400" />
                            <span className="text-slate-800 uppercase tracking-wide">{entry.destinationCountryName}</span>
                            <span className="bg-slate-200 text-slate-700 px-1.5 py-0.2 rounded-md font-extrabold text-[9px] uppercase tracking-widest ml-1">
                              {entry.input.category}
                            </span>
                          </div>
                          
                          <p className="text-slate-500 font-medium leading-none">
                            Value: ${entry.input.declaredValue.toLocaleString()} USD | Mode: {entry.input.shippingMode === "express" ? "Express prioritization" : "Standard"}
                          </p>
                          <span className="text-[10px] text-slate-400 block font-normal leading-none mt-0.5">
                            Executed on: {new Date(entry.timestamp).toLocaleTimeString()}
                          </span>
                        </div>

                        <div className="text-right">
                          <span className="block text-[10px] text-slate-400 uppercase font-bold tracking-wider leading-none">Landed Total</span>
                          <span className="font-bold text-slate-900 font-mono text-sm leading-normal">
                            ₹{entry.result.landedCostLocal.toLocaleString(undefined, {maximumFractionDigits: 1})}
                          </span>
                          <span className="block text-[9px] text-emerald-600 font-extrabold leading-none mt-0.2">
                            {entry.result.timelineMinDays}-{entry.result.timelineMaxDays} days shipping
                          </span>
                        </div>
                      </div>
                    ))}

                    {history.length === 0 && (
                      <div className="text-center py-6 text-xs text-slate-400 italic">
                        No historical evaluations recorded on the server yet.
                      </div>
                    )}
                  </div>
                </div>

              </div>

              {/* Cost stats consolidated card */}
              <div className="lg:col-span-5 space-y-4">
                
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl text-white space-y-5">
                  <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                    <Info className="w-5 h-5 text-cyan-400" />
                    <div>
                      <h3 className="text-sm font-bold tracking-tight">Landed Invoice Estimator</h3>
                      <p className="text-[10px] text-cyan-300">Simulated DDP Logistics Aggregator</p>
                    </div>
                  </div>

                  <div className="space-y-3.5 text-xs">
                    
                    <div className="flex items-center justify-between pb-1">
                      <span className="text-slate-400 font-medium">Bundled Items Value:</span>
                      <span className="font-bold font-mono">${cartStats.rawItemValueUSD.toLocaleString()} USD</span>
                    </div>

                    <div className="flex items-center justify-between pb-1">
                      <span className="text-slate-400 font-medium">Aggregated Shipment Mass:</span>
                      <span className="font-semibold">{cartStats.totalWeightKg.toFixed(2)} KG</span>
                    </div>

                    <div className="flex items-center justify-between pb-1">
                      <span className="text-slate-400 font-medium flex items-center gap-1">
                        Combined freight, fuel & logistics:
                      </span>
                      <span className="font-semibold font-mono">${cartStats.finalFreightUSD.toFixed(1)} USD</span>
                    </div>

                    <div className="flex items-center justify-between pb-1">
                      <span className="text-slate-400 font-medium flex items-center gap-1">
                        Est. Combined Customs Duties:
                      </span>
                      <span className={cartStats.isBelowDeMinimis ? "text-emerald-400 font-bold" : "font-mono font-bold"}>
                        {cartStats.isBelowDeMinimis ? "Exempted ($0)" : `$${cartStats.dutyUSD.toFixed(1)} USD`}
                      </span>
                    </div>

                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <span className="text-slate-400 font-medium">Est. Consumption VAT:</span>
                      <span className={cartStats.isBelowDeMinimis ? "text-emerald-400 font-bold" : "font-mono font-bold"}>
                        {cartStats.isBelowDeMinimis ? "Exempted ($0)" : `$${cartStats.vatUSD.toFixed(1)} USD`}
                      </span>
                    </div>

                    {/* Landed Total locally Display */}
                    <div className="pt-3 flex flex-col gap-1 text-center sm:text-left">
                      <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-widest block">Combined Landed Import Cost</span>
                      
                      <div className="flex items-baseline justify-between mt-1">
                        <span className="text-slate-300 font-semibold uppercase text-[11px]">In destination currency:</span>
                        <h2 className="text-2xl font-extrabold text-cyan-400 font-mono">
                          {cartStats.destCountry.symbol}
                          {cartStats.finalLandedLocal.toLocaleString(undefined, {maximumFractionDigits: 1})}
                        </h2>
                      </div>
                      
                      <div className="flex items-baseline justify-between text-[11px] text-slate-400 mt-0.5">
                        <span>USD Base Pricing:</span>
                        <span className="font-bold">${cartStats.finalLandedUSD.toLocaleString(undefined, {maximumFractionDigits: 1})} USD</span>
                      </div>
                    </div>

                  </div>

                  {cartItems.length > 0 && (
                    <div className="pt-2">
                      <button
                        onClick={() => {
                          alert(`Mock checkout success!\nCustoms invoice generated for ${cartStats.destCountry.name}.\nDDP clearance scheduled with IATA brokers.`);
                          setCartItems([]);
                        }}
                        className="w-full bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-extrabold py-3 px-4 rounded-xl shadow-md transition-colors cursor-pointer text-center text-xs uppercase"
                      >
                        Execute Order & Prepay Duty (DDP)
                      </button>
                    </div>
                  )}

                </div>

                {/* Delivery timelines indicators */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4.5 text-xs text-slate-650 space-y-3 shadow-3xs">
                  <div className="flex items-center gap-1.5 font-bold text-slate-800 uppercase tracking-wider">
                    <Clock className="w-4 h-4 text-cyan-600" />
                    <span>Cross-border clearance times</span>
                  </div>
                  
                  <p className="text-[11px] text-slate-500 leading-normal">
                    These timelines specify normal operational flow times. When shipping bundled values above de-minimis limits, government borders might request customs KYC forms or verified identification cards for clearance processing.
                  </p>

                  <div className="p-3 bg-slate-50 border border-slate-150 rounded-xl space-y-2">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-semibold">Normal airport priority broker:</span>
                      <span className="text-cyan-700 font-bold">4-7 business days</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-semibold">Standard logistics ocean route:</span>
                      <span className="text-indigo-600 font-bold">7-12 business days</span>
                    </div>
                    
                    {cartStats.destCountry.code === "IN" && (
                      <div className="text-[10px] text-amber-700 bg-amber-50 p-2 rounded-lg border border-amber-100 flex items-start gap-1.5 font-semibold leading-normal">
                        <AlertTriangle className="w-3.5 h-3.5 mt-0.2 shrink-0 text-amber-650" />
                        <span>India Hub Surcharge & increased inspection buffer active (adds 2-3 extra days clearing delay).</span>
                      </div>
                    )}
                  </div>
                </div>

              </div>
              
            </div>

          </div>
        )}

        {/* TAB 4: Academic Admin Playground / Global Insights Feed */}
        {activeTab === "insights" && (
          <div className="space-y-6">
            
            {/* Header banner */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 bg-cyan-900/50 text-cyan-400 rounded-lg">
                    <Settings className="w-5 h-5 text-cyan-400" />
                  </span>
                  <h2 className="text-xl font-extrabold tracking-tight">Admin Policy Configurator & Alerts</h2>
                </div>
                <p className="text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
                  Welcome to the Policy Configuration Dashboard. Adjust international logistics multipliers globally to inspect how prices adjust, review dynamic border notifications, and verify compliance structures.
                </p>
              </div>

              {/* Signatures status badge */}
              <div className="px-4 py-3 bg-slate-800 rounded-xl border border-slate-700 font-bold text-xs shrink-0 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Logistics Gateway: Active</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Box 1: Interactive Policy Multiplier tool (Member 2 assignment focus) */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-3xs">
                
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Sliders className="w-5 h-5 text-cyan-600" />
                  <div>
                    <h3 className="font-extrabold text-[13px] text-slate-800 uppercase tracking-tight">Policy Multipliers</h3>
                    <p className="text-[10px] text-slate-450 leading-none mt-0.5">Adjust fuel index & import broker markups</p>
                  </div>
                </div>

                <div className="space-y-4 text-xs">
                  
                  {/* Slider Fuel surcharge */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-700">Dynamic Fuel Factor</span>
                      <span className="font-mono bg-cyan-50 text-cyan-700 font-bold px-2 py-0.5 rounded">
                        {adminFuelMultiplier.toFixed(2)}x
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="3.0"
                      step="0.1"
                      value={adminFuelMultiplier}
                      onChange={(e) => setAdminFuelMultiplier(parseFloat(e.target.value))}
                      className="w-full accent-cyan-600 cursor-pointer h-2 bg-slate-100 rounded-lg appearance-none"
                    />
                    <span className="text-[10px] text-slate-400 block leading-normal">
                      Simulates trans-pacific aircraft kerosene surcharges. Impacts both express and standard basic shipping charges.
                    </span>
                  </div>

                  {/* Input Flat Surcharge */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-700">Flat Handling Mark-up</span>
                      <span className="font-mono bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded">
                        +${adminHandlingMarkup} USD
                      </span>
                    </div>
                    <input
                      type="number"
                      min="0"
                      max="150"
                      value={adminHandlingMarkup}
                      onChange={(e) => setAdminHandlingMarkup(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg py-1.5 px-3 text-xs focus:outline-none focus:border-cyan-500 font-semibold"
                    />
                    <span className="text-[10px] text-slate-400 block leading-normal">
                      Inserts flat administration charges for broker declaration handling logs.
                    </span>
                  </div>

                  {/* Reset policy metrics to defaults */}
                  <button
                    onClick={() => {
                      setAdminFuelMultiplier(1.0);
                      setAdminHandlingMarkup(0);
                      alert("Admin custom logistics surcharges have been reset to baseline configurations!");
                    }}
                    className="w-full text-center py-2 border border-cyan-200 hover:bg-cyan-50 text-cyan-600 rounded-xl font-bold font-mono text-[11px] transition-colors cursor-pointer"
                  >
                    Reset System Parameters
                  </button>

                </div>

              </div>

              {/* Box 2: Live Logistics Notifications panel */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-3xs">
                
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                  <div>
                    <h3 className="font-extrabold text-[13px] text-slate-800 uppercase tracking-tight">Active Notices Feed</h3>
                    <p className="text-[10px] text-slate-450 leading-none mt-0.5">Updates on regional delays & custom audits</p>
                  </div>
                </div>

                <div className="space-y-3 text-xs">
                  {notifications.map((note) => (
                    <div key={note.id} className="p-3 bg-slate-50 border border-slate-100 rounded-xl space-y-1 hover:border-slate-200 transition-colors">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-slate-850 truncate">{note.title}</span>
                        <span className={`px-1.5 py-0.2 rounded text-[10px] uppercase tracking-wider font-extrabold ${
                          note.type === "warning" ? "bg-amber-100 text-amber-800" : (note.type === "success" ? "bg-emerald-100 text-emerald-800" : "bg-blue-100 text-blue-800")
                        }`}>
                          {note.type}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 leading-normal font-medium">
                        {note.message}
                      </p>
                      <span className="text-[9px] text-slate-400 block pt-0.5">
                        Received: {new Date(note.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  ))}
                </div>

              </div>

              {/* Box 3: Technical Information Overview */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-3xs">
                
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                  <FileText className="w-5 h-5 text-cyan-600" />
                  <div>
                    <h3 className="font-extrabold text-[13px] text-slate-800 uppercase tracking-tight">Compliance & HS Classification</h3>
                    <p className="text-[10px] text-slate-450 leading-none mt-0.5">Technical framework details & links</p>
                  </div>
                </div>

                <div className="space-y-3.5 text-xs text-slate-600 leading-relaxed font-medium">
                  
                  <p>
                    Harmonized System (HS) classifications represent unified 6-to-10 digit identifiers structured by the World Customs Organization (WCO).
                  </p>

                  <div className="p-3 bg-cyan-950 text-cyan-200 rounded-xl space-y-1.5 border border-cyan-800 font-bold">
                    <span className="text-white block text-[11px] font-bold">System details:</span>
                    <span className="block text-[10px] text-slate-300 font-mono">Backend framework: Node.js, Express.js</span>
                    <span className="block text-[10px] text-slate-300 font-mono">Frontend: React.js, Tailwind v4</span>
                    <span className="block text-[10px] text-slate-300 font-mono">Database: Local Memory logs store</span>
                  </div>

                  <p className="text-[11px] text-slate-450">
                    The Express server handles calculations locally using continuous formulas and proxies AI classification queries safely through server-side environment configurations.
                  </p>

                </div>

              </div>

            </div>

          </div>
        )}

      </main>

      {/* Modern High-contrast Footer */}
      <footer className="bg-slate-900 text-slate-405 text-xs py-8 border-t border-slate-800 mt-12 shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-slate-400">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 text-center md:text-left">
            <div>
              <span className="font-bold text-white tracking-wide uppercase text-[11px] block text-cyan-400">
                Global Customs & Carrier Estimator
              </span>
              <p className="text-[10px] text-slate-400 mt-1 leading-normal max-w-xl">
                Integrated real-time international shipping estimator featuring standard IATA freight methodologies, live de-minimis guidelines, and multi-country tax calculations.
              </p>
            </div>
            <div className="flex justify-center md:justify-end gap-3 text-[11px] text-slate-500 font-semibold uppercase tracking-wider">
              <span>Secure Logistics Agent Portal</span>
            </div>
          </div>
          
          <div className="border-t border-slate-850 mt-6 pt-4 text-center text-[10px] text-slate-500">
            &copy; {new Date().getFullYear()} Global Customs & Carrier Agent. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Interactive Wishlist / Product Details Overlay Modal */}
      <AnimatePresence>
        {selectedProductDetails && (() => {
          const activeP = getAdjustedProduct(selectedProductDetails);
          const preview = computeLocalDDPPreview(activeP);
          return (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedProductDetails(null)}
                className="absolute inset-0 bg-slate-950/65 backdrop-blur-xs cursor-pointer z-10"
              />

              {/* Modal Body */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 30 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 30 }}
                transition={{ type: "spring", duration: 0.45 }}
                className="relative bg-white w-full max-w-xl rounded-3xl overflow-hidden shadow-2xl border border-slate-100 z-20 flex flex-col max-h-[90vh]"
              >
                {/* Close Button */}
                <button
                  onClick={() => setSelectedProductDetails(null)}
                  className="absolute top-4 right-4 p-2 bg-slate-900/55 hover:bg-slate-900/80 text-white rounded-full transition-colors z-30 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>

                {/* Product Hero Image Header */}
                <div className="relative h-48 bg-slate-100 shrink-0">
                  <img
                    src={activeP.image}
                    alt={activeP.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/25 to-transparent" />
                  
                  <div className="absolute bottom-4 left-5 right-5 text-white">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-cyan-600 text-white shadow-xs uppercase tracking-wider">
                      {activeP.category}
                    </span>
                    <h3 className="text-base font-extrabold mt-1 leading-tight text-white drop-shadow-md">
                      {activeP.name}
                    </h3>
                    <p className="text-cyan-300 text-xs font-semibold mt-0.5 drop-shadow-xs">
                      {activeP.tagline}
                    </p>
                  </div>
                </div>

                {/* Content Panel (Scrollable) */}
                <div className="p-5 space-y-4 overflow-y-auto font-sans text-xs">
                  {/* Product Description */}
                  <div>
                    <h4 className="text-[9px] font-black uppercase text-slate-400 tracking-wider mb-1">
                      Commodity Overview
                    </h4>
                    <p className="text-slate-600 text-[11px] leading-relaxed">
                      {activeP.description}
                    </p>
                  </div>

                  {/* Weight Customization Panel */}
                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-[10px] font-extrabold uppercase text-slate-800 tracking-tight">
                          Interactive Weight Tuner
                        </h4>
                        <p className="text-[9px] text-slate-400">
                          Adjust product weight (up to 5 kg) to live-calculate carrier freight rates & country taxes
                        </p>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-cyan-100 text-cyan-800 font-bold text-[10px] font-mono">
                        {activeP.weightKg} kg
                      </span>
                    </div>

                    {/* Controls Row */}
                    <div className="flex flex-wrap items-center gap-1.5 pt-1">
                      <button
                        onClick={() => adjustProductWeight(selectedProductDetails, Math.max(0.01, activeP.weightKg - 1))}
                        className="px-2 py-1.5 bg-white text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg text-[10px] font-bold cursor-pointer transition-colors"
                      >
                        -1 kg
                      </button>
                      
                      <div className="flex-1 flex items-center justify-center bg-white border border-slate-150 rounded-lg py-1.5 px-3">
                        <span className="text-slate-400 text-[10px] mr-1.5 select-none font-medium">Set Weight:</span>
                        <input
                          type="number"
                          step="0.1"
                          min="0.01"
                          max="5"
                          value={activeP.weightKg || ""}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            if (!isNaN(val)) {
                              adjustProductWeight(selectedProductDetails, val > 5 ? 5 : val);
                            }
                          }}
                          className="w-16 bg-transparent text-slate-900 border-none outline-hidden text-center text-[11px] font-black font-mono focus:ring-0 p-0"
                        />
                        <span className="text-slate-400 font-mono text-[10px] ml-1 select-none font-bold">kg</span>
                      </div>

                      <button
                        onClick={() => adjustProductWeight(selectedProductDetails, Math.min(5, activeP.weightKg + 1))}
                        className="px-2 py-1.5 bg-white text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg text-[10px] font-bold cursor-pointer transition-colors"
                      >
                        +1 kg
                      </button>
                    </div>

                    <div className="text-[10px] text-slate-500 bg-white/50 border border-dashed border-slate-200 p-2 rounded-lg leading-relaxed">
                      💡 <strong className="text-slate-700 font-bold">Dynamic Scale Feedback:</strong> Weight increase scales base raw materials and manufacturing costs. Price updated from <span className="line-through">${selectedProductDetails.priceUSD} USD</span> to <strong className="text-cyan-700 font-black">${activeP.priceUSD} USD</strong>.
                    </div>
                  </div>

                  {/* Real-Time Shipping & Landed Tax Breakdown */}
                  <div className="border border-slate-250 bg-slate-900 text-slate-100 rounded-2xl p-4 space-y-3 shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[14px]">📦</span>
                        <div>
                          <h4 className="text-[10px] font-black uppercase tracking-wide text-cyan-400">
                            Real-Time Landed Cost Preview
                          </h4>
                          <p className="text-[9px] text-slate-400">
                            Destination: {preview.destination.name} ({preview.destination.code})
                          </p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                        DDP Estimated
                      </span>
                    </div>

                    <div className="space-y-1.5 font-mono text-[11px]">
                      <div className="flex justify-between items-center text-slate-300">
                        <span>Scaled Item Value (FOB):</span>
                        <span className="font-bold text-white">${activeP.priceUSD.toLocaleString()}.00 USD</span>
                      </div>
                      <div className="flex justify-between items-center text-slate-300">
                        <span>Fuel & Freight Quote:</span>
                        <span className="font-bold text-white">${preview.shippingCostUSD.toFixed(2)} USD</span>
                      </div>
                      
                      <div className="flex justify-between items-center text-slate-300">
                        <span>
                          Customs Duty ({preview.isBelowDeMinimis ? "Exempt" : `${preview.destination.dutyRates[activeP.category] || 5}% CIF`}):
                        </span>
                        <span className={`font-bold ${preview.isBelowDeMinimis ? "text-slate-500" : "text-white"}`}>
                          ${preview.dutyUSD.toFixed(2)} USD
                        </span>
                      </div>

                      <div className="flex justify-between items-center text-slate-300">
                        <span>
                          Consumption VAT ({preview.isBelowDeMinimis ? "Exempt" : `${preview.destination.vatRate}%`}):
                        </span>
                        <span className={`font-bold ${preview.isBelowDeMinimis ? "text-slate-500" : "text-white"}`}>
                          ${preview.vatUSD.toFixed(2)} USD
                        </span>
                      </div>

                      {preview.isBelowDeMinimis && (
                        <div className="text-[9px] text-amber-400 font-bold bg-amber-950/60 p-1.5 rounded-md border border-amber-800">
                          ⚠️ Value is under de-minimis threshold of ${preview.destination.deMinimis}.00 USD. No tax/duty applied!
                        </div>
                      )}
                    </div>

                    <div className="pt-2 border-t border-slate-800 flex items-baseline justify-between">
                      <span className="text-[11px] font-black text-slate-300 uppercase tracking-tight">
                        Total Estimated DDP:
                      </span>
                      <div className="text-right">
                        <div className="text-sm font-black text-cyan-400 font-mono">
                          ${preview.landedCostUSD.toFixed(2)} USD
                        </div>
                        <div className="text-[10px] text-slate-400 font-bold">
                          ≈ {preview.destination.symbol} {preview.landedCostLocal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} {preview.destination.currency}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Dimensions & Package Constraints */}
                  <div className="grid grid-cols-2 gap-3.5">
                    <div className="p-2.5 bg-slate-50 border border-slate-150 rounded-xl">
                      <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">
                        Commercial Cargo Class
                      </span>
                      <span className="font-extrabold text-slate-900 text-[11px] block mt-0.5">
                        {activeP.category}
                      </span>
                    </div>

                    <div className="p-2.5 bg-slate-50 border border-slate-150 rounded-xl">
                      <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">
                        Carton Size Guidelines
                      </span>
                      <span className="font-mono text-slate-800 font-bold block mt-0.5">
                        {activeP.lengthCm}x{activeP.widthCm}x{activeP.heightCm} cm
                      </span>
                    </div>
                  </div>

                  {/* Security Clearance Alert */}
                  <div className="p-3 bg-cyan-50/50 border border-cyan-150 rounded-2xl flex items-start gap-2 text-xs">
                    <span className="text-[13px] pt-0.5">✈️</span>
                    <div className="space-y-0.5">
                      <span className="text-[9px] text-cyan-800 font-black uppercase tracking-wider block">
                        IATA Security compliance report
                      </span>
                      <p className="text-slate-650 text-[10px] leading-relaxed">
                        Commercial retail status. Cleared for flight transit as standard air cargo. Weight is recalculating base fuel and kinetic dispatch indices in real-time.
                      </p>
                    </div>
                  </div>

                  {/* Wishlist Toggle badge */}
                  <div className="flex items-center justify-between text-xs pt-0.5">
                    <span className="text-slate-400 font-medium">Inside your active list?</span>
                    <button
                      onClick={() => toggleWishlist(selectedProductDetails)}
                      className="flex items-center gap-1.5 px-3 py-1 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-bold cursor-pointer transition-colors"
                    >
                      <Heart 
                        className={`w-3.5 h-3.5 transition-colors ${
                          wishlist.some(item => item.id === selectedProductDetails.id)
                            ? "fill-rose-500 text-rose-500"
                            : "text-slate-400"
                        }`}
                      />
                      <span>
                        {wishlist.some(item => item.id === selectedProductDetails.id)
                          ? "Saved in Wishlist"
                          : "Save to Wishlist"}
                      </span>
                    </button>
                  </div>
                </div>

                {/* Action Buttons Footer */}
                <div className="p-4 bg-slate-50 border-t border-slate-150 flex items-center justify-between gap-3 shrink-0">
                  <button
                    onClick={() => {
                      selectProductToEstimate(activeP);
                      setSelectedProductDetails(null);
                    }}
                    className="flex-1 py-2.5 px-4 bg-white hover:bg-slate-55 text-slate-800 border border-slate-200 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Calculator className="w-4 h-4 text-cyan-600" />
                    Estimate Duty Rates
                  </button>

                  <button
                    onClick={() => {
                      addProductToCart(activeP);
                      setSelectedProductDetails(null);
                    }}
                    className="flex-1 py-2.5 px-4 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-black transition-all shadow-md cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    Add to Cart
                  </button>
                </div>
              </motion.div>
            </div>
          );
        })()}
      </AnimatePresence>

    </div>
  );
}
