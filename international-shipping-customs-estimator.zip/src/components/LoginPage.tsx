import { useState, FormEvent } from "react";
import { motion } from "motion/react";
import { 
  Lock, 
  Mail, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  ShieldAlert, 
  Building2, 
  PlaneTakeoff, 
  Sparkles,
  Info
} from "lucide-react";

interface LoginPageProps {
  onLoginSuccess: (user: { email: string; name: string; role: string }) => void;
}

export default function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Pre-configured agent credentials for easy testing
  const presets = [
    {
      name: "Inspector Mo",
      email: "mohanaasmitha@klh.edu.in",
      role: "Senior Customs Inspector",
      pass: "klh2026",
      desc: "Full border compliance & override credentials"
    },
    {
      name: "Compliance Auditor",
      email: "auditor@iata-logistics.org",
      role: "IATA Compliance Auditor",
      pass: "compliance123",
      desc: "Customs de-minimis database audit role"
    }
  ];

  const handleApplyPreset = (preset: typeof presets[0]) => {
    setEmail(preset.email);
    setPassword(preset.pass);
    setError(null);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim() || !password.trim()) {
      setError("Please fill out all credential fields.");
      return;
    }

    setIsLoading(true);

    // Simulate natural security network check
    setTimeout(() => {
      // Find matching preset, or allow custom user registration (e.g. any matching login helper)
      const matched = presets.find(p => p.email.toLowerCase() === email.toLowerCase().trim() && p.pass === password);

      if (matched) {
        setIsLoading(false);
        onLoginSuccess({
          email: matched.email,
          name: matched.name,
          role: matched.role
        });
      } else if (password.length >= 6) {
        // Fallback for custom user credentials (makes it simple and extensible for any user)
        setIsLoading(false);
        const generatedName = email.split("@")[0].split(".")[0];
        const formattedName = generatedName.charAt(0).toUpperCase() + generatedName.slice(1);
        onLoginSuccess({
          email: email.trim(),
          name: formattedName || "Logistics Agent",
          role: "Global Trade Merchant"
        });
      } else {
        setIsLoading(false);
        setError("Invalid credentials. For trial, use the presets or choose any password with 6+ characters.");
      }
    }, 750);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8 font-sans selection:bg-cyan-500 selection:text-slate-950 relative overflow-hidden">
      
      {/* Dynamic Background Accents */}
      <div className="absolute top-[-20%] left-[-10%] w-[60vw] h-[60vw] rounded-full bg-cyan-900/15 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] rounded-full bg-indigo-900/15 blur-[120px] pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md space-y-6 relative z-10"
      >
        {/* Core Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex p-3 bg-cyan-950 border border-cyan-500/30 text-cyan-400 rounded-2xl shadow-xl shadow-cyan-950/40 mb-2">
            <PlaneTakeoff className="w-8 h-8 animate-pulse" />
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight">
            Logistics Command Center
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xs mx-auto leading-relaxed font-medium">
            Global Carrier Customs & IATA Compliance Portal
          </p>
        </div>

        {/* Credentials Form Box */}
        <div className="bg-slate-950/80 backdrop-blur-md border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-slate-950/80 space-y-6">
          <div className="space-y-1">
            <h2 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Agent Authentication
            </h2>
            <p className="text-[11px] text-slate-400 font-medium">
              Enter your secure identity coordinates or select a profile below.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email field */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Security Email
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-xl px-3 py-2.5 pl-10 text-xs sm:text-sm text-white placeholder-slate-500 font-semibold focus:outline-none transition-all"
                  placeholder="agent@iata-logistics.org"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
              </div>
            </div>

            {/* Password field */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Access Code
                </label>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-xl px-3 py-2.5 pl-10 pr-10 text-xs sm:text-sm text-white placeholder-slate-500 font-semibold focus:outline-none transition-all"
                  placeholder="••••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <Lock className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-slate-500 hover:text-slate-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Live feedback alert banner */}
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 bg-red-950/50 border border-red-905/40 rounded-xl text-[11px] font-bold text-red-200 flex items-start gap-2"
              >
                <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span>{error}</span>
              </motion.div>
            )}

            {/* Submit button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 bg-cyan-650 hover:bg-cyan-500 active:scale-[0.98] text-slate-950 text-xs font-black uppercase tracking-wider rounded-xl cursor-pointer shadow-lg shadow-cyan-950/50 hover:shadow-cyan-500/10 transition-all font-sans flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:scale-100"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <span>Initialize Connection</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Quick-test Prefills section */}
          <div className="space-y-3 pt-4 border-t border-slate-900">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Quick-Select Testing Profiles
              </span>
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleApplyPreset(preset)}
                  className="w-full text-left bg-slate-900 hover:bg-slate-850 border border-slate-850/80 hover:border-slate-800 transition-all p-2.5 rounded-xl flex items-center justify-between gap-3 group cursor-pointer"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors">
                        {preset.name}
                      </span>
                      <span className="text-[9px] font-black uppercase bg-cyan-950 text-cyan-400 border border-cyan-900 px-1 py-0.2 rounded">
                        {preset.role.split(" ").pop()}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 leading-none">
                      {preset.desc}
                    </p>
                  </div>
                  <div className="h-6 w-6 rounded-lg bg-slate-950 border border-slate-800 group-hover:border-cyan-500 flex items-center justify-center text-slate-500 group-hover:text-cyan-400 transition-all shrink-0">
                    <Building2 className="w-3.5 h-3.5" />
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="text-[10px] text-slate-500 text-center font-medium flex items-center justify-center gap-1">
            <Info className="w-3 h-3 text-slate-600" />
            <span>Use custom secure email as any trade merchant!</span>
          </div>

        </div>

        {/* Floating security credential compliance badge */}
        <div className="text-center text-[10px] text-slate-600 font-semibold uppercase tracking-widest leading-none mt-2">
          IATA Secure Ingress Control // Verified Protocol
        </div>

      </motion.div>
    </div>
  );
}
