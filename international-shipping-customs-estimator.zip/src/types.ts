/**
 * Shared Type Definitions for International Shipping Customs Estimator
 */

export enum ItemCategory {
  ELECTRONICS = "Electronics",
  FASHION = "Fashion & Apparel",
  BOOKS = "Books & Media",
  COSMETICS = "Cosmetics & Personal Care",
  TOYS = "Toys & Hobbies",
  SPORTS = "Sports & Outdoors",
  FOOD = "Food & Perishables",
  MEDICAL = "Medical & Health",
  GENERAL = "General Merchandise"
}

export interface CountryData {
  code: string;
  name: string;
  currency: string;
  symbol: string;
  rateToUSD: number; // 1 standard currency in USD, e.g. INR is 0.012
  deMinimis: number; // in USD: below this, no duties/taxes apply
  vatRate: number; // e.g. 20 for 20% Vat
  dutyRates: Record<string, number>; // Category mapping to percentage (e.g., { "Electronics": 5, ... })
  restrictedItems: string[];
}

export interface CalculationInput {
  originCode: string;
  destinationCode: string;
  category: ItemCategory;
  declaredValue: number; // in origin currency
  valueCurrency: string; // e.g. "USD", "INR", etc.
  weight: number; // actual weight
  weightUnit: "kg" | "lb";
  length: number;
  width: number;
  height: number;
  dimensionUnit: "cm" | "in";
  shippingMode: "standard" | "express";
}

export interface CalculationResult {
  chargeableWeightKg: number;
  volumetricWeightKg: number;
  baseShippingCostUSD: number;
  baseShippingCostLocal: number;
  fuelSurchargeUSD: number;
  handlingFeeUSD: number;
  dutyUSD: number;
  dutyLocal: number;
  vatUSD: number;
  vatLocal: number;
  landedCostUSD: number;
  landedCostLocal: number;
  timelineMinDays: number;
  timelineMaxDays: number;
  isBelowDeMinimis: boolean;
  recommendation: {
    incoterm: "DDP" | "DAP";
    title: string;
    description: string;
    score: number; // recommendation score out of 100
  };
}

export interface HistoryEntry {
  id: string;
  timestamp: string;
  input: CalculationInput;
  result: CalculationResult;
  originCountryName: string;
  destinationCountryName: string;
}

export interface GeminiAdvisorResponse {
  hsCode: string;
  hsCodeConfidence: string; // High, Medium, Low
  dutyEstimateRange: string;
  vatGstRate: string;
  restrictionsWarning: string;
  isRestricted: boolean; // boolean
  documentationRequired: string[];
  smartAdvice: string;
}
