// Local shim providing native DOMException to dependencies
module.exports = globalThis.DOMException || global.DOMException || class DOMException extends Error {
  constructor(message, name) {
    super(message);
    this.name = name;
  }
};
