import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type } from "@google/genai";
import { ItemCategory, CountryData, CalculationInput, CalculationResult, HistoryEntry, GeminiAdvisorResponse } from "./src/types";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory Database for calculations history (Backend development assignment)
interface Notification {
  id: string;
  type: "info" | "warning" | "success";
  title: string;
  message: string;
  timestamp: string;
}

let calculationHistory: HistoryEntry[] = [];
let mockNotifications: Notification[] = [
  {
    id: "n1",
    type: "info",
    title: "Global Supply Chain Surcharge Update",
    message: "Fuel surcharge has stabilized to 12.5% for all trans-pacific shipping lanes.",
    timestamp: new Date().toISOString()
  },
  {
    id: "n2",
    type: "warning",
    title: "India Customs Delay Notice",
    message: "Increased inspections on lithium-ion and general electronics in Mumbai & Delhi air hubs may add 2-3 business days to clearance.",
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString()
  },
  {
    id: "n3",
    type: "success",
    title: "Canada De-Minimis Threshold Alert",
    message: "Simplified postal clearance now active for values under 40 CAD.",
    timestamp: new Date(Date.now() - 3600000 * 24).toISOString()
  }
];

// Currencies mapping relative to 1 Units to USD
const EXCHANGE_RATES: Record<string, number> = {
  USD: 1.0,
  INR: 0.012,    // 1 INR = 0.012 USD
  GBP: 1.25,     // 1 GBP = 1.25 USD
  CAD: 0.73,     // 1 CAD = 0.73 USD
  AUD: 0.66,     // 1 AUD = 0.66 USD
  EUR: 1.08,     // 1 EUR = 1.08 USD
  JPY: 0.0064,   // 1 JPY = 0.0064 USD
  SGD: 0.74      // 1 SGD = 0.74 USD
};

const COUNTRIES: CountryData[] = [
  {
    code: "US",
    name: "United States",
    currency: "USD",
    symbol: "$",
    rateToUSD: 1.0,
    deMinimis: 800,
    vatRate: 0,
    dutyRates: {
      [ItemCategory.ELECTRONICS]: 1.5,
      [ItemCategory.FASHION]: 12.5,
      [ItemCategory.BOOKS]: 0,
      [ItemCategory.COSMETICS]: 4.5,
      [ItemCategory.TOYS]: 3.0,
      [ItemCategory.SPORTS]: 5.5,
      [ItemCategory.FOOD]: 8.0,
      [ItemCategory.MEDICAL]: 2.0,
      [ItemCategory.GENERAL]: 5.0
    },
    restrictedItems: ["Aerosols", "Prescription Drugs", "Counterfeits", "Perishables", "Explosives"]
  },
  {
    code: "IN",
    name: "India",
    currency: "INR",
    symbol: "₹",
    rateToUSD: 0.012,
    deMinimis: 20, // Low de-minimis threshold
    vatRate: 18,   // GST
    dutyRates: {
      [ItemCategory.ELECTRONICS]: 10.0,
      [ItemCategory.FASHION]: 25.0,
      [ItemCategory.BOOKS]: 0,
      [ItemCategory.COSMETICS]: 20.0,
      [ItemCategory.TOYS]: 15.0,
      [ItemCategory.SPORTS]: 12.0,
      [ItemCategory.FOOD]: 30.0,
      [ItemCategory.MEDICAL]: 10.0,
      [ItemCategory.GENERAL]: 15.0
    },
    restrictedItems: ["Satellite Phones", "Bullion & Coins", "Used Electronics", "Spices", "Flammable Liquids"]
  },
  {
    code: "GB",
    name: "United Kingdom",
    currency: "GBP",
    symbol: "£",
    rateToUSD: 1.25,
    deMinimis: 170, // ~135 GBP
    vatRate: 20, // UK VAT
    dutyRates: {
      [ItemCategory.ELECTRONICS]: 2.0,
      [ItemCategory.FASHION]: 12.0,
      [ItemCategory.BOOKS]: 0,
      [ItemCategory.COSMETICS]: 6.0,
      [ItemCategory.TOYS]: 4.7,
      [ItemCategory.SPORTS]: 4.0,
      [ItemCategory.FOOD]: 14.0,
      [ItemCategory.MEDICAL]: 0.0,
      [ItemCategory.GENERAL]: 5.0
    },
    restrictedItems: ["Offensive Weapons", "Soil & Growing Media", "CFCs or Coolants", "Unlicensed Transmitters"]
  },
  {
    code: "CA",
    name: "Canada",
    currency: "CAD",
    symbol: "C$",
    rateToUSD: 0.73,
    deMinimis: 15, // ~20 CAD
    vatRate: 12, // GST/PST combination
    dutyRates: {
      [ItemCategory.ELECTRONICS]: 5.0,
      [ItemCategory.FASHION]: 18.0,
      [ItemCategory.BOOKS]: 0,
      [ItemCategory.COSMETICS]: 6.5,
      [ItemCategory.TOYS]: 5.0,
      [ItemCategory.SPORTS]: 7.0,
      [ItemCategory.FOOD]: 11.0,
      [ItemCategory.MEDICAL]: 3.0,
      [ItemCategory.GENERAL]: 6.0
    },
    restrictedItems: ["Hate Literature", "Used Mattresses", "Firewood", "Spices & Unpackaged Seed", "Prescription Medication"]
  },
  {
    code: "AU",
    name: "Australia",
    currency: "AUD",
    symbol: "A$",
    rateToUSD: 0.66,
    deMinimis: 660, // ~1000 AUD de minimis
    vatRate: 10, // GST
    dutyRates: {
      [ItemCategory.ELECTRONICS]: 5.0,
      [ItemCategory.FASHION]: 10.0,
      [ItemCategory.BOOKS]: 0,
      [ItemCategory.COSMETICS]: 5.0,
      [ItemCategory.TOYS]: 5.0,
      [ItemCategory.SPORTS]: 5.0,
      [ItemCategory.FOOD]: 15.0,
      [ItemCategory.MEDICAL]: 0.0,
      [ItemCategory.GENERAL]: 5.0
    },
    restrictedItems: ["Biological Samples", "Soil or Seed Packages", "Spitfires/Blades", "Laser Pointers > 1mW"]
  },
  {
    code: "DE",
    name: "Germany",
    currency: "EUR",
    symbol: "€",
    rateToUSD: 1.08,
    deMinimis: 162, // ~150 EUR
    vatRate: 19, // Mehrwertsteuer
    dutyRates: {
      [ItemCategory.ELECTRONICS]: 2.5,
      [ItemCategory.FASHION]: 12.0,
      [ItemCategory.BOOKS]: 7.0,
      [ItemCategory.COSMETICS]: 6.5,
      [ItemCategory.TOYS]: 4.7,
      [ItemCategory.SPORTS]: 4.7,
      [ItemCategory.FOOD]: 7.0,
      [ItemCategory.MEDICAL]: 12.0,
      [ItemCategory.GENERAL]: 4.0
    },
    restrictedItems: ["Radar Detectors", "Publications endangering minors", "Unregistered medicines", "Fake goods"]
  },
  {
    code: "JP",
    name: "Japan",
    currency: "JPY",
    symbol: "¥",
    rateToUSD: 0.0064,
    deMinimis: 100, // ~10,000 JPY
    vatRate: 10, // Consumption tax
    dutyRates: {
      [ItemCategory.ELECTRONICS]: 0.0,
      [ItemCategory.FASHION]: 10.0,
      [ItemCategory.BOOKS]: 0,
      [ItemCategory.COSMETICS]: 5.0,
      [ItemCategory.TOYS]: 3.0,
      [ItemCategory.SPORTS]: 4.8,
      [ItemCategory.FOOD]: 12.0,
      [ItemCategory.MEDICAL]: 5.0,
      [ItemCategory.GENERAL]: 5.0
    },
    restrictedItems: ["Counterfeit products", "Narcotic stimulants", "Dangerous goods/Aerosols", "Lithium cells unlisted"]
  },
  {
    code: "SG",
    name: "Singapore",
    currency: "SGD",
    symbol: "S$",
    rateToUSD: 0.74,
    deMinimis: 300, // ~400 SGD
    vatRate: 9, // GST
    dutyRates: {
      [ItemCategory.ELECTRONICS]: 0.0,
      [ItemCategory.FASHION]: 0.0,
      [ItemCategory.BOOKS]: 0,
      [ItemCategory.COSMETICS]: 0.0,
      [ItemCategory.TOYS]: 0.0,
      [ItemCategory.SPORTS]: 0.0,
      [ItemCategory.FOOD]: 4.0,
      [ItemCategory.MEDICAL]: 0.0,
      [ItemCategory.GENERAL]: 0.0
    },
    restrictedItems: ["Chewing Gum", "Vaping accessories", "Spikes or tactical gears", "Telecommunication transceivers"]
  }
];

// Lazy Gemini API Initializer (Safety guidelines: fail fast and lazy load)
let geminiClient: GoogleGenAI | null = null;
function getGemini(): GoogleGenAI {
  if (!geminiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is required to access the Customs Advisor AI.");
    }
    geminiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return geminiClient;
}

// REST API endpoint: Retrieve supported countries
app.get("/api/countries", (req, res) => {
  res.json(COUNTRIES);
});

// REST API endpoint: Retrieve calculation history
app.get("/api/history", (req, res) => {
  res.json(calculationHistory);
});

// REST API endpoint: Reset calculation history
app.post("/api/history/clear", (req, res) => {
  calculationHistory = [];
  res.json({ message: "History cleared successfully", history: [] });
});

// REST API endpoint: Get live logistics notifications
app.get("/api/notifications", (req, res) => {
  res.json(mockNotifications);
});

// Helper function: Taxonomy catalog matcher for standard retail items (providing failsafe reliability)
function getSimulatedProductSpecs(searchQuery: string) {
  const queryLower = searchQuery.toLowerCase().trim();
  
  // Selection buckets based on the user's item taxonomy guidelines
  let category = ItemCategory.GENERAL;
  let price = 45;
  let weight = 0.5;
  let length = 20, width = 15, height = 8;
  let tagline = "Essential High-Quality Merchandise";
  let image = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80"; // standard elegant product photo
  let description = "";

  // Explicit user-driven keyword matchups
  if (queryLower.includes("kitchen & storage") || queryLower.includes("kitchen and storage")) {
    category = ItemCategory.GENERAL;
    tagline = "Hermetic Modular Kitchen Organizer Set";
    price = 39;
    weight = 1.8;
    length = 32; width = 20; height = 15;
    image = "https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?auto=format&fit=crop&w=600&q=80";
    description = "Sleek, stackable modular pantry jars crafted from thick borosilicate glass with airtight sustainable bamboo lids. Perfect for space-saving kitchen counter and cabinet organization with high-efficiency visual layout clearance.";
  }
  else if (queryLower.includes("revamp your home") || queryLower.includes("revamp your home in style")) {
    category = ItemCategory.GENERAL;
    tagline = "Luxury Aesthetic Soft Velvet Lounge Chair";
    price = 249;
    weight = 14.0;
    length = 85; width = 80; height = 95;
    image = "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=600&q=80";
    description = "Ergonomic scandinavian lounge chair crafted using water-resistant plush velvet fabrics and solid oak frame support. Adds an instant upscale visual dynamic and cozy mood to elevate any living room or creative workspace.";
  }
  else if (queryLower.includes("deals on headphones") || queryLower.includes("deals on headphone")) {
    category = ItemCategory.ELECTRONICS;
    tagline = "Premium Hi-Fi Wireless Sport Headphones";
    price = 79;
    weight = 0.28;
    length = 18; width = 14; height = 7;
    image = "https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=600&q=80";
    description = "Sweat-resistant secure-hook audio headphones with dual acoustic drivers and 36-hour extended lithium playtime cells. Unmatched deep bass and clean treble balance for active modern workouts.";
  }
  else if (queryLower.includes("appliances for your home") || queryLower.includes("home appliances")) {
    category = ItemCategory.ELECTRONICS;
    tagline = "Multi-Function Intelligent Eco Air Purifier";
    price = 189;
    weight = 4.8;
    length = 42; width = 26; height = 26;
    image = "https://images.unsplash.com/photo-1585338111116-606d57ad84d3?auto=format&fit=crop&w=600&q=80";
    description = "Dual-filter active true-HEPA air circulation purifier with built-in particulate smoke detectors, automated fan regulation loops, and whisper-quiet night sleep timers.";
  }
  else if (queryLower.includes("electronics & accessories") || queryLower.includes("electronics and accessories")) {
    category = ItemCategory.ELECTRONICS;
    tagline = "Acoustic Noise-Cancelling Over-Ear Headset";
    price = 175;
    weight = 0.45;
    length = 20; width = 16; height = 8;
    image = "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=600&q=80";
    description = "Superior fidelity audio headset equipped with memory-foam ear cushions, smart ambient gesture controls, and dual-microphone clear-voice feedback array.";
  }
  else if (queryLower.includes("gadget") || queryLower.includes("gadgets")) {
    category = ItemCategory.ELECTRONICS;
    tagline = "Ultimate Multi-USB Smart Productivity Gadget";
    price = 89;
    weight = 0.35;
    length = 12; width = 8; height = 3;
    image = "https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80";
    description = "Interactive wireless power distribution device featuring responsive atmospheric backlight cues, tactile smart dials, and high-conductivity terminal contacts. Elevates any home charging station or study desk.";
  }
  else if (queryLower.includes("vechicle") || queryLower.includes("vechicles") || queryLower.includes("vehicle") || queryLower.includes("vehicles")) {
    category = ItemCategory.SPORTS;
    tagline = "High-Performance Advanced Transportation System";
    price = 1200;
    weight = 24.5;
    length = 110; width = 45; height = 115;
    image = "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80";
    description = "Robust multi-terrain motor electric transit model with digital dash console, dual disc emergency brakes, and high-safety smart lithium energy cell loops.";
  }

  // 0. MOTORBIKES, VEHICLES, BICYCLES, AUTOMOTIVE & KTM ATHLETICS
  else if (
    (queryLower.includes("ktm") || queryLower.includes("motorcycle") || queryLower.includes("bike") || 
     queryLower.includes("cycle") || queryLower.includes("scooter") || queryLower.includes("car") || 
     queryLower.includes("vehicle") || queryLower.includes("automotive") || queryLower.includes("tire") ||
     queryLower.includes("wheel")) && !queryLower.includes("toy")
  ) {
    category = ItemCategory.SPORTS;
    tagline = "High-Performance Advanced Transportation System";
    price = 3500;
    weight = 135.0;
    length = 210; width = 80; height = 115;
    image = "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80";

    if (queryLower.includes("bicycle") || (queryLower.includes("cycle") && !queryLower.includes("motor"))) {
      price = 450; weight = 12.5; length = 170; width = 40; height = 100;
      tagline = "Premium Lightweight Multi-Terrain Bicycle";
      image = "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("ktm")) {
      price = 8500; weight = 148.0; length = 215; width = 85; height = 120;
      tagline = "KTM Ready-To-Race High-Performance Sports Motorcycle";
      image = "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80";
    }

    description = `Premium vehicle and high-durability transit equipment designed for extreme performance. Features high-grade lightweight metal compounds, hydraulic shock absorption loops, and advanced fuel or solid batteries. Crated and shipped via heavy logistics guidelines.`;
  }

  // 1. ELECTRONICS / HOME APPLIANCES / TECH GEAR
  else if (
    queryLower.includes("phone") || queryLower.includes("macbook") || queryLower.includes("laptop") || 
    queryLower.includes("rtx") || queryLower.includes("electronics") || queryLower.includes("headphones") || 
    queryLower.includes("ipad") || queryLower.includes("playstation") || queryLower.includes("sony") || 
    queryLower.includes("keyboard") || queryLower.includes("pixel") || queryLower.includes("smart tv") || 
    queryLower.includes("speaker") || queryLower.includes("earbuds") || queryLower.includes("watch") || 
    queryLower.includes("power bank") || queryLower.includes("charger") || queryLower.includes("usb") || 
    queryLower.includes("mouse") || queryLower.includes("router") || queryLower.includes("extension") || 
    queryLower.includes("led bulb") || queryLower.includes("fan") || queryLower.includes("air cond") || 
    queryLower.includes("cooler") || queryLower.includes("cctv") || queryLower.includes("grinder") || 
    queryLower.includes("blender") || queryLower.includes("cooker") || queryLower.includes("oven") || 
    queryLower.includes("refrigerator") || queryLower.includes("fridge") || queryLower.includes("washing") || 
    queryLower.includes("vacuum") || queryLower.includes("fryer") || queryLower.includes("kettle") || 
    queryLower.includes("toaster") || queryLower.includes("stove") || queryLower.includes("trimmer") || 
    queryLower.includes("dryer") || queryLower.includes("straightener") || queryLower.includes("iron") ||
    queryLower.includes("tablet")
  ) {
    category = ItemCategory.ELECTRONICS;
    tagline = "Premium Advanced Electrical Device";
    price = 199;
    weight = 1.2;
    length = 24; width = 18; height = 12;
    image = "https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&w=600&q=80";

    if (queryLower.includes("phone") || queryLower.includes("pixel") || queryLower.includes("smartphone") || queryLower.includes("tablet")) {
      price = 799; weight = 0.22; length = 16; width = 8; height = 2;
      tagline = "Smart Next-Generation Mobile Communicator";
      image = "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("laptop") || queryLower.includes("macbook")) {
      price = 1299; weight = 1.65; length = 34; width = 24; height = 3;
      tagline = "High-Performance Workstation Computer Bundle";
      image = "https://images.unsplash.com/photo-1496181130204-755241544e35?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("tv") || queryLower.includes("television")) {
      price = 650; weight = 12.5; length = 110; width = 68; height = 15;
      tagline = "Ultra-HD 4K Cinematic Smart Screen Display";
      image = "https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("refrigerator") || queryLower.includes("fridge")) {
      price = 950; weight = 58.0; length = 75; width = 70; height = 175;
      tagline = "Multi-Zone Eco-Inverter Refrigerator";
      image = "https://images.unsplash.com/photo-1571175432247-5c12ef024d27?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("earbuds") || queryLower.includes("headphones") || queryLower.includes("speaker")) {
      price = 120; weight = 0.35; length = 18; width = 14; height = 7;
      tagline = "High-Fidelity Dynamic Acoustic Audio Gear";
      image = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("stove") || queryLower.includes("cooker") || queryLower.includes("fryer") || queryLower.includes("grinder") || queryLower.includes("blender") || queryLower.includes("kettle") || queryLower.includes("oven") || queryLower.includes("washing") || queryLower.includes("vacuum") || queryLower.includes("toaster")) {
      price = 149; weight = 4.2; length = 38; width = 32; height = 24;
      tagline = "Advanced Home Living Smart Utility Appliance";
      image = "https://images.unsplash.com/photo-1574269909862-7e1d70bb8078?auto=format&fit=crop&w=600&q=80";
    }

    description = `Commercial-grade electric standard unit built for efficient home duty. Configured with standard high-efficiency copper components, thermal isolation plates, and premium grounded electrical cords. Matches strict logistics safety guidelines for air shipments.`;
  }
  
  // 2. FASHION & APPAREL, ETHNIC WEAR, SHOES & BEAUTY ACCESSORIES
  else if (
    queryLower.includes("shirt") || queryLower.includes("top") || queryLower.includes("hoodie") || 
    queryLower.includes("sweat") || queryLower.includes("jacket") || queryLower.includes("coat") || 
    queryLower.includes("jeans") || queryLower.includes("pants") || queryLower.includes("legging") || 
    queryLower.includes("jegging") || queryLower.includes("skirt") || queryLower.includes("dress") || 
    queryLower.includes("suit") || queryLower.includes("pajama") || queryLower.includes("inner") || 
    queryLower.includes("socks") || queryLower.includes("bra") || queryLower.includes("kurti") || 
    queryLower.includes("saree") || queryLower.includes("blouse") || queryLower.includes("dupatta") || 
    queryLower.includes("shawl") || queryLower.includes("sweater") || queryLower.includes("cardigan") || 
    queryLower.includes("blazer") || queryLower.includes("raincoat") || queryLower.includes("bag") || 
    queryLower.includes("wallet") || queryLower.includes("belt") || queryLower.includes("cap") || 
    queryLower.includes("glasses") || queryLower.includes("earring") || queryLower.includes("necklace") || 
    queryLower.includes("bracelet") || queryLower.includes("ring") || queryLower.includes("clip") || 
    queryLower.includes("band") || queryLower.includes("sandal") || queryLower.includes("flat") || 
    queryLower.includes("heels") || queryLower.includes("slippers")
  ) {
    category = ItemCategory.FASHION;
    tagline = "Designer Apparel & Lifestyle Wear";
    price = 49;
    weight = 0.35;
    length = 26; width = 18; height = 3;
    image = "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=600&q=80";

    if (queryLower.includes("jacket") || queryLower.includes("coat") || queryLower.includes("blazer")) {
      price = 159; weight = 1.3; length = 36; width = 28; height = 7;
      tagline = "Premium Hand-Stitched Custom Structured Outerwear";
      image = "https://images.unsplash.com/photo-1544022613-e87ca75a784a?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("saree") || queryLower.includes("kurti") || queryLower.includes("dress") || queryLower.includes("anarkali")) {
      price = 85; weight = 0.65; length = 30; width = 22; height = 4;
      tagline = "Elegant Royal Traditional Ensemble Pack";
      image = "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("bag") || queryLower.includes("handbag") || queryLower.includes("tote")) {
      price = 120; weight = 0.8; length = 32; width = 22; height = 12;
      tagline = "Premium Crafted Structured Carryall Handbag";
      image = "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("glasses") || queryLower.includes("watch") || queryLower.includes("sunglasses")) {
      price = 95; weight = 0.15; length = 15; width = 8; height = 5;
      tagline = "Classic Lightweight Lifestyle Eyewear";
      image = "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("shoes") || queryLower.includes("heels") || queryLower.includes("sandal") || queryLower.includes("flats") || queryLower.includes("slippers")) {
      price = 78; weight = 0.75; length = 31; width = 17; height = 11;
      tagline = "Engineered Ergonomic Fashion Footwear";
      image = "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=600&q=80";
    }

    description = `Premium textile garment manufactured from certified organic fibers, utilizing skin-friendly non-toxic reactive dyes. Elegantly packed inside protective commercial poly-wrap bounds, meeting clean international customs classification directives.`;
  }

  // 3. COSMETICS, SKINCARE, MAKEUP, PERFUMES & HAIR TOOLS
  else if (
    queryLower.includes("brush") || queryLower.includes("foundation") || queryLower.includes("concealer") || 
    queryLower.includes("powder") || queryLower.includes("cream") || queryLower.includes("primer") || 
    queryLower.includes("lipstick") || queryLower.includes("gloss") || queryLower.includes("balm") || 
    queryLower.includes("eyeliner") || queryLower.includes("kajal") || queryLower.includes("mascara") || 
    queryLower.includes("palette") || queryLower.includes("remover") || queryLower.includes("wash") || 
    queryLower.includes("scrub") || queryLower.includes("mask") || queryLower.includes("moisturizer") || 
    queryLower.includes("sunscreen") || queryLower.includes("toner") || queryLower.includes("serum") || 
    queryLower.includes("lotion") || queryLower.includes("perfume") || queryLower.includes("deodorant") || 
    queryLower.includes("spray") || queryLower.includes("nail") || queryLower.includes("toothpaste") || 
    queryLower.includes("toothbrush") || queryLower.includes("mouthwash") || queryLower.includes("razor") ||
    queryLower.includes("shampoo") || queryLower.includes("conditioner") || queryLower.includes("oil") ||
    queryLower.includes("wellness")
  ) {
    category = ItemCategory.COSMETICS;
    tagline = "Nourishing Bio-Active Radiance Formulation";
    price = 39;
    weight = 0.28;
    length = 13; width = 8; height = 6;
    image = "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80";

    if (queryLower.includes("perfume") || queryLower.includes("deodorant") || queryLower.includes("spray")) {
      price = 85; weight = 0.45; length = 14; width = 9; height = 9;
      tagline = "Concentrated French Botanical Parfum Mist";
      image = "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("serum") || queryLower.includes("cream") || queryLower.includes("moisturizer") || queryLower.includes("sunscreen") || queryLower.includes("foundation")) {
      price = 48; weight = 0.22; length = 11; width = 7; height = 7;
      tagline = "Micro-Hydrating Skin Defence Shield";
      image = "https://images.unsplash.com/photo-1608248597481-496100c80836?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("brush") || queryLower.includes("palette") || queryLower.includes("lipstick") || queryLower.includes("makeup")) {
      price = 35; weight = 0.18; length = 16; width = 10; height = 3;
      tagline = "Precision Color Artistry Professional Set";
      image = "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80";
    }

    description = `Hypoallergenic dermatologically verified cosmetic compound. Safe for air freight shipping due to sealed, impact-resistant containers. Conforms entirely with global cosmetic and personal care clearance specifications.`;
  }

  // 4. GROCERIES, FOODSTUFFS, MATCHA, pantry
  else if (
    queryLower.includes("rice") || queryLower.includes("flour") || queryLower.includes("oil") || 
    queryLower.includes("sugar") || queryLower.includes("salt") || queryLower.includes("tea") || 
    queryLower.includes("coffee") || queryLower.includes("biscuit") || queryLower.includes("noodle") || 
    queryLower.includes("pasta") || queryLower.includes("ketchup") || queryLower.includes("butter") || 
    queryLower.includes("jam") || queryLower.includes("chocolate") || queryLower.includes("chips") || 
    queryLower.includes("drink") || queryLower.includes("juice") || queryLower.includes("fruit") || 
    queryLower.includes("spice") || queryLower.includes("matcha") || queryLower.includes("grain") ||
    queryLower.includes("curry") || queryLower.includes("snack")
  ) {
    category = ItemCategory.FOOD;
    tagline = "Sustainably Harvested High-Grade Pantry Delicacy";
    price = 24;
    weight = 0.9;
    length = 22; width = 15; height = 8;
    image = "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=600&q=80";

    if (queryLower.includes("matcha") || queryLower.includes("tea") || queryLower.includes("coffee")) {
      price = 45; weight = 0.35; length = 12; width = 8; height = 7;
      tagline = "Stone-Ground Ceremonial Sourced Harvest";
      image = "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("rice") || queryLower.includes("flour")) {
      price = 18; weight = 5.0; length = 38; width = 24; height = 10;
      tagline = "Naturally Cultivated Premium Long-Grain Pack";
    } else if (queryLower.includes("chocolate") || queryLower.includes("biscuits") || queryLower.includes("chips")) {
      price = 15; weight = 0.4; length = 18; width = 12; height = 6;
      tagline = "Master-Crafted Single-Origin Cocoa Assembly";
      image = "https://images.unsplash.com/photo-1511381939415-e44ab21d5e43?auto=format&fit=crop&w=600&q=80";
    }

    description = `Premium culinary selection packed in hermetically sealed multi-barrier e-commerce foil constraints to retain pristine freshness. Marked clearly with clean ingredient tracking, certification stamps, and long-shelf-life details.`;
  }

  // 5. SPORTS, ATHLETICS, RUNNING SHOES, SNEAKERS & RECREATION
  else if (
    queryLower.includes("sports") || queryLower.includes("gym") || queryLower.includes("yoga") || 
    queryLower.includes("racket") || queryLower.includes("ball") || queryLower.includes("sportswear") || 
    queryLower.includes("sneaker") || queryLower.includes("shoe") || queryLower.includes("helmet") ||
    queryLower.includes("athletic")
  ) {
    category = ItemCategory.SPORTS;
    tagline = "High-End Tournament Strength Play System";
    price = 85;
    weight = 1.1;
    length = 32; width = 20; height = 12;
    image = "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=600&q=80";

    if (queryLower.includes("shoe") || queryLower.includes("sneaker") || queryLower.includes("running")) {
      price = 125; weight = 0.85; length = 32; width = 19; height = 11;
      tagline = "Responsive High-Elasticity Running Footwear";
      image = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80";
    }

    description = `Premium athletic system crafted using responsive honeycomb structures and impact resistant lightweight fibers. Fully compliant with standard passenger baggage clearances and sporting import frameworks.`;
  }

  // 6. BOOKS & MEDIA
  else if (
    queryLower.includes("book") || queryLower.includes("novel") || queryLower.includes("textbook") || 
    queryLower.includes("magazine") || queryLower.includes("media")
  ) {
    category = ItemCategory.BOOKS;
    tagline = "Academic and Professional Text Publication";
    price = 32;
    weight = 0.65;
    length = 24; width = 16; height = 3;
    image = "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80";
    description = `Professionally bound hardcover compilation printed on high-density acid-free paper. Exempted from standard trade duties across 150+ countries. Clean customs clearance guaranteed.`;
  }

  // 7. CHEMICALS / HYGIENE, HOUSEHOLD REPELLENTS, CLEANING
  else if (
    queryLower.includes("detergent") || queryLower.includes("cleaner") || queryLower.includes("liquid") || 
    queryLower.includes("soap") || queryLower.includes("tissue") || queryLower.includes("garbage bag") || 
    queryLower.includes("repellent") || queryLower.includes("sanitizer") || queryLower.includes("shaving") ||
    queryLower.includes("diaper") || queryLower.includes("wipe")
  ) {
    category = ItemCategory.GENERAL;
    tagline = "High-Efficiency Concentrated Home Hygiene";
    price = 18;
    weight = 1.4;
    length = 22; width = 14; height = 12;
    image = "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=600&q=80";

    if (queryLower.includes("diaper") || queryLower.includes("wipe")) {
      price = 29; weight = 1.5; length = 32; width = 20; height = 18;
      tagline = "Ultra-Soft Hypoallergenic Disposable Guard";
    }

    description = `Sanitary domestic commodity designed for optimal care. Meets health and safety guidelines, with sturdy non-spill seal closures preventing leakage. Standard global parcel profile apply.`;
  }

  // 8. BABY, MEDICAL & HEALTH
  else if (
    queryLower.includes("medicine") || queryLower.includes("vitamin") || queryLower.includes("supplement") || 
    queryLower.includes("bandage") || queryLower.includes("pill") || queryLower.includes("medical") || 
    queryLower.includes("first aid") || queryLower.includes("health")
  ) {
    category = ItemCategory.MEDICAL;
    tagline = "Verified Multi-Vitamin Wellness Formulation";
    price = 45;
    weight = 0.3;
    length = 12; width = 8; height = 8;
    image = "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&w=600&q=80";
    description = `Personal wellness supplements packed inside compliant child-safe, tamper-evident containers with full composition tracking barcodes. Checked for swift, trouble-free customs clearance pathways.`;
  }

  // 9. TOYS & HOBBIES
  else if (
    queryLower.includes("toy") || queryLower.includes("lego") || queryLower.includes("game") || 
    queryLower.includes("puzzle") || queryLower.includes("doll") || queryLower.includes("pet") || 
    queryLower.includes("dog") || queryLower.includes("cat")
  ) {
    category = ItemCategory.TOYS;
    tagline = "Premium Family Recreation System";
    price = 55;
    weight = 1.2;
    length = 30; width = 20; height = 8;
    image = "https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?auto=format&fit=crop&w=600&q=80";
    description = `ASTM safety-certified child or family entertainment product. Molded using safe, high-durability polymer resins and packaged in standard commercial visual retail sleeves. Clear shipping rules apply.`;
  }

  // DEFAULT FALLBACK: GENERAL MERCHANDISE, LINENS, UTENSILS
  else {
    category = ItemCategory.GENERAL;
    tagline = "Premium Durable Home Merchandise Piece";
    price = 32;
    weight = 0.85;
    length = 24; width = 16; height = 10;
    image = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80";

    if (queryLower.includes("towel") || queryLower.includes("bedsheet") || queryLower.includes("blanket") || queryLower.includes("pillow") || queryLower.includes("curtain") || queryLower.includes("linen")) {
      price = 45; weight = 1.30; length = 34; width = 25; height = 6;
      tagline = "Woven Multi-Thread Pure Cotton Comfort Bundle";
      image = "https://images.unsplash.com/photo-1616627547474-12349e1e2494?auto=format&fit=crop&w=600&q=80";
    } else if (queryLower.includes("bottle") || queryLower.includes("cup") || queryLower.includes("plate") || queryLower.includes("knife") || queryLower.includes("fork") || queryLower.includes("mug")) {
      price = 22; weight = 0.45; length = 16; width = 11; height = 11;
      tagline = "Premium Heat-Stabilized Dining Homeware";
      image = "https://images.unsplash.com/photo-1517256064527-09c53b2d0bc6?auto=format&fit=crop&w=600&q=80";
    }

    description = `Premium high-durability item designed for home, recreational or private utilities. Secured in robust reinforced parcel board structures suitable for direct express trans-border deliveries with zero inspection flags.`;
  }

  // Built dynamic capitilised product title matching standard formatting
  const name = searchQuery.split(" ").map(w => {
    if (w.toLowerCase() === "ktm") return "KTM";
    return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
  }).join(" ");

  return {
    id: "custom_" + Math.random().toString(36).substring(2, 9),
    name,
    tagline,
    category,
    priceUSD: price,
    weightKg: weight,
    lengthCm: length,
    widthCm: width,
    heightCm: height,
    image,
    description
  };
}

// REST API endpoint: Custom Product Specifications Lookup using Gemini AI
app.post("/api/custom-product-lookup", async (req, res) => {
  const { searchQuery } = req.body;
  if (!searchQuery || !searchQuery.trim()) {
    return res.status(400).json({ error: "Search query is required to retrieve item specifications." });
  }

  try {
    // Try live retrieval via Gemini AI first
    const modelInstance = getGemini();
    const prompt = `You are a helpful expert international logistics assistant and product catalog taxonomist.
The user is searching for a product to buy online and clear through customs: "${searchQuery}".
Analyze this search phrase and identify the standard, realistic, highly accurate packaging specifications, retail pricing, and category mapping.

Respond back with a JSON object EXACTLY containing the following properties:
{
  "name": "Full precise polished brand name (e.g., 'Sony PlayStation 5 Slim' or 'Dyson Airwrap Multi-Styler')",
  "tagline": "A short elegant marketing tagline for the item (e.g., 'Ultimate 4K Next-Gen Gaming Engine' or 'Specialist Aerodynamic Hair Therapy')",
  "category": "Must be exactly one of these string values: 'Electronics', 'Fashion & Apparel', 'Books & Media', 'Cosmetics & Personal Care', 'Toys & Hobbies', 'Sports & Outdoors', 'Food & Perishables', 'Medical & Health', 'General Merchandise'",
  "priceUSD": A realistic average retail price as a number in USD (e.g., 499),
  "weightKg": A realistic package physical weight in kilograms as a decimal number (e.g. 3.20),
  "lengthCm": A realistic box packaging length in centimeters as an integer or decimal (e.g. 35.8),
  "widthCm": A realistic box packaging width in centimeters as an integer or decimal (e.g. 22.4),
  "heightCm": A realistic box packaging height in centimeters as an integer or decimal (e.g. 10.5),
  "image": "A beautiful, relevant Unsplash image URL illustrating this type of product.",
  "description": "A professional paragraph detailing the specific characteristics of the product. Be descriptive—mention materials, if it contains special components like lithium metal batteries, original sealed e-commerce box structures, etc. This description will be fed directly to the customs classification AI."
}

Available realistic beautiful Unsplash image URLs categorized by matching types:
- Electronics: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=600&q=80'
- Fashion: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&q=80'
- Cosmetics/Perfume: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1608248597481-496100c80836?auto=format&fit=crop&w=600&q=80'
- Sports: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=600&q=80'
- Food: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=600&q=80'
- Medical: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&w=600&q=80'
- Generic premium object: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80'

Choose whichever most accurately reflects the searched product category.
Do not add any markdown formatting like \`\`\`json or backticks. Return the pure JSON string so that it can be parsed directly.`;

    const response = await modelInstance.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            tagline: { type: Type.STRING },
            category: { type: Type.STRING },
            priceUSD: { type: Type.NUMBER },
            weightKg: { type: Type.NUMBER },
            lengthCm: { type: Type.NUMBER },
            widthCm: { type: Type.NUMBER },
            heightCm: { type: Type.NUMBER },
            image: { type: Type.STRING },
            description: { type: Type.STRING }
          },
          required: [
            "name", "tagline", "category", "priceUSD", "weightKg",
            "lengthCm", "widthCm", "heightCm", "image", "description"
          ]
        }
      }
    });

    const jsonText = response.text || "{}";
    const productSpec = JSON.parse(jsonText.trim());
    productSpec.id = "custom_" + Math.random().toString(36).substring(2, 9);
    productSpec.weightKg = Math.floor(Math.random() * 10) + 1; // random 1 to 10
    
    return res.json(productSpec);
  } catch (error: any) {
    console.warn("Gemini Live API Specs query did not complete, falling back immediately to the local intelligent taxonomy engine. Source error:", error.message || error);
    
    // Smooth automatic failover to the pre-mapped database category
    const productSpec = getSimulatedProductSpecs(searchQuery);
    productSpec.weightKg = Math.floor(Math.random() * 10) + 1; // random 1 to 10
    return res.json(productSpec);
  }
});

// REST API endpoint: Calculate custom duties & international shipping rates
app.post("/api/calculate", (req, res) => {
  try {
    const input: CalculationInput = req.body;
    
    // Find rates and country parameters
    const origin = COUNTRIES.find(c => c.code === input.originCode) || COUNTRIES[0];
    const destination = COUNTRIES.find(c => c.code === input.destinationCode) || COUNTRIES[1];
    
    // Convert weight to KG
    let baseWeightKg = input.weight;
    if (input.weightUnit === "lb") {
      baseWeightKg = input.weight * 0.45359237;
    }
    
    // Volumetric Weight Calculation (L * W * H / 5000 in cm / kg scale)
    let lengthCm = input.length;
    let widthCm = input.width;
    let heightCm = input.height;
    
    if (input.dimensionUnit === "in") {
      lengthCm = input.length * 2.54;
      widthCm = input.width * 2.54;
      heightCm = input.height * 2.54;
    }
    
    const volumetricWeightKg = (lengthCm * widthCm * heightCm) / 5000;
    const chargeableWeightKg = Math.max(baseWeightKg, volumetricWeightKg);
    
    // -------------------------------------------------------------------------
    // Shipping Cost Formulation
    // -------------------------------------------------------------------------
    // Basic structural formula for pricing:
    // Standard: Base $15 + $8.50 per chargeable kg
    // Express: Base $35 + $14.50 per chargeable kg
    const baseShippingRate = input.shippingMode === "express" ? 35 : 15;
    const perKgRate = input.shippingMode === "express" ? 14.50 : 8.50;
    
    const baseShippingCostUSD = baseShippingRate + (chargeableWeightKg * perKgRate);
    const fuelSurchargeUSD = baseShippingCostUSD * 0.125; // 12.5% fuel fee
    const handlingFeeUSD = 7.50; // Flat administration surcharge
    
    const totalShippingCostUSD = baseShippingCostUSD + fuelSurchargeUSD + handlingFeeUSD;
    
    // -------------------------------------------------------------------------
    // Value Formulation
    // -------------------------------------------------------------------------
    // Convert the item value from the origin currency to USD for thresholds
    const itemCurrencyPrice = input.declaredValue;
    const originRateToUSD = EXCHANGE_RATES[input.valueCurrency] || EXCHANGE_RATES[origin.currency] || 1.0;
    const itemValueUSD = itemCurrencyPrice * originRateToUSD;
    
    // Check de-minimis threshold:
    // If the landed value (usually declared price + freight) OR declared price
    // is below the de-minimis limit of the destination country, duty & tax is zero!
    const isBelowDeMinimis = itemValueUSD <= destination.deMinimis;
    
    // -------------------------------------------------------------------------
    // Duties & Consumption Tax Formulation
    // -------------------------------------------------------------------------
    let dutyUSD = 0;
    let vatUSD = 0;
    
    if (!isBelowDeMinimis) {
      // Duty calculation
      const dutyPercentage = destination.dutyRates[input.category] !== undefined 
        ? destination.dutyRates[input.category] 
        : 5.0; // Default general percentage is 5%
      
      // Customs valuation typically bases duty on CIF (Cost, Insurance & Freight) which includes shipping
      const cifValueUSD = itemValueUSD + totalShippingCostUSD;
      dutyUSD = cifValueUSD * (dutyPercentage / 100);
      
      // VAT/GST typically applied to (CIF + Duty)
      const vatTaxableUSD = cifValueUSD + dutyUSD;
      vatUSD = vatTaxableUSD * (destination.vatRate / 100);
    }
    
    // -------------------------------------------------------------------------
    // Total Landed Cost (Landed cost = Item Value + Shipping Fees + Customs + Taxes)
    // -------------------------------------------------------------------------
    const landedCostUSD = itemValueUSD + totalShippingCostUSD + dutyUSD + vatUSD;
    
    // Currency conversion relative to destination local currency
    const destRateToUSD = EXCHANGE_RATES[destination.currency] || 1.0;
    
    const baseShippingCostLocal = baseShippingCostUSD / destRateToUSD;
    const dutyLocal = dutyUSD / destRateToUSD;
    const vatLocal = vatUSD / destRateToUSD;
    const landedCostLocal = landedCostUSD / destRateToUSD;
    
    // -------------------------------------------------------------------------
    // Timelines Prediction
    // -------------------------------------------------------------------------
    // Express shipping normally 4-7 days; standard shipping 7-12 days.
    // Customs speed varies. Slow customs e.g., India adds extra cushions
    const customsDelayBuffer = destination.code === "IN" ? 3 : (destination.code === "US" ? 1 : 2);
    
    const timelineMinDays = input.shippingMode === "express" ? 4 : 7;
    const timelineMaxDays = (input.shippingMode === "express" ? 7 : 12) + customsDelayBuffer;
    
    // -------------------------------------------------------------------------
    // Smart Incoterms Recommendation (Member 1 - smart UI insights requirement)
    // -------------------------------------------------------------------------
    // DDP (Delivered Duty Paid): Recommended if total duties are low, or standard shipping.
    // DAP (Delivered at Place): Recommended when there is a risk of high duty disputes.
    let incoterm: "DDP" | "DAP" = "DDP";
    let score = 95;
    let recTitle = "Prepaid customs (DDP) Recommended";
    let recDesc = "We recommend prepaying duties and VAT at checkout. This speeds up customs clearance, avoids local agency delivery surcharges, and ensures zero surprise fees on delivery.";
    
    if (dutyUSD > 200 || destination.code === "IN") {
      incoterm = "DAP";
      score = 78;
      recTitle = "Collect Duty (DAP) Recommended";
      recDesc = "High tax margins or strict clearance policies apply. Pay customs locally with your destination broker. Ensure you prepare relevant import KYC documents (e.g., PAN Card) in advance.";
    }
    
    const result: CalculationResult = {
      chargeableWeightKg: Number(chargeableWeightKg.toFixed(2)),
      volumetricWeightKg: Number(volumetricWeightKg.toFixed(2)),
      baseShippingCostUSD: Number(baseShippingCostUSD.toFixed(2)),
      baseShippingCostLocal: Number(baseShippingCostLocal.toFixed(2)),
      fuelSurchargeUSD: Number(fuelSurchargeUSD.toFixed(2)),
      handlingFeeUSD: Number(handlingFeeUSD.toFixed(2)),
      dutyUSD: Number(dutyUSD.toFixed(2)),
      dutyLocal: Number(dutyLocal.toFixed(2)),
      vatUSD: Number(vatUSD.toFixed(2)),
      vatLocal: Number(vatLocal.toFixed(2)),
      landedCostUSD: Number(landedCostUSD.toFixed(2)),
      landedCostLocal: Number(landedCostLocal.toFixed(2)),
      timelineMinDays,
      timelineMaxDays,
      isBelowDeMinimis,
      recommendation: {
        incoterm,
        title: recTitle,
        description: recDesc,
        score
      }
    };
    
    // Create history entry
    const entryId = "calc_" + Math.random().toString(36).substring(2, 9);
    const newEntry: HistoryEntry = {
      id: entryId,
      timestamp: new Date().toISOString(),
      input,
      result,
      originCountryName: origin.name,
      destinationCountryName: destination.name
    };
    calculationHistory.unshift(newEntry);
    
    // Add real-time log event to mock calculation list
    const logEvent = `New estimated shipment calculated: ${origin.name} to ${destination.name} (${input.category}) - Total Landed Cost: ${destination.symbol}${landedCostLocal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    console.log(logEvent);
    
    res.json({ id: entryId, result });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// REST API endpoint: Intelligent Advisor powered by Gemini 3.5-flash
app.post("/api/gemini/advisor", async (req, res) => {
  try {
    const { originCode, destinationCode, itemDescription, declaredValue, category } = req.body;
    
    const origin = COUNTRIES.find(c => c.code === originCode) || COUNTRIES[0];
    const destination = COUNTRIES.find(c => c.code === destinationCode) || COUNTRIES[1];
    
    // Retrieve lazy loaded Gemini client
    let modelInstance;
    try {
      modelInstance = getGemini();
    } catch (kError: any) {
      // Graceful local backup if API key is not present or configured (fails fast without server crash)
      console.warn("Gemini Client could not start (likely missing GEMINI_API_KEY). Returning high-quality simulated advisory parameters.");
      
      const simulatedAdvice: GeminiAdvisorResponse = {
        hsCode: "8517.62.90",
        hsCodeConfidence: "High",
        dutyEstimateRange: `${destination.dutyRates[category as ItemCategory] || 5.0}% - 10.0%`,
        vatGstRate: `${destination.vatRate}% VAT/GST`,
        restrictionsWarning: `Please ensure your item does not contain any of the prohibited items for ${destination.name}: ${destination.restrictedItems.slice(0, 3).join(", ")}. In particular, check if it requires local RF/wireless safety certifications.`,
        isRestricted: false,
        documentationRequired: ["Commercial Invoice", "Air Waybill (AWB)", "Packing List", "Country of Origin Declaration Certificate"],
        smartAdvice: `Customs clearance for ${category} from ${origin.name} bound for ${destination.name} is generally simple. For declared values of $${declaredValue}, ${declaredValue > destination.deMinimis ? "the value is ABOVE the destination de-minimis threshold of $" + destination.deMinimis + ", so duty+VAT will be charged." : "the value is below the threshold of $" + destination.deMinimis + ", so it enters duty-free!"} Pre-declare and use the correct Harmonized Tariff code.`
      };
      
      return res.json(simulatedAdvice);
    }
    
    // Connect to actual Gemini client using gemini-3.5-flash which is ideal for basic-to-moderate text and structured JSON outputs
    const prompt = `You are an expert cross-border customs classifier and shipping import broker counselor. You are analyzing an e-commerce order with the following metadata:
- Origin Country: ${origin.name} (Code: ${origin.code})
- Destination Country: ${destination.name} (Code: ${destination.code})
- Product Category: ${category}
- Declared Value: ${declaredValue} ${origin.currency}
- Item Product Description: "${itemDescription}"

Using standard Harmonized System (HS) classifications, estimate and formulate a high-quality advisor response in JSON format exactly matching the following structure:
{
  "hsCode": "Proposed 6-to-8 digit HS Code (e.g. '8517.62.00')",
  "hsCodeConfidence": "'High' | 'Medium' | 'Low'",
  "dutyEstimateRange": "Description of likely import duty range based on product description (e.g. '3.5% - 5.0%')",
  "vatGstRate": "Description of standard consumption tax/VAT rate at destination (e.g. '20% VAT' or '10% Goods & Services Tax')",
  "restrictionsWarning": "Analyze if the product description is likely prohibited or requires special permits in destination country. Be specific about destination forbidden items (e.g. lithium batteries, wireless RF certification, or food quarantine rules).",
  "isRestricted": true or false (use boolean, true if suspicious, forbidden, or heavily restricted),
  "documentationRequired": ["Document 1", "Document 2", "etc"],
  "smartAdvice": "Provide a high-impact, scannable advisor paragraph with practical tips: how to declare safely, packaging suggestions, whether DDP is suitable, and any import tax loopholes (like de-minimis limits)."
}

Do not add any markdown decoration like \`\`\`json or backticks. Return the pure JSON string so that it can be parsed directly in JSON format. Provide high quality, professional, realistic information.`;

    const response = await modelInstance.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            hsCode: { type: Type.STRING },
            hsCodeConfidence: { type: Type.STRING },
            dutyEstimateRange: { type: Type.STRING },
            vatGstRate: { type: Type.STRING },
            restrictionsWarning: { type: Type.STRING },
            isRestricted: { type: Type.BOOLEAN },
            documentationRequired: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            smartAdvice: { type: Type.STRING }
          },
          required: [
            "hsCode", "hsCodeConfidence", "dutyEstimateRange", 
            "vatGstRate", "restrictionsWarning", "isRestricted", 
            "documentationRequired", "smartAdvice"
          ]
        }
      }
    });

    const jsonText = response.text || "{}";
    const advisorResponse: GeminiAdvisorResponse = JSON.parse(jsonText.trim());
    res.json(advisorResponse);
  } catch (error: any) {
    console.error("Gemini Advisor API Error:", error);
    res.status(500).json({ error: error.message || "An error occurred with GenAI" });
  }
});

// REST API endpoint: Interactive bargaining/negotiator agent
app.post("/api/bargain", async (req, res) => {
  try {
    const { originalResult, proposedPriceUSD, attemptsCount, declaredValue } = req.body;
    if (!originalResult || typeof proposedPriceUSD !== "number") {
      return res.status(400).json({ error: "Missing required bargain parameters." });
    }

    const price = Number(proposedPriceUSD);
    const originalLanded = originalResult.landedCostUSD;
    const requestedDiscount = originalLanded - price;

    if (price <= 0 || price >= originalLanded) {
      return res.json({
        status: "rejected",
        bargainedLandedCostUSD: originalLanded,
        explanation: "Our freight calculations are precise. Please enter a valid bid below the standard price to begin negotiating."
      });
    }

    const baseShipping = originalResult.baseShippingCostUSD || 0;
    const dutyVal = originalResult.dutyUSD || 0;
    const vatVal = originalResult.vatUSD || 0;
    const surcharges = (originalResult.fuelSurchargeUSD || 0) + (originalResult.handlingFeeUSD || 0);

    const nonNegotiableTaxes = dutyVal + vatVal;
    // Base item value + non negotiable taxes cannot be negotiated
    const fixedMinimumThreshold = declaredValue + nonNegotiableTaxes;

    // Surcharges + 30% of shipping is our maximum negotiable room
    const maxNegotiableDiscount = surcharges * 1.0 + baseShipping * 0.35;

    // Minimum absolute price we can accept
    const minimumFeasiblePrice = Math.round(Math.max(fixedMinimumThreshold + baseShipping * 0.65, originalLanded - maxNegotiableDiscount));

    // Let's check attempts. If attemptsCount is high (e.g. >= 3), we get rigid
    const isFatigued = (attemptsCount || 0) >= 3;

    // Try utilizing Gemini if available for a fun interactive roleplay!
    try {
      const modelInstance = getGemini();
      const prompt = `You are a professional cargo logistics broker negotiations bot. A customer is bargaining on their shipping and import tax package.
Original Landed Cost breakdown:
- Declared Item Value: $${declaredValue}
- Base Freight: $${baseShipping}
- Government Duty: $${dutyVal}
- VAT/GST: $${vatVal}
- Surcharges & Handling: $${surcharges}
- Total Original Landed Cost: $${originalLanded}

Customer Proposed Price: $${price} (Requested Discount: $${requestedDiscount})
Minimum Allowed Price threshold (our hard bottom line): $${minimumFeasiblePrice}
Negotiation attempts count so far: ${attemptsCount || 0} (max 3 rounds)

Decide the outcome based on these instructions:
1. If the offer is very close to original or the requested discount is subtle (less than 8% of total cost and keeps price above bottom line), "approve" it.
2. If the offer is realistic but below bottom line, or if it is a moderate discount (e.g. discount represents 8% - 25% of total cost and stays above bottom line), propose a "counter" offer. The countered total price MUST be between the customer's proposed price and the original price. Make it mathematically sound (e.g., meeting in the middle or suggesting a discount of around 15% of flexible freight portion).
3. If the offer is way too low (e.g., below bottom line, or below $${minimumFeasiblePrice}), "reject" it and explain politely why government taxes ($${nonNegotiableTaxes}) and core carrier fuel costs cannot be negotiated. Suggest a reasonable counter-target (e.g. $${Math.round(originalLanded - (maxNegotiableDiscount * 0.4))} USD).
4. Keep the explanation snappy, extremely helpful, realistic, professional, and slightly witty.

Produce a JSON response ONLY of the following format:
{
  "status": "approved" | "rejected" | "countered",
  "bargainedLandedCostUSD": number,
  "explanation": "concise explanation reflecting your persona as a friendly logistics agent"
}`;

      const aiResponse = await modelInstance.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              status: { type: Type.STRING },
              bargainedLandedCostUSD: { type: Type.NUMBER },
              explanation: { type: Type.STRING }
            },
            required: ["status", "bargainedLandedCostUSD", "explanation"]
          }
        }
      });

      const responseText = aiResponse.text || "{}";
      const parsed = JSON.parse(responseText.trim());
      if (parsed.status && parsed.bargainedLandedCostUSD) {
        return res.json(parsed);
      }
    } catch (aiErr: any) {
      console.warn("Bargain API calling Gemini failed, falling back to local math algorithm:", aiErr.message || aiErr);
    }

    // High fidelity Fallback Algorithm
    let status: "approved" | "rejected" | "countered" = "rejected";
    let finalPrice = originalLanded;
    let explanation = "";

    const discountPercentage = (requestedDiscount / originalLanded) * 100;

    if (price < minimumFeasiblePrice) {
      status = "rejected";
      finalPrice = originalLanded;
      const targetHint = Math.round(originalLanded - (maxNegotiableDiscount * 0.4));
      explanation = `Bargain bid rejected! ❌ Code regulatory minimum threshold error. Your proposed offering of $${price} USD represents a ${discountPercentage.toFixed(1)}% reduction. Because duties & taxes ($${nonNegotiableTaxes.toFixed(2)}) are statutory government mandates and carrier slots require baseline operations fuel, our hard floor limit is $${minimumFeasiblePrice.toFixed(2)}. Suggest bidding closer to $${targetHint} USD to trigger an automated clearance deal.`;
    } else if (discountPercentage <= 7) {
      // Very reasonable discount request!
      status = "approved";
      finalPrice = price;
      explanation = `Deal approved! 🤝 We have reduced our secondary handling commissions directly from your freight invoice. Your bid of $${price} is validated. Your total landed price is officially updated to $${price} USD. Safe shipping!`;
    } else {
      // Propose Counter-Offer
      status = "countered";
      // Meet them somewhere in between their bid and the base original
      const concessionFrac = isFatigued ? 0.35 : 0.55;
      const concession = requestedDiscount * concessionFrac;
      finalPrice = Number((originalLanded - concession).toFixed(2));
      const differenceUSD = originalLanded - finalPrice;

      explanation = `Counter-offer proposed! ⚖️ We cannot discount regional country duties, but we've successfully waived administrative markup and part of our high-volume fuel allowance. We can counter at $${finalPrice} USD, immediately saving you $${differenceUSD.toFixed(2)} USD from the original rate. Do you accept this counter-deal?`;
    }

    return res.json({
      status,
      bargainedLandedCostUSD: finalPrice,
      explanation
    });

  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Vite & Static file configurations
if (process.env.NODE_ENV !== "production") {
  // Use Vite development server middleware in development
  import("vite").then(async (viteModule) => {
    const vite = await viteModule.createServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
    console.log("Vite development middleware registered successfully.");
  });
} else {
  // Serve compiled production files
  const distPath = path.join(process.cwd(), "dist");
  app.use(express.static(distPath));
  app.get("*", (req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });
}

// Global process error handling
process.on("unhandledRejection", (err) => {
  console.error("Unhandled Rejection:", err);
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Express server running on http://0.0.0.0:${PORT} in ${process.env.NODE_ENV || "development"} mode.`);
});
